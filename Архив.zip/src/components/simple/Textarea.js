import React from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'

const Textarea = ({color, fontSize, fontWeight, marginBottom, padding, marginTop, width, height}) => (
  <MainTextarea
    color={color}
    fontSize={fontSize}
    fontWeight={fontWeight}
    marginBottom={marginBottom}
    marginTop={marginTop}
    width={width}
    height={height}/>
);

Textarea.propTypes = {
  color: PropTypes.string,
  fontSize: PropTypes.string,
  fontWeight: PropTypes.string,
  marginBottom: PropTypes.string,
  marginTop: PropTypes.string,
  width: PropTypes.string,
  height: PropTypes.string
}

Textarea.defaultProps = {
  text: ''
}

export default Textarea

const MainTextarea = styled.textarea`
  width: ${props => props.width ? props.width : "300px"};
  height: ${props => props.height ? props.height: "80px"}
  font-family: Roboto;
  font-size: ${props => props.fontSize ?  props.fontSize : "16px"};
  font-weight: ${props => props.fontWeight ?  props.fontWeight : "300"};
  margin-bottom: ${props => props.marginBottom ? props.marginBottom : "0px"}
  margin-top: ${props => props.marginTop ? props.marginTop : "0px"}
  box-shadow: 0 1px 2px 0 rgba(90, 90, 90, 0.12);
  background-color: #ffffff;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  border: none;
  resize: none;
  color: ${props => props.color ?  props.color : "#3c445a"};
`;
