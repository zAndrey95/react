import React from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'

const Underline = ({color, width, margin}) => (
  <Line
    color = {color}
    width={width}
    margin={margin}
  />
);

Underline.propTypes = {
  color: PropTypes.string,
  margin: PropTypes.string
}

Underline.defaultProps = {
  value: ''
}

export default Underline

const Line = styled.div`
  width: ${props => props.width ?  props.width : "100%"};
  background-color: ${props => props.color ?  props.color : "#fff"};
  margin: ${props => props.margin ?  props.margin : "0px"};
  height: 2px;
  
`;

// <Text text="value" color="string" fontSize ="300px" fontWeight = 500/>