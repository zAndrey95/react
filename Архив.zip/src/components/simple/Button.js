import React from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'

const Button = ({className, value, onClick, width}) => (
  <ReactButton
    className = {className}
    value={value}
    onClick={onClick}
    width={width} > {value} </ReactButton>
);

Button.propTypes = {
  className: PropTypes.string,
  name: PropTypes.string,
  value: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number
  ]),
  onClick: PropTypes.func,
  width: PropTypes.string
}

Button.defaultProps = {
  value: 'button'
}

export default Button

const ReactButton = styled.div`
  width: ${props => props.width ?  props.width : "100%"};
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #99d5d7;
  border-radius: 6px;
  height: 46px;
  color: #fff;
  font-size: 16px;
    &:hover {
      font-size: 16px;
      font-weight: 500;
      color: #fff;
      box-shadow: 0 2px 2px 0 rgba(151, 151, 151, 0.14);
      background-color: #69bcbe;
      -webkit-transition: all 0.3s ease;;
      -moz-transition: all 0.3s ease;;
      -o-transition: all 0.3s ease;;
      transition: all 0.3s ease;
    }

  &.black {
    background-color: #2e3941;
    color: #ffffff;
      &:hover {
      box-shadow: 0 2px 2px 0 rgba(151, 151, 151, 0.35);
      background-color: #575d6d;
    }
  }

  &.transparent {
    background-color : transparent;
    color: #3c445a;
    border: 1px solid #2e3941;
      &:hover {
        box-shadow: 0 2px 2px 0 rgba(151, 151, 151, 0.35);
        background-color: #2e3941
        color: #ffffff;
    }
  }

  &.red-btn {
    background-color : transparent;
    color: #dd5860;
    border: 1px solid #dd5860;
      &:hover {
        box-shadow: 0 2px 2px 0 rgba(151, 151, 151, 0.35);
        background-color : #dd5860;
        color: #ffffff;
    }
  }


`;






