import React, { Component } from 'react';
import { Col } from 'react-bootstrap';
import styled from 'styled-components';
import PropTypes from 'prop-types'

import True from './source/CheckboxTrue.png'
import False from './source/CheckboxFalse.png'

class CheckBox extends Component {
  state = {
    open: false
  }

componentWillReceiveProps(nextProps){
 this.setState({open: nextProps.open});
}

componentDidMount(){
  this.setState({open: this.props.open});
}

getOpen = () => {
  this.setState({open: !this.state.open});
}

  render() {
    const { top, open, marginBottom, value } = this.props;
    return (
      <Checkbox
        lg={12}
        onClick={this.props.onClick ? this.props.onClick.bind(this, this.props.name) : this.getOpen}
        top={top}
        open={open}
        marginbottom={marginBottom}>
        <Img src={this.state.open ? True : False} />
        <div>
          <span>{value}</span>
        </div>
      </Checkbox>
    )
  }
}

CheckBox.propTypes = {
  top: PropTypes.string,
  open: PropTypes.bool,
  marginBottom: PropTypes.string,
  value: PropTypes.string
}

CheckBox.defaultProps = {
  open: false,
  value: 'Non information'
}


export default CheckBox;

const Checkbox = styled(Col)`
  font-family: HelveticaNeue;
  font-size: 14px;
  font-weight: ${props => props.open ? "700" : "300"};
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #4a4a4a;
  margin-bottom: ${props => props.marginbottom ? props.marginbottom: "0px"}
  margin-top: ${props => props.top ? props.top : "19px"};

  &:hover {
    cursor: pointer
  }
`;

const Img = styled.img`
  float: left;
  margin-right: 13px;
  width: 15px;
  height: 15px;
`;
