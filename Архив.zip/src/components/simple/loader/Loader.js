import React from 'react';
import styled from 'styled-components';
import {Loader as LoaderUI} from 'semantic-ui-react'

const Loader = () => (
    <LoaderBlock>
        <LoaderCircle active inline='centered' size='massive'>Loading</LoaderCircle>
    </LoaderBlock>
);

export default Loader;


const LoaderCircle = styled(LoaderUI)`
  margin-top: 20% !important;
`;

const LoaderBlock = styled.div`
  position: absolute;
  background-color: white;
  width: 100%;
  height: 100%;
  opacity: 0.4;
  z-index: 100;
  margin-left: -20px;
`;