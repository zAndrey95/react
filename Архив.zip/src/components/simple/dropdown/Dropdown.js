import React, { Component } from 'react'
import FontAwesome from 'react-fontawesome'
import styled from 'styled-components';
import PropTypes from 'prop-types';

class Dropdown extends Component{
    constructor(props){
        super(props);
        this.state = {
            listOpen: false,
            defaultValue: this.props.defaultValue,
            list: this.props.list,
            searchValue: '',
            keys: this.props.nameKey
        };
        this.close = this.close.bind(this)
    }

    componentDidUpdate = () => {
        const { listOpen } = this.state;
        setTimeout(() => {
            if(listOpen){
                window.addEventListener('click', this.close)
            }
            else{
                window.removeEventListener('click', this.close)
            }
        }, 0)
    };

    componentWillUnmount = () => {
        window.removeEventListener('click', this.close)
    };

    static getDerivedStateFromProps(nextProps, prevState) {
        if(nextProps.list.length <= 0) {
        } else {
            if (!nextProps.list.loading && !nextProps.defaultValue.loading) {
                const store = nextProps.list;
                const  activeName = nextProps.defaultValue
                if (store !== prevState && activeName !== prevState) {
                    return {
                        list: store,
                        defaultValue: activeName
                    }
                }
                return null
            }
            return null
        }
        return null
    };

    close = () => {
        this.setState({
            listOpen: false,
            searchValue: ''
        })
    };

    selectItem = (defaultValue, id) => {
        this.setState({
            defaultValue: defaultValue,
            listOpen: false,
            searchValue: ''
        }, this.props.activeId(id))
    };

    toggleList = () => {
        this.setState({
            listOpen: true
        })
    };

    ChangeSearch = (e) => {
        this.setState({
            searchValue: e.target.value.toLowerCase(),
        });
    };

    render(){
        const{list, listOpen, defaultValue, searchValue, keys} = this.state;
        const key1 = keys[0];
        const key2 = keys[1];

        let listArr =[];
        let off = '';
        if (!list) {
            off = undefined;
        } else {
            listArr = list.filter(updatedList => {
                return updatedList[key2].toLowerCase().includes(searchValue);
            });
        }

        return(
            <div>
                <TitleDropdown>{this.props.title}</TitleDropdown>
                <Block>
                    <DropTitle onClick={() => this.toggleList()}>
                        {listOpen
                            ? <DropTitleSearchInput value={searchValue} placeholder={defaultValue} autoFocus onChange={this.ChangeSearch}/>
                            : <DropTitleText>{searchValue ? searchValue : defaultValue}</DropTitleText>
                        }
                        {listOpen
                            ? <FontAwesome name="caret-up" style={{marginRight:'20px'}}/>
                            : <FontAwesome name="caret-down" style={{marginRight:'20px'}}/>
                        }
                    </DropTitle>
                    {listOpen &&
                        <DropUl onClick={e => e.stopPropagation()}>
                            {off === undefined
                                ? <DropLi/>
                                : listArr.map((item) => (
                                        <DropLi
                                            active={item.selected}
                                            key={item.id}
                                            onClick={() => this.selectItem(item[key2], item[key1], item.key)}>
                                            {item[key2]}
                                        </DropLi>
                                    ))
                            }

                        </DropUl>}
                </Block>
            </div>
        )
    }
}

Dropdown.propTypes = {
    list: PropTypes.oneOfType([
        PropTypes.array,
        PropTypes.object
    ]),
    defaultValue: PropTypes.string,
    activeId: PropTypes.func,
    title: PropTypes.string,
    nameKey: PropTypes.array
};

Dropdown.defaultProps = {
    list: false,
    defaultValue: '',
    activeId: '',
    title: '',
    nameKey: ['id', 'title']
};

export default Dropdown

const TitleDropdown = styled.div`
    width: 96px;
    height: 19px;
    font-family: Roboto;
    font-size: 16px;
    font-weight: 500;
    font-style: normal;
    font-stretch: normal;
    line-height: normal;
    letter-spacing: normal;
    color: #3c445a;
    margin-bottom: 6px;
`;

const Block = styled.div`
    width: 300px;
    height: 36px;
    box-shadow: 0 1px 2px 0 rgba(90, 90, 90, 0.12);
    background-color: #ffffff;
`;

const DropTitle = styled.div`
    cursor: pointer;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: justify;
    -ms-flex-pack: justify;
    justify-content: space-between;
    position: relative;
`;

const DropTitleText = styled.div`
    width: 136px;
    height: 16px;
    font-family: Roboto;
    font-size: 14px;
    font-weight: normal;
    font-style: normal;
    font-stretch: normal;
    line-height: normal;
    letter-spacing: normal;
    color: #3c445a;
    margin: 10px 128px 10px 13px;
`;

const DropTitleSearchInput = styled.input`
    width: 280px;
    height: 36px;
    border: none;
    padding-left: 13px;
    font-family: Roboto;
    font-size: 14px;
    font-weight: normal;
    font-style: normal;
    font-stretch: normal;
    line-height: normal;
    letter-spacing: normal;
    color: #3c445a;
`;

const DropUl = styled.ul`
    z-index: 10;
    position: absolute;
    width: 300px;
    padding: 0;
    max-height: 215px;
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
    box-shadow: 0 1px 2px 0 rgba(90, 90, 90, 0.12);
    background-color: #ffffff;
    font-family: Roboto;
    font-size: 14px;
    font-weight: normal;
    font-style: normal;
    font-stretch: normal;
    line-height: normal;
    letter-spacing: normal;
    color: #3c445a;
`;

const DropLi = styled.li`
    cursor: pointer;
    border-bottom: 1px solid #f5f5f5;
    padding: 10px 0 10px 13px;
    background-color: ${props => props.active ? '#f5f5f5' : '#ffffff'}
    
    &:hover {
    background-color: #f5f5f5;
`;