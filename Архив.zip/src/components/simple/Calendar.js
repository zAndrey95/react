import React, { Component } from 'react';
import {  Col } from 'react-bootstrap';
import styled from 'styled-components'
import Calendar from 'react-calendar';

import icon_calendar from '../../img/icon-calendar.svg';

class NewCalendar extends Component {
  state={
    openCalendar: false,
    date: new Date()
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    return {
      date: nextProps.date?nextProps.date:prevState.date
    }
    return null
  }

  getOpen = () => {
    this.setState({openCalendar: true});
  }

  getClose = (date) => {
    this.setState({openCalendar: false, date: date}, () => this.props.getDate(this.getFormatDate()))
  }

  getFormatDate = () =>{
    let formatDate = String(this.state.date.getFullYear()).replace(/^(.)$/, "0$1") + 
    '-'+ String(this.state.date.getMonth()+1).replace(/^(.)$/, "0$1") +
    '-' + this.state.date.getDate();
    return formatDate.slice(0, 10);
  }

  render() {
    return (
      <Col lg={12}>
        {this.state.openCalendar
          ?
            <Calendar 
              value={this.state.date}
              format='DDDD/MM/YYYY'
              onChange={this.getClose}
            /> 
          :
            <CalendarInput lg={12} onClick={this.getOpen} >
                <span>{this.getFormatDate()}</span> 
                <img src={icon_calendar}/>
            </CalendarInput>
        }
      </Col>
    )
  }
}

export default NewCalendar;

const CalendarInput = styled.div`
  height: 36px;
  border-radius: 3px;
  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.1);
  background-color: #ffffff;
  text-align: center;
  padding-top: 10px;
    img{
      width: 20px;
      height: 20px;
      float: right;
      margin:-2px 5px 0 0;
    }
`;
