import React from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'

const Line = ({width, height, backColor, marginTop, marginBottom}) => (
  <LineStyle width={width} height={height} backColor={backColor} marginTop={marginTop} marginBottom={marginBottom}/>
);

Text.propTypes = {
  width: PropTypes.string,
  height: PropTypes.string,
  backColor: PropTypes.string,
  marginTop: PropTypes.string,
  marginBottom: PropTypes.string
}

export default Line

const LineStyle = styled.hr`
  width: ${props => props.width ?  props.width : "100%"};
  height: ${props => props.height ?  props.height : "2px"};
  border: 0;
  margin: 0;
  background-color: ${props => props.backColor ?  props.backColor : "#ffffff"};
  margin-top: ${props => props.marginTop ?  props.marginTop : "20px"};
  margin-bottom: ${props => props.marginBottom ?  props.marginBottom : "20px"};
`;
