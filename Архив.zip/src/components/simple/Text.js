import React from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'

const Text = ({text, color, fontSize, fontWeight, marginBottom, padding, marginTop}) => (
  <MainText color={color} fontSize={fontSize} fontWeight={fontWeight} marginBottom={marginBottom} marginTop={marginTop}> {text} </MainText>
);

Text.propTypes = {
  text: PropTypes.string,
  color: PropTypes.string,
  fontSize: PropTypes.string,
  fontWeight: PropTypes.string,
  marginBottom: PropTypes.string,
  marginTop: PropTypes.string,
}

Text.defaultProps = {
  text: 'text'
}

export default Text

const MainText = styled.span`
  font-family: Roboto;
  font-size: ${props => props.fontSize ?  props.fontSize : "16px"};
  font-weight: ${props => props.fontWeight ?  props.fontWeight : "500"};
  margin-bottom: ${props => props.marginBottom ? props.marginBottom : "0px"}
  margin-top: ${props => props.marginTop ? props.marginTop : "0px"}
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: ${props => props.color ?  props.color : "#3c445a"};
`;

// <Text text="value" color="string" fontSize ="300px" fontWeight="500" marginBottom='20px'/>
