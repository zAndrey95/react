import React from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'




const FilterButton = ({onClick}) => (
    <ReactButton
      onClick={onClick}
    >Filter</ReactButton>
);

FilterButton.propTypes = {
  onClick: PropTypes.func
}

FilterButton.defaultProps = {
  value: 'Filter'
}

export default FilterButton

const ReactButton = styled.div`
  display: flex;
  justify-content: left;
  align-items: left;
  box-shadow: 0 1px 2px 0 rgba(90, 90, 90, 0.2);
  background-color: #f5f5f5;
  padding-left: 10px;
  height: 22px;
  :after {
    content: ''; 
    left: 2px; bottom: -2px;
    border: 5px solid transparent; 
    border-top: 5px solid #3c445a;
    margin-top: 9px;
    margin-left: 0.5vw;
  }
`;






