import React, { Component } from 'react';
import {  Col } from 'react-bootstrap';
import styled from 'styled-components';

class Input extends Component {
  state = {
    name:""
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    return {
      name: nextProps.value
    }
    return null
  }

  getValueOfInput = (event) => {
    this.setState({name: event.target.value})
  }

  render() {
    const { text,placeholder,autoFocus,ref,width,type,name,onBlur} = this.props;
    return (
      <Col lg={12}>
        {text?
          <InputText>
            {text}
          </InputText>
        :null}
        <Inputs
          placeholder={placeholder}
          autoFocus={autoFocus}
          ref={ref}
          style={{width: width}}
          type={type}
          value={this.state.value===null ? "" : this.state.value}
          onChange={this.getValueOfInput}
          onBlur={(e)=>onBlur ? onBlur(e,this.state.name) : null}
          name={name}
        />
      </Col>
    )
  }
}

export default Input;


export const InputText = styled.div`
  height: 18px;
  font-family: HelveticaNeue;
  font-size: 16px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #3c445a;
  margin: 15px 0 4px 0;
`;

const Inputs = styled.input`
  width: 100%;
  padding-left: 10px;
  height: 30px;
  border-radius: 2px;
  border: solid 1px #ffffff;
  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.1);
`;

/*
onChange={

onValueOfInput(e){
    e.preventDefault();
    this.setState(({[e.target.name]:e.target.value}));
  }

}

value={
  this.state.value

}

onBlur={

  function(){
  updeteInput();
  }

}

name={
  {"name"}
}*/
