import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import {  Col } from 'react-bootstrap';
import styled from 'styled-components';

class Input extends Component {

  render() {
      return (
          <Col lg={12}>
            <InputText>
              {this.props.text}
            </InputText>
            <Inputs
              style={{width: this.props.width}}
              type={this.props.type}
              value={this.props.value=== null ? "" : this.props.value}
              onChange={this.props.onChange}
              onBlur={this.props.onBlur}
              name={this.props.name}
              onKeyPress = {this.props.onKeyPress}
              autoFocus = {this.props.autoFocus}
            />
          </Col>
      )
  }
}

export default Input;


export const InputText = styled.div`
  height: 18px;
  font-family: HelveticaNeue;
  font-size: 16px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #3c445a;
  margin: 20px 0 4px 0;
`;

const Inputs = styled.input`
  width: 100%;
  padding-left: 10px;
  height: 30px;
  border-radius: 6px;
  border: solid 1px #ffffff;
  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.1);
`;

/*
onChange={

onValueOfInput(e){
    e.preventDefault();
    this.setState(({[e.target.name]:e.target.value}));
  }

}

value={
  this.state.value

}

onBlur={

  function(){
  updeteInput();
  }

}

name={
  {"name"}
}*/
