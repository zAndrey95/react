import React, { Component } from 'react';
import PropTypes from 'prop-types'
import styled from 'styled-components';
import DatePicker from 'react-date-picker';

import Text from '../simple/Text.js'

class Calendar extends Component {

  onChange = date => this.setState({ date })

  render() {
    const {
      text,
      color,
      fontSize,
      fontWeight,
      marginBottom,
      dateDB,
      width
    } = this.props;
    console.log(this.props);
		return (
      <div>
        <TextStyle>
          <Text text={text} color={color} fontSize ={fontSize} fontWeight={fontWeight} marginBottom={marginBottom}/>
        </TextStyle>
        <CalendarStyle
          onChange={this.props.onChange}
          value={this.props.date ? this.props.date : ''}
          width={width}
        />
      </div>

    )
  }
}

Calendar.propTypes = {
  text: PropTypes.string,
  color: PropTypes.string,
  fontSize: PropTypes.string,
  fontWeight: PropTypes.string,
  marginBottom: PropTypes.string,
  marginTop: PropTypes.string,
  dateDB: PropTypes.string
}

// Calendar.defaultProps = {
//   dateDB: new Date()
// }

export default Calendar;

const CalendarStyle = styled(DatePicker)`
  background-color: white;
  box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.1);
  height: 30px;
  width: ${props => props.width ? props.width : '140px'}
`;

const TextStyle = styled.div`
  margin-top: 17px;
`;
