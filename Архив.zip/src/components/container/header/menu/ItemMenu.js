import React, { Component } from 'react';

import img from '../../../../style/img/img.png'


class ItemMenu extends Component {
  render() {
    return (
        <div className="icon">
          <div className="shape">
            <img src={this.props.icon} alt=""/>
          </div>
          <p style={{color: this.props.color}}>{this.props.iconText}</p>
        </div>
    );
  }
}

export default ItemMenu;
