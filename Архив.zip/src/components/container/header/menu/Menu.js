import React, { Component } from 'react';
import { NavLink} from 'react-router-dom';
import {Row, Col} from 'react-bootstrap';

import ItemMenu from './ItemMenu.js';

import customer from '../../../../style/img/icon_customer.svg'
import debitor from '../../../../style/img/debitor_color.svg'
import offer from '../../../../style/img/offer.svg'
import statistic from '../../../../style/img/statistic.svg'
import order from '../../../../style/img/order.svg'
import article from '../../../../style/img/article.svg'
import production from '../../../../style/img/production.svg'
import invoice from '../../../../style/img/invoice.svg'
import options from '../../../../style/img/options.svg'

//import redcustomer from '../../img/redcustomer.svg'
//import redarticle from '../../img/redarticle.svg'
//import redoffer from '../../img/redoffer.svg'
//import redorder from '../../img/redorder.svg'
//import redproduction from '../../img/redproduction.svg'
//import redinvoice from '../../img/redinvoice.svg'
//import reddebitor from '../../img/reddebitor.svg'
//import redstatistic from '../../img/redstatistic.svg'
//import redoptions from '../../img/redoptions.svg'


import './Menu.css';

class Menu extends Component {
  state = {
      index: 0
  };

  getIndex = (index) => {
    this.setState({index: index})
  }

  render() {
    //const redicons =[redcustomer, redarticle, redoffer, redorder, redproduction, redinvoice, reddebitor, redstatistic, redoptions]
    const links =["/customers/3/adresse", "/products", "/offer/create", "/order/create", "/production/print/production", "/invoice/", "/debitor/", "/statistic/", "/options/"]
    const icons =[customer, article, offer, order, production, invoice, debitor, statistic, options]
    const texts =["Customer", "Article", "Offer", "Order", "Production", "Invoice", "Debitor", "Statistic", "Options"]
    const items = ["","","","","","","","",""];
    const widths = ["11.11%","11.11%","11.11%","11.11%","11.11%","11.11%","11.11%","11.11%","11.11%"]
    const itemsMap = items.map((item, index)=>{
      const width = widths[index];
      const icon = icons[index];
      const text = texts[index];
      const link = links[index];
      //const redicon = redicons[index];
        return(
          <NavLink key={index} to={link} activeClassName="selected" onClick={this.getIndex.bind(this, index)}>
            <div className="linkHeader" style={index>6?{height: "96px",'minWidth':`${width}`, float: "left", background: "#2e3941",background: "grey"}:{height: "96px",'minWidth':`${width}`, float: "left", background: "#2e3941",}}>
                <ItemMenu color = {index==this.state.index? "#ff4b57": "white"}  iconText={text} icon={icon}/>
            </div>
          </NavLink>
        )
    })

    return (
      <div style={{height: "96px",'minWidth': "100%"}}>
        {itemsMap}
      </div>
    )

  }
}

export default Menu;
