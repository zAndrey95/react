import React, { Component } from 'react';
import {Row, Col} from 'react-bootstrap';

import Menu from './menu/Menu.js';

import './Header.css';


class Header extends Component {
  render() {
    return (

      	<Row>
		    <Col lg={12}>
            	<Menu/>
         	</Col>
		</Row>


    );
  }
}

export default Header;
