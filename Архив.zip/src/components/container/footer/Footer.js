import React, { Component } from 'react';

import Text from '../../simple/Text';

import './Footer.css';

class Footer extends Component {

  constructor(props) {
    super(props);
    this.state = {
      index: 0
    };
  }

  getIndex = (index) => {
    this.setState({index: index})
  }

  render() {
    const items = [ "",
                  <Text top="12px" size="20px" color="#ee5a5d" text="Factura Assist"/>,
                  <Text top="5px" borderW="3px" height="30px" border="1"/>,
                  <div><Text color="white" border="1"  top="15px" height="30px" size="14px" text="live Chat"/></div>,
                  <div><Text color="white" size="14px"  top="15px" height="30px" text="Support  Screencoct"/></div>,
                  ""];
    const widths = ["2%", "7%","69%","8%","12%","2%"]
    const itemsMap = items.map((item, index)=>{
      const width = widths[index];
      //const redicon = redicons[index];
        return(
          <div  key={index} style={{height: "30px",'minWidth':`${width}`, float: "left", background: "#2e3941"}}>
            <div onClick={this.getIndex.bind(this, index)} color = {index===this.state.index? "#ff4b57": "white"}>
              {item}
            </div>
          </div>
        )
    })

    return (
      <div style={{height: "50px",'minWidth': "100%", background: "#2e3941", 'margin-top': '20px'}}>
        {itemsMap}
      </div>
    )
  }
}

export default Footer;
