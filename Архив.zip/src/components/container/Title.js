import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import {  Col } from 'react-bootstrap';
import styled from 'styled-components';

import './Title.css';

class Title extends Component {


  render() {
      	return (
          	<Col lg={12} style={{padding: "0px 0 2px 0", "margin-top": `${this.props.top? this.props.top : "15px"}`}} className="title">
            	<div>{this.props.text}</div>
          	</Col>
    	)
  	}
}


export default Title;