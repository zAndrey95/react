import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import { Row, Col } from 'react-bootstrap';
import styled from 'styled-components';

import dropdown_Open from '../../../../../../img/dropdown_Open.png';

import './InputWithDropdown.css'


export const InputText = styled.div`
  height: 18px;
  font-family: HelveticaNeue;
  font-size: 16px;
  font-weight: 300;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #6e6e6e;
  margin: 20px 0 4px 0;
`;

const Inputs = styled.input`
  width: 100%;
  border: none;
  border-bottom: 1px solid rgba(76, 76, 76, 0.08);
  background-color: #ffffff;

`;



class InputWithDropdown extends Component {
  constructor(props) {
    super(props);
    this.state={
      open: true,
      list: [],
      values: '',
      background: "#67adff",
    }
    this.myRef = React.createRef();
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    return {
      list: nextProps.list,
      inputValue: nextProps.inputValue
    }
  }

  onSelect = (index,item) => {
    console.log(index)
    console.log(item)
    this.props.onClickInputWithDropdown(index,item)
    this.props.closeInput();
    
  }

  closeInput = () =>{
    this.setState({open: false});
  }




getOpen = (e) => {
    this.props.changeValue(e);
    this.setState({open: true});   
  }

  render() {
    const dropDown = this.state.list.map((item, index) => {
      return (
        <React.Fragment key={item.Intern}>
          <div 
            style={
              this.props.next?
              this.props.gruppeId||this.props.gruppeId===0?
              this.state.list[index].id===this.state.gruppeId?{background:'#67adff'}:
              !Number.isInteger(index/2)?
              {background:"white"}:
              {background:"#edf5ff"}:
              index==this.props.gruppeId-1?
              {background:'#67adff'}:
              !Number.isInteger(index/2)?
              {background:"white"}:
              {background:"#edf5ff"}:
              ///////////////////////
              this.state.index||this.state.index===0?
              index===this.state.index?{background:'#67adff'}:
              !Number.isInteger(index/2)?
              {background:"white"}:
              {background:"#edf5ff"}:
              index==this.props.gruppeId-1?
              {background:'#67adff'}:
              !Number.isInteger(index/2)?
              {background:"white"}:
              {background:"#edf5ff"}
            }
            
            onClick={this.onSelect.bind(this, index, item)}
          >
            <span  className='span_dropdown1'>{item.ArtikelNr}</span> 
          </div>
        </React.Fragment>
      )
    }
  );
      return (
            <Row style={{ padding: "0 0 25px 0"}} style={{display: this.props.display, textAlign: 'center'}}  ref={this.props.ref}>
              <Col lg={12} tabIndex="1">
                <div className="dropDownInput" style={this.props.style}>
                  <Inputs 
              style={{width: this.props.width}}
              type={this.props.type}
              value={this.props.inputValue === null ? "" : this.props.inputValue}
              onChange={this.getOpen}
              onBlur={this.props.onBlur}
              name={this.props.name}
              placeholder={this.props.placeholder}
              autoFocus={true}
            />
                     {this.state.open ? <img alt="" style={this.state.open?{'transform':'rotateX(180deg)'}:null}  className="relay" src={dropdown_Open} onClick={this.closeInput}></img> : null}
                  <div className={this.state.open ? "openWithInputs" : "close"}>
                    <div>
                      {dropDown}
                    </div>
                  </div>
                </div>
              </Col>
              
            </Row>
      )
  }
}

export default InputWithDropdown;



