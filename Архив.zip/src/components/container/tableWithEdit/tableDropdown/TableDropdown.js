import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import {  Col, Row } from 'react-bootstrap';
import styled from 'styled-components';

import search from '../../../../../../img/search1.svg'
import edit from '../../../../../../img/edit.svg'

import './Table.css';




class Table extends Component {
  constructor(props) {
    super(props);
    this.state = {
      index:''
    }
  }


  onClick=(index)=>{
    this.setState({index})
    this.props.onClick(index)
  }
  render() {

    const arr = this.props.arr.map((row, index) => {
      return (
        
        <Col
          onClick={ this.onClick.bind(this,index)}
          style={{"text-align": this.props.align?this.props.align:"center", borderLeft: index==this.state.index ? "12px solid #3c445a": "12px solid #cdcdcd"}}
          className="tabRow"
          lg={12}
          key={index}>
          <Row>
            <Col lg={this.props.delete?11:12}>
              {this.props.arr[index].map((col, id)=>{
                const width = this.props.widths[id];
                return(
                  <div style={{'width':`${width}`, float: "left", padding: "10px 0 0 9px" }} key={id}>{col ? col : '-'}</div>
                )
              })}
            </Col>
            {this.props.delete?<Col lg={1}><Col lg={6}  className="editTable"><img onClick={this.props.edit?this.props.edit.bind(this, index):null} src={edit}/></Col><Col lg={6}  className="deleteCustomer"><div onClick={this.props.delete?this.props.delete.bind(this, index):null}>x</div></Col></Col>:null}
          </Row>

        </Col>
        
      )
    })


    const names = this.props.names.map((item, index)=>{
      const width = this.props.widths[index];
        return(
          <div
            className="headerTable"
            key={index}
            style={{"text-align": this.props.align?this.props.align:"center",'min-width':`${width}`, float: "left", padding: "10px 0 0 9px", height: "37px", "border-bottom": "1px solid #e0e0e0", background: "#3c445a" }}>
            {item}
          </div>
        )
    })

    return (
      <div>
        <Col lg={this.props.delete?11:12}>{names}</Col>{this.props.delete?<Col style={{height: "36px",background: "#3c445a"}} lg={1}></Col>:null}

        <Row>
          <Col lg={12} className="input-search">
              <Col lg={11}>
                <input className="search_main" placeholder="Search" onChange={ this.props.getSearchValue} value={this.props.searchValue} name="searchValue"/>
              </Col>
               <Col lg={1} className="element_search">
                <img src={search} alt=""/>
              </Col>
          </Col>
        </Row>
        <Col lg={12} id="q" className="ys">
        {arr}
        </Col>
      </div>
    )
  }
}

export default Table;
