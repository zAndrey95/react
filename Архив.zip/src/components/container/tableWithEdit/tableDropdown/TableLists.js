import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import {  Col, Row } from 'react-bootstrap';
import styled from 'styled-components';

import edit from '../../../../../../img/edit.svg'




class TableLists extends Component {
  


  
  render() {
  	console.log(this.props)
  	const array = this.props.sortByArticles.map((item,index)=>{
  		console.log(item)
  		return (
  			<Col lg={12}>
      			<Col lg={1}>
      				<img src={edit}/>
      			</Col>
	      	<Col lg ={11}>
	      		<span> {item[0].ArtikelNr}</span>
	      	</Col>
	      </Col>
	  	);
  	})
    return array
  }
}

export default TableLists;
