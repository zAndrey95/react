import React, { Component } from 'react';
import { graphql, compose } from 'react-apollo';
import { withApollo } from 'react-apollo'
import {  Col } from 'react-bootstrap';
import styled from 'styled-components';
import Calendar from 'react-calendar';

import icon_calendar from '../../../../../../img/icon-calendar.svg';


const Block = styled.div`
`;



const Inputs = styled.input`
  height: 30px;
  border-radius: 6px;
  border: solid 1px #d2d2d2;
`;



class CalendarReact extends Component {

  constructor() {
    super();
    this.state= {
      openCalendar:false,
      date: new Date()
    }
  }

   onChangeCalClose = (date) => {
    this.state.date = date;
    this.setState({ openCalendar: false})
    this.props.getDateFromCalendar(this.getFormatDate());

  };

  getFormatDate = () =>{
    let formatDate = String(this.state.date.getFullYear()).replace(/^(.)$/, "0$1") + 
      '-'+ String(this.state.date.getMonth()+1).replace(/^(.)$/, "0$1") +
      '-' + this.state.date.getDate();
      return formatDate;
  }

  onChangeCalOpen = () => this.setState({openCalendar: true });

  nextDate = () => {
      this.state.date = new Date(this.state.date.getFullYear(), 
        this.state.date.getMonth(),
         this.state.date.getDate()+1)

     this.props.getDateFromCalendar(this.getFormatDate());
  };

  prevDate = () => {
      this.state.date = new Date(this.state.date.getFullYear(), 
        this.state.date.getMonth(), 
        this.state.date.getDate()-1)
     this.props.getDateFromCalendar(this.getFormatDate());
  };
  componentDidMount(){
    this.props.getDateFromCalendar(this.getFormatDate());
  }

  render() {
    let day = String(this.state.date.getDay()).replace(/^(.)$/, "0$1");
      return (
               
            <div>
              {this.state.openCalendar?<Calendar 
              value={this.state.date}
              format='DDDD/MM/YYYY'
              onChange={this.onChangeCalClose}/>: 
              <Col lg={12} md={12} sm={12} xs={12} className='grey_background' style={{margin: '20px 0 6px 0', paddingBottom:'8px'}} >
                <Col lg={5} md={5} sm={5} xs={5} className="data_on_calendar" onClick={this.onChangeCalOpen} style={{marginLeft: '8px'}}>
                 <span>{String(this.state.date.getFullYear()).replace(/^(.)$/, "0$1") + 
                        '-'+ String(this.state.date.getMonth()+1).replace(/^(.)$/, "0$1") +
                        '-' + this.state.date.getDate()}
                  </span> 
                  <img src={icon_calendar} style={{width: "20px", height: '20px', margin:"-7px 0 0 28px"}}/>
                </Col>
                <Col lg={1} md={1} sm={1} xs={1}></Col>
                <Col lg={4} md={4} sm={4} xs={4} className="day_on_calendar" style={{margin: '0px 0px 12px 25px'}}>
                  <span className={'controlDayCalendarPrev'} onClick={this.prevDate}>{"<"}</span>
                    <span style={{color: '#1c1547'}}>{ day==0?'Sunday':
                    day==1?'Monday':
                    day==2?'Tuesday':
                    day==3?'Wednesday':
                    day==4?'Thursday':
                    day==5?'Friday ': 
                    'Saturday'}
                    </span>
                  <span onClick={this.nextDate} className={'controlDayCalendarNext'} >{">"}</span>
                </Col>
                <Col lg={1} md={1} sm={1} xs={1}></Col>
              </Col>}
                      </div>
          
      )
  }
}


export default CalendarReact



