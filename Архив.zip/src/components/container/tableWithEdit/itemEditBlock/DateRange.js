import React, { Component } from 'react';
import { graphql, compose } from 'react-apollo';
import { withApollo } from 'react-apollo'
import {  Col } from 'react-bootstrap';
import Calendar from '../../../../../../@appElements/calendar/Calendar.js'

import icon_calendar from '../../../../../../img/icon-calendar.svg';




class DateRange extends Component {

  

  render() {
   
      return (
               
            <Col lg={12} md={12} sm={12} xs={12} className='grey_background' style={{margin: '20px 0 6px 0'}} >
            <Col lg={5}>
              <Calendar getDate={this.props.getDate}/>
             </Col>
             <Col lg={5} lgOffset={1}>
              <Calendar getDate={this.props.getSecondDateFromCalendar}/>
             </Col>
            </Col>
          
      )
  }
}


export default DateRange



