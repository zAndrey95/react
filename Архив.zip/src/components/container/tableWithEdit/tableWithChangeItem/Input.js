import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import {  Col } from 'react-bootstrap';
import styled from 'styled-components';

import './Table.css'

export const InputText = styled.div`
  height: 18px;
  font-family: HelveticaNeue;
  font-size: 16px;
  font-weight: 300;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #6e6e6e;
  margin: 20px 0 4px 0;
`;





class Input extends Component {

  render() {
      return (

          <Col lg={12} style={{marginLeft: this.props.left}}>{
            this.props.text ?
              <InputText>
                {this.props.text}
              </InputText> :
            null}
            <input 
              className="table_with_change_input"
              style={{width: this.props.width, display: this.props.display, height: this.props.height?this.props.height:"30px", textAlign: 'center'}}
              type={this.props.type}
              value={this.props.value=== null ? "" : this.props.value}
              onChange={this.props.onChange}
              onBlur={this.props.onBlur}
              name={this.props.name}
              ref={this.props.getRef}
              placeholder={this.props.placeholder}
              autoFocus = {this.props.autoFocus}
              step={this.props.step}
              onClick={this.props.onClick}
              onKeyPress = {this.props.onKeyPress}
            />
          </Col>
      )
  }
}

export default Input;

/*
onChange={

onValueOfInput(e){
    e.preventDefault();
    this.setState(({[e.target.name]:e.target.value}));
  }

}

value={
  this.state.value

}

onBlur={

  function(){
  updeteInput();
  }

}

name={
  {"name"}
}*/


