import React, { Component} from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'
import {  Row, Col} from 'react-bootstrap';
import { NavLink } from 'react-router-dom'

import Text from '../simple/Text';

import './Title.css'

class Menu extends Component {
  render() {
    const {menuObj, className, isAddition, text} = this.props;
    const menuLink = menuObj.map((item, index)=>{
      return (
        <Col lg={item.col ? item.col : 12 / menuObj.length}>
          <ActiveLink isAddition={isAddition} to={item.link}>
            <LinkButton isAddition={isAddition}> {item.name}</LinkButton>
          </ActiveLink>
        </Col>
      );
    });
    return (
      <div>
        {text ? <div>
          <Text text={text} fontSize="24px" color="#3c445a"/>
        </div> : null}
        <div>
          {menuLink}
        </div>
      </div>
    );
  }
}

Menu.propTypes = {
  isAddition: PropTypes.bool,
  className: PropTypes.string,
  text: PropTypes.string
}

Menu.defaultProps = {
  menuObj: [{
    name: 'name',
    link: 'link'
  }]
}

export default Menu

const LinkButton = styled.button`
  background-color: ${props => props.isAddition ?  'transparent' : '#2e3941'};
  transparent: ${props => props.isAddition ?  'transparent' : '#2e3941'};
  box-shadow: ${props => props.isAddition ?  'none' : '0 2px 2px 0 rgba(90, 90, 90, 0.2)'};
  width: 100%;
  height: 36px;
  text-align: center;
  font-size: 16px;
  border: none;
  &.active{
    background-color: ${props => props.isAddition ?  'transparent' : '#2e3941'};
  }
`;

const ActiveLink = styled(NavLink)`
  color: ${props => props.isAddition ?  '#3c445a' : '#ffffff'};
  border-bottom: ${props => props.isAddition ?  '2px solid #2e3941' : 'none'};
  padding-bottom: ${props => props.isAddition ?  '8px' : '0'};
  opacity: ${props => props.isAddition ? '0.5' : '1'};
  &.active{
    opacity: 1;
    color: ${props => props.isAddition ? '#3c445a' : '#c13c44'};
  }
`;
