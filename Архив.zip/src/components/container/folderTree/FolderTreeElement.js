import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import {  Col } from 'react-bootstrap';
import styled, {withTheme} from 'styled-components';


class OrderGroup extends Component {

  constructor() {
    super();
    this.state={
      open: false,
      openSubFolder: false
    }
  }

  componentWillReceiveProps(nextProps){
    this.setState({open: nextProps.open});
  }

  getOpen = () => {
    this.setState({open: !this.state.open});
    
  }

  getElement = () =>{
    this.props.changeFolderName(this.props.elementId, !this.state.open);
  }

  getOpenSubFolder = () => {
    this.setState({openSubFolder: !this.state.openSubFolder});
  }

  render() {    
    return (
      <div  onClick={this.props.onClick}>
        <Checkbox lg={12} onClick={this.getOpen} style={{marginTop: '3px', marginLeft: this.props.left}}>
        <BorderCheckBox lg={3} style={{marginTop: '3px'}}>
          <Middle style={this.state.open ? {  'backgroundColor': '#7ed321'} : {'backgroundColor': 'initial'}}/>
        </BorderCheckBox>
        <Col lg={9} style={{margin: "3px 0 0 0"}}>
          <Text open={this.state.open} color={this.props.color} onClick={this.getOpen}> {this.props.text}</Text>
        </Col>
      </Checkbox>
        
      </div>
    )
  }
}

export default OrderGroup;

const Checkbox = styled(Col)`
  font-family: HelveticaNeue;
  font-size: 16px;
  font-weight: 300;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  color: #4a4a4a;
`;

const BorderCheckBox = styled(Col)`
  width: 15px;
  height: 15px;
  border: solid 1px #bebebe;
  -moz-border-radius: 8px;
  -webkit-border-radius: 8px;
  border-radius: 8px
`;

const InputText = styled.div`
  height: 18px;
  font-family: HelveticaNeue;
  font-size: 16px;
  font-weight: 300;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #6e6e6e;
  margin: 20px 0 4px 0;
`;

const Middle = styled.div`
  margin-top:2.7px;
  width: 7.5px !important;
  height: 7.5px !important;
  margin-left: 2.7px !important;
  border-radius: 8px;

`;

const SquareBorder = styled.div`
  margin-right: 2px !important;
  width: 12px;
  height: 12px;
  border: 2px solid ${props => props.color};
  margin-top: 3px;
  float: left;
  ;
`;

const SquareInside = styled.div`
  height: 100%;
  background: ${props => props.open ? '#99d5d7' : '#fff'};
`;

const Text = styled.div`
  font-size: 14px;
  font-weight: ${props => props.open ? "600" : "300"}
  padding: 0 0 10px 6px;
  font-family: HelveticaNeue;
`;

