import React, { Component } from 'react';
import styled from 'styled-components';
import {  Col, Row } from 'react-bootstrap';

import Table from '../table/Table'
import Text from '../../simple/Text'
import Button from '../../simple/Button'
import FilterButton from '../../simple/FilterButton'

class Items extends Component {
  render() {
    const {filterBtn, isfilterButton, name, firstBtnName, secondBtnName } = this.props;
    return (
      <div>
        <Row>
          <Col lg={10}>
            <Text text={name} fontSize="24px" color="#3c445a"/>
          </Col>
          {filterBtn ?<Col lg={2}>
            <FilterButton/>
          </Col> : null}
        </Row>

        {isfilterButton ?
          <div>
            <ShadowBlock>
              <Table
                {...this.props}
                minHeight = '57vh'
              />
            </ShadowBlock>
            <div style={{padding: '18px 0px 18px 0px'}}>
              <Button value={firstBtnName}/>
            </div>
            <div>
              <Button className='transparent' value={secondBtnName}/>
            </div>
          </div> : null }
      </div>
    );
  }
}

export default Items;

const ShadowBlock = styled.div`
  box-shadow: 0 1px 1px 1px rgba(76, 76, 76, 0.08);
`;

/*
  <Items
    name="Order"
    names={['Id', 'Order']}
    widths = {['25%', '75%']}
    float= {["left", "left"]}
    align="left"
    arr={newArr}
    getSearchValue={this.changeSearch}
    searchValue=''
    onClick = this.func
    filterBtn = bol - is filterButton
    isfilterButton = bol  - filterButton status (for change components)

          />
*/
