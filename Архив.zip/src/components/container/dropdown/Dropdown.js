import React, { Component } from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types'


import {InputText} from '../../simple/Input'

class Dropdown extends Component {
  state={isOpen: false, search: ''}

  openDropdown = (e) => { this.setState({isOpen: !this.state.isOpen}) }

  closeDropdown = (index, item) => {
    this.props.getDropdownIndex(index, item)
    this.setState({isOpen: false})
  }

  getDbName = (item, dbName, secondDbName) =>{
    if( secondDbName){
      return `${item[dbName]} ${item[secondDbName]} `
    }
    if(dbName){
      return item[dbName]
    }
    else return 'Ops'
  }

  render() {
    const { isOpen,search } = this.state;
    const { text, list,dbName, chooseItem,secondDbName, width, noOpen} = this.props;
    const arrayList = list.map((item, index)=>{
      return <DropdownItem onClick={this.closeDropdown.bind(null, index, item)} isChoose={index === this.props.index}> {this.getDbName(item, dbName, secondDbName)}</DropdownItem>
    })

    return (
      <div>
        {text ? <InputText >{text} </InputText> : null}
        <MainDropdown noOpen={noOpen} width={width} onClick={noOpen ? null : this.openDropdown} isOpen={isOpen}> <DropdownInnerText> {chooseItem} </DropdownInnerText></MainDropdown>
        {isOpen && <DropdownBlock> {arrayList}</DropdownBlock> }
      </div>
    );
  }
}

export default Dropdown;

const DropdownBlock = styled.div`
  width: 100%;
  z-index: 20;
  overflow-y: scroll;
  height: 180px;
  background: #fff;
  position: absolute;
  box-shadow: 0 1px 2px 0 rgba(90, 90, 90, 0.12);
  margin-top: ${props => props.topDrop ?  '-120px': "0px"};
  display: inline-block;
`;

const DropdownItem = styled.div`
  width: 100%;
  height: 37px;
  border-bottom: 1px solid #f5f5f5;
  background-color: ${props => props.isChoose ?  '#f5f5f5': '#ffffff'};
  font-weight: ${props => props.isChoose ?  '600': '500'};
  padding: 10px;

`;

const MainDropdown = styled.div `
  box-shadow: 0 1px 2px 0 rgba(90, 90, 90, 0.12);
  background-color: ${props => props.noOpen ?  '#f5f5f5f5': '#ffffff'};
  width: ${props => props.width ?  props.width : '100%'};
  height: 36px;

`;

const DropdownInnerText = styled.div `
  padding: 10px 0px 16px 10px;
  font-size: 15px;
  display: inline-block;

`;

const Triangle = styled.div`
    display: inline-block;
    border: 6px solid transparent;
    border-top: 8px solid #3c445a;
    margin-top: 14px;
    position: absolute;
    margin-left: 100px;
`;

Dropdown.propTypes = {
  list : PropTypes.array.isRequired, // u main array list
  getDropdownIndex: PropTypes.func.isRequired, // func with params index.
  chooseItem: PropTypes.string.isRequired, // choose position in u dropdown.
  index: PropTypes.number.isRequired, // Index of choose list. Save in parent component
  text: PropTypes.string,  //upper text
  dbName: PropTypes.string // Its name of obj key
}

Dropdown.defaultProps = {
  list: [1,2,3],
  getDropdownIndex: ()=>{ console.log('Add func getDropdownIndex(i) in u parent component')}
}

/*
  *SOME ABOUT DROPDOWN (Simply... We must create new =-))
    * U must save state of drop in parent cmpnt P.S dont now is`t true))
    * Its can take simple array [], or array with obj [{}]. Use dbName only on OBLECT!
    * When chooseItem havent in list, send simply request in DB and then push its db item in u list on firts position
  *
*/
