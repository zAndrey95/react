 export const namesArray = [
  'Customer No', 
  'Name', 
  'Addition', 
  'Street', 
  'Zip code',
  'Town'
];

export const phoneArray = [
  {
    'name': 'Phone 1',
    'dbName': 'TelefonG'
  },
  {
    'name': 'Phone 2',
    'dbName': 'TelefonGII'
  },
  {
    'name': 'Phone 3',
    'dbName': 'TelefonP'
  },
  {
    'name': 'Fax',
    'dbName': 'Fax'
  },
  {
    'name': 'Natel',
    'dbName': 'Natel'
  },
  {
    'name': 'Email',
    'dbName': 'Email'
  }
];

export const headText = "Informationen";
