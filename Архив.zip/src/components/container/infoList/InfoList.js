import React, { Component } from 'react';
import {  Row, Col} from 'react-bootstrap';
import { graphql, compose } from 'react-apollo';
import { Query } from 'react-apollo'
import styled from 'styled-components';

import {namesArray, phoneArray, headText} from './Data'
import Text from '../../simple/Text'

import getOrderHead from '../../../functions/query/order/getOrderHead.js'

class InfoList extends Component {
  state = {
    id: 3
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if(!nextProps.id) {return null}
    return {
      id: nextProps.id
    }
  }

  render() {
    return (
      <Query
        query={getOrderHead}
        variables={{id: this.state.id}}
      > 
        {({ loading, error, data, refetch, networkStatus }) => {
          if (networkStatus === 4) return "Refetching!";
          if (error) return `Error!: ${error}`;
          let adress = data.getOrderHead ? data.getOrderHead[0].Address.split('\r\n') : [];
          const mainData = data.getOrderHead ? data.getOrderHead[0] : [];
          const adressArray = namesArray.map((item,index)=>{
            return (
              <ListLine key={item.Intern} className={index % 2 !== 0 ? 'paired' : null}>
                <Col lg={3}>
                  <span>{item} :</span>
                </Col>

                <Col lg={9}>
                  <StrongText> {adress[index]? adress[index] : '-'}</StrongText>
                </Col>
                   
              </ListLine>
            );
          });
          const locPhoneArray = phoneArray.map((item,index)=>{
            return (
              <ListLine className={index % 2 !== 0 ? 'paired' : null} key={item.Intern}>
                <Col lg={2}>
                  <span>{item.name} :</span>
                </Col>

                <Col lg={10}>
                  <StrongText> {mainData[item.dbName] ? mainData[item.dbName] : '-'}</StrongText>
                </Col>
              </ListLine>
            );
          });
          return ( 
            <MainBlock>
              <div>
                <Col lg={12} style={{padding: '20px 0px 6px 0px'}}>
                  <Text text={headText} fontSize ="16px" fontWeight ={600}/>
                </Col>
                <Col lg={4}>
                  {adressArray}
                </Col>
                <Col lg={4} >
                  <Col lg={11} lgOffset={1} >
                      {locPhoneArray}
                  </Col>
                </Col>
              </div>
            </MainBlock>

          );
        }}
      </Query>
    );
  }
}

export default InfoList;

const ListLine = styled.div`
  font-family: Roboto;
  height: 32px;
  padding: 10px 0 0 10px;
  border-bottom: 1px solid #ffffff;
  font-weight: 300;
  background-color: rgba(195, 195, 195, 0.2);
  &.paired{
    background-color: #fff;
  }
`;

const StrongText = styled.span`
  font-family: Roboto;
  font-size: 14px;
  font-weight: 600;
  color: #3c445a;
`;

const MainBlock = styled(Row)`
  box-shadow: 0 2px 2px 0 rgba(90, 90, 90, 0.2);
  background-color: #f5f5f5;
  padding: 5px 0px 20px 0px;
  margin:0;
}
`;




// <InfoList id={Int!}>

/*Get information from database, table FacturaKundle;
  Information in filed Adress send into string with /n/r, so I used 2 arrays;
  To change names of colons or some information edit file Data.js in this folder;
*/


