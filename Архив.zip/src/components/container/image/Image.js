import React, { Component } from 'react';
import { Col } from 'react-bootstrap';
import styled from 'styled-components';
import PropTypes from 'prop-types'

import Text from '../../simple/Text'


Text.propTypes = {
  value: PropTypes.string,
}

class Images extends Component {

  render() {
    const {value, srcImage} = this.props;
      return (
          <Body lg={12}>
            <Text text={value} />
            <BlockImage
              srcImage={srcImage}>
              <ShadowBlock>
                <SpanText>Delete Edit</SpanText>
              </ShadowBlock>
            </BlockImage>
          </Body>
      )
  }
}

export default Images;

const Body = styled(Col)`
  margin-top: 20px;
`;

const Img = styled.img`
  width: 300px;
  height: 140px;
  background-color: rgba(0, 0, 0, 0.8);
`;

const ShadowBlock = styled.div`
  display: none;
  background-color: rgba(0,0,0,0.8);
  position: absolute;
  height: 100%;
  width: 100%;
  left:0;
`;

const SpanText = styled.span`
  margin-left: 100px;
`;

const BlockImage = styled.div`
  width: 300px;
  height: 140px;
  background-image: url(${props => props.srcImage});
  background-repeat: no-repeat;
  background-position: left;
  position: relative;

  &:hover ${ShadowBlock} {
      display: block;
      padding-top: 60px;
  }
`;
