import React, { Component } from 'react';
import {  Col, Row } from 'react-bootstrap';

import edit from '../../../style/img/edit.svg'

class TableRow extends Component {

  renderSwitch = (props) =>{
    switch (props.columnIndex) {
      case 0:
        return <input  value ={props.data[props.rowIndex].ArtikelNr}/>
      case 1:
        return <input  value ={props.data[props.rowIndex].Menge}/>
      case 2:
        return <input  value ={props.data[props.rowIndex].Bezeichnung}/>
      case 3: 
        return <img src={edit}/>
      case 4:
        return <div> {props.data[props.rowIndex].PreisLieferung}</div>
      case 5:
        return <div> {props.data[props.rowIndex].Total}</div>
      case 6:
        return <div> {props.data[props.rowIndex].RabattP}</div>
      case 7:
        return <div> {props.data[props.rowIndex].MWStCode}</div>
      case 8:
        return <div> {props.data[props.rowIndex].MWStCode}</div>
    }

  }
  render() {
    const {key, style, rowIndex, columnIndex, list} = this.props;
    return (
      <div key={key} style={style}>
        {this.renderSwitch(this.props)}         
      </div>

    )
  }
}

export default TableRow;


/*<div>
    <div style={{'width':'10%', float: "left", padding: "6px 0 0 9px" }} >
    { this.state.index === index ?
    <InputWithDropdown
      changeValue={this.props.changeInputWithDropdownValue}
      onClickInputWithDropdown={this.props.onClickInputWithDropdown}
      inputValue = {item.ArtikelNr}
      text="ArtikelNr" 
      style={{zIndex: 99999 - index}} 
      list={this.props.list} 
      gruppeId={1} 
      onChange={this.props.changeInputWithDropdownValue.bind(this, index)}
      deleteDropDown={null} 
      addDropDown={null} 
      updeteDrop={null}
      ref = {this.textInput}
      placeholder='Article'
      closeInput={this.closeInput}
    />
    :
    <Input  
      type="text" 
      value={item.ArtikelNr} 
      width = '100%'
      placeholder='ArtikelNr'
      onClick={this.getRowIndex.bind(null, index)}
    />
  }
    </div>
    <div style={{'width':'10%', float: "left", padding: "6px 0 0 9px" }} >
    <Input  
      type="number" 
      value={item.Menge} 
      name="Menge" 
      onBlur={this.changeInputWithoutDroponBlur.bind(this, 'quantityIndex')} 
      onChange={this.props.changeTableByInput.bind(this, index)}
      width = '100%'
      step={1} 
      placeholder='Quantity'
      autoFocus = {index==0? true:null}
      onKeyPress={onPressEnter}
      getRef={(input) => {mergeInput[index] = input}}
    /> 
    </div>
    <div style={{'width':'20%', float: "left", padding: "6px 0 0 9px" }} >
    {
      false?
      <InputWithDropdown
        testFunctionToInput= {this.props.testFunctionToInput}
        onClickInputWithDropdown={this.onClickInputWithDropdown}
        changeValue={this.props.changeInputWithDropdownValue.bind(this)}
        inputValue = {item.Bezeichnung.substring(0, 25)}
        text="Group" 
        style={{zIndex: 99999 - index}} 
        list={this.props.list} 
        gruppeId={1} 
        onBlur={this.changeInputWithoutDroponBlur.bind(this, 'desIndex')} 
        deleteDropDown={null} 
        addDropDown={null} 
        updeteDrop={null}
        ref = {this.textInput}
        placeholder='Bezeichnung'
      /> :
      <div>{item.Bezeichnung} </div>
    }
      </div>
  <div style={{'width':'10%', float: "left", padding: "6px 0 0 9px" }} >
  <img style={{width:'26px', height: "25px"}} src={edit} onClick={this.props.deleteTable}/>
  </div>
  <div style={{'width':'10%', float: "left", padding: "6px 0 0 9px" }} >
  <Input  
      type="text" 
      value={item.PreisLieferung} 
      name="PreisLieferung" 
      onChange={this.props.changeTableByInput.bind(this, index)}
      width = '100%'
      placeholder='Price'
    /> 
    </div>
    <div style={{'width':'10%', float: "left", padding: "6px 0 0 9px" }} >
  <div style ={{color: item.Menge <0 ? "#d0021b" : null, width: '100%'}}> {item.Total ? item.Total: 0}</div> 
  </div>
  <div style={{'width':'10%', float: "left", padding: "6px 0 0 9px" }} >
  <Input  
      type="text" 
      value={item.RabattP ? item.RabattP : ''} 
      name="RabattP" 
      onChange={this.props.changeTableByInput.bind(this, index)}
      width = '100%'
      
      placeholder='Discount'
    />
    </div>
    <div> </div>
    </div>*/