export const tableData = [
  {
    name: 'Article no', 
    width: '10%',
    dataBase: 'Articel'
  },

  {
    name: 'Quantity', 
    width: '10%'
  },

  {
    name: 'Description', 
    width: '20%'
  },

  {
    name: 'Addition', 
    width: '10%'
  },

  {
    name: 'Price', 
    width: '10%',
    textAlign: 'right'
  },

  {
    name: 'Total', 
    width: '10%',
    textAlign: 'right'
  },

  {
    name: 'Discount', 
    width: '10%',
    textAlign: 'right'
  },

  {
    name: 'VAT', 
    width: '10%',
    textAlign: 'right'
  }
]
