import React, { Component } from 'react';
import {  Col, Row } from 'react-bootstrap';
import styled from 'styled-components'
import { Grid } from 'react-virtualized';

import TableRow from './TableRow'
import {tableData} from './tableData'

const list = [ [1,2,3], [4,5,6], [7,8,9], [7,8,9], [7,8,9], [7,8,9], [7,8,9], [7,8,9], [7,8,9], [7,8,9], [7,8,9], [7,8,9], [7,8,9], [7,8,9], [7,8,9], [7,8,9], [7,8,9], [7,8,9], [7,8,9]];
let widthWindow = document.documentElement.clientWidth * 0.65;



class TableWithEdit extends Component {
  state = {}

  onChange = () =>{
    console.log('gg')
  }

  getColumnWidth  = ({index}) =>{
    switch (index) {
      case 2:
        return  widthWindow * 0.2;
      default:
        return widthWindow * 0.1;
    }
  }

  cellRenderer = ({ columnIndex, key, rowIndex, style }) => {
  return (
      <TableRow
        columnIndex={columnIndex}
        key = {key}
        rowIndex = {rowIndex}
        style={style}
        list={list}
        {...this.props}   
      />
  )  
}
  render() {
    const {data} = this.props;
    const table = tableData.map((item,index)=>{
      return (<NameBlock width={item.width} textAlign = {item.textAlign}>{item.name} </NameBlock>);
    });
    return (
      <Row>
        {table}
        <Grid
          cellRenderer={this.cellRenderer}
          columnCount={9}
          columnWidth={this.getColumnWidth}
          height={200}
          rowCount={data.length}
          rowHeight={40}
          width={widthWindow}
        />
        
      </Row>
    );
  }
}

export default TableWithEdit;

const NameBlock = styled.div`
  width: ${props => props.width};
  float: left;
  position: center;
  text-align: ${props => props.textAlign ? props.textAlign : 'left'};
`;