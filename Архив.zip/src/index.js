import React from 'react';
import { BrowserRouter } from 'react-router-dom'
import App from './App';
import {render}  from 'react-dom';
import AWSAppSyncClient from "aws-appsync";
import { Rehydrated } from 'aws-appsync-react';
import { ApolloProvider } from 'react-apollo';
import ApolloClient from "apollo-boost";

import Amplify, { Auth } from 'aws-amplify';
import { AUTH_TYPE } from 'aws-appsync/lib/link/auth-link';



const getCreds = async () => {
  return await Auth.currentSession()
    .then(data => {
      return data.idToken.jwtToken;
    })
    .catch(err => console.log(err));
};

const client = new AWSAppSyncClient({
  url: "http://fa-api-env.eu-west-1.elasticbeanstalk.com/graphql",
  region: "eu-west-1",
  auth: {
    type: AUTH_TYPE.AMAZON_COGNITO_USER_POOLS,
    jwtToken: getCreds(),
  },
});

// const client = new ApolloClient({
//   uri: "http://localhost:4000/graphql"
// });

const ApolloApp = () => (
  <ApolloProvider client={client}>
      <BrowserRouter>
        <App />
      </BrowserRouter>
  </ApolloProvider>
)

render(<ApolloApp/>, document.getElementById('root'));
