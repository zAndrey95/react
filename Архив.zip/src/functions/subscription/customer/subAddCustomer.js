import gql from 'graphql-tag';

export default gql`
 subscription addedCustomer{
   addCustomerComents {
   		__typename
		changeNm
		nameCustomer
		salutationCustomer
		additiveCustomer
		roadCustomer
		zipCode
		place
		telefonG
		natel
		email

    }
}`; 