import gql from 'graphql-tag';

export default gql`
 subscription addCustomerListsSub{
   addCustomerListsSub {
    	CustomerListID
    	CustomerListName

    }
}`; 