import gql from 'graphql-tag';

export default gql`
 subscription deleteCustomerListsSub{
   deleteCustomerListsSub {
		CustomerListID
		CustomerListName
    }
}`; 