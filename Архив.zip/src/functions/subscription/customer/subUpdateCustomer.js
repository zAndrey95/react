import gql from 'graphql-tag';

export default gql`
 subscription updetedCustomer{
    updateCustomerComents {
   	__typename
    id
	changeNm
	nameCustomer
	salutationCustomer
	additiveCustomer
	roadCustomer
	zipCode
	place
	telefonG
	natel
	email

    }
}`; 