import gql from 'graphql-tag';

export default gql`
 subscription deletedCustomer{
   deletesCustomer {
   	__typename
  	  ModifiedNo
	Name
	Intern
	Anrede
	Zusatz
	Strasse
	PLZ
	Ort
	TelefonG
	Natel
	EMail

    }
}`; 