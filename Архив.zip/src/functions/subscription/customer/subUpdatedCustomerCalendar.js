import gql from 'graphql-tag';

export default gql`
 subscription updatedCustomerCalendar{
    updatedCustomerCalendar {
    Intern
    LieferungMontag
	LieferungDienstag
	LieferungMittwoch
	LieferungDonnerstag
	LieferungFreitag
	LieferungSamstag 
	LieferungSonntag

    }
}`; 