import gql from 'graphql-tag';

export default gql`
 subscription updatefkProductListsSub{
    updatefkProductListsSub {
    	productListId
    	productListName

    }
}`; 