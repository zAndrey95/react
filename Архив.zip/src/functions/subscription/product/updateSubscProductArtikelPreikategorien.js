import gql from 'graphql-tag';

export default gql`
 subscription updateSubscProductArtikelPreikategorien{
   updateSubscProductArtikelPreikategorien {
    	LinkArticle
    	FromDate
      ToDate
      Price1
      Price2
      Price3
      Price4
      Price5
      Price6
      Price7
      Price8
      Price9
      Price10
      Description

    }
}`;
