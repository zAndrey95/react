import gql from 'graphql-tag';

export default gql`
 subscription noOrderOnOrderCreateSub{
   noOrderOnOrderCreateSub {
    	LinkCustomer
		OrderDate
    }
}`; 