import gql from 'graphql-tag';

export default gql`
query allListProductionEditGeneralFormSelectProduction{
    allListProductionEditGeneralFormSelectProduction{
	ReportID
	Formular
	DateiName
	UserFormularID
	DefaultFormularID
	ReportTypeName
	}
}`;