import gql from 'graphql-tag';

export default gql`
query getProductionEditGeneralInfo($Intern: Int){
    getProductionEditGeneralInfo(Intern: $Intern){
		Intern
            LinkGruppe
            LinkSortierung
            IsMo
            IsDi
            IsMi
            IsDo
            IsFr
            IsSa
            IsSo
            AddDay
            IsPrint
            ReportID
            ShowSemiProductsDetails
            ListenName
	}
}`;