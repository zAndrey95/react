import gql from 'graphql-tag';

export default gql`
query allListProductionEditGeneralFormSelectSpediliste{
    allListProductionEditGeneralFormSelectSpediliste{
	ReportID
	Formular
	DateiName
	UserFormularID
	DefaultFormularID
	ReportTypeName
	}
}`;