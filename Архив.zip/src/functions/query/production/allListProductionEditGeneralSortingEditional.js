import gql from 'graphql-tag';

export default gql`
query allListProductionEditGeneralSortingEditional{
    allListProductionEditGeneralSortingEditional{
	ProductionReportSortingKindID
	ProductionReportSortingKindName
	}
}`;