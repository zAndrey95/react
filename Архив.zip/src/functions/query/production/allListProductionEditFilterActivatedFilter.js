import gql from 'graphql-tag';

export default gql`
query allListProductionEditFilterActivatedFilter($Is: String){
    allListProductionEditFilterActivatedFilter(Is: $Is){
	ArticleListID
	ArticleListName
	Is
	Checked
	}
}`;