import gql from 'graphql-tag';

export default gql`
query allListProductionEditFilterCustomerFilter($Is: String){
    allListProductionEditFilterCustomerFilter(Is: $Is){
	CustomerListID
	CustomerListName
	Is
	Checked
	}
}`;