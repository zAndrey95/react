import gql from 'graphql-tag';

export default gql`
query allListProductionPrintPrint($firstDate: String, $secondDate: String){
    allListProductionPrintPrint(firstDate: $firstDate, secondDate: $secondDate){
		Intern
  LieferscheinNr
  Datum
  KundenNr
  AktNameIntern
  LieferscheinTyp
  ResName
  IsPrint
  IsPrintDateTime
  firstDate
  secondDate
	}
}`;