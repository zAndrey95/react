import gql from 'graphql-tag';

export default gql`
query allListProductionEditFilterOrderType($Is: String){
    allListProductionEditFilterOrderType(Is: $Is){
	OrderTypeID
	OrderTypeName
	Is
	Checked
	}
}`;