import gql from 'graphql-tag';

export default gql`
query allListProductionEditGeneralSortingUniversall{
    allListProductionEditGeneralSortingUniversall{
	ProductionReportSortingKindID
	ProductionReportSortingKindName
	}
}`;