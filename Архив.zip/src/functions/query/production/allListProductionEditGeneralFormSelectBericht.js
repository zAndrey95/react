import gql from 'graphql-tag';

export default gql`
query allListProductionEditGeneralFormSelectBericht{
    allListProductionEditGeneralFormSelectBericht{
	ReportID
	Formular
	DateiName
	UserFormularID
	DefaultFormularID
	ReportTypeName
	}
}`;