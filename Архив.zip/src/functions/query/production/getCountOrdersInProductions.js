import gql from 'graphql-tag';

export default gql`
query getCountOrdersInProductions($firstDate: String, $secondDate: String){
    getCountOrdersInProductions(firstDate: $firstDate, secondDate: $secondDate){
		RecordCount
		firstDate
		secondDate
	}
}`;