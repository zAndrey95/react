import gql from 'graphql-tag';

export default gql`
query getProductionEditFilter($Intern: Int){
    getProductionEditFilter(Intern: $Intern){
        FilterDef
        FilterDefKunde
        FilterDefOrderTypes
        FilterDefSQL
        FilterDefKundeSQL
        OrderPositionsOnlyIndividualText
        HighlightArticlesFromProductionCalculation
        IsSplitDoughBeforePrint
	}
}`;