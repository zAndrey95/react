import gql from 'graphql-tag';

export default gql`
query allListProductionPrintProduction($onDayWeek: String){
    allListProductionPrintProduction(onDayWeek: $onDayWeek){
		Intern
		IsPrint
		ListenName
		ReportID
		PrintFld
		PreviewFld
		onDayWeek
	}
}`;