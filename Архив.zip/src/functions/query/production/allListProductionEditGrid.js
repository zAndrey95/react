import gql from 'graphql-tag';

export default gql`
query allListProductionEditGrid($Name: String, $Id: Int){
    allListProductionEditGrid(Name: $Name, Id: $Id){
	Intern
  ListenName
  Name
  Id
	}
}`;