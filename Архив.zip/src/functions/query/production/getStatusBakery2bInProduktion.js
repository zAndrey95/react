import gql from 'graphql-tag';

export default gql`
query getStatusBakery2bInProduktion($OnDate: String){
    getStatusBakery2bInProduktion(OnDate: $OnDate){
		RecordID
		OnDate
	}
}`;