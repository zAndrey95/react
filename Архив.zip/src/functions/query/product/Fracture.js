import gql from 'graphql-tag';

export default gql`
query listProductFracture($id: Int){

  listProductFracture{
  	id
    concatenatedField
	}

  getProductFracture(id: $id){
    id
    concatenatedField
  }

  ProductAddInfo(id: $id){
    id
    breakUsedParts
    isBreakTitle
}
}`;
