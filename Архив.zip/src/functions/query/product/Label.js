import gql from 'graphql-tag';

export default gql`
query getProductLabel($id: Int){
    getProductLabel(id: $id){
    	id
      label
      EANNo
      isEANmanagedByCA
      linkLabelRecipe
      declaration
      forSaleDays
      salesWeight
      toConsumeDays
      shelfLifeDayes
      mustBeKeptCool
      storage
      storageCustomerText
	}
}`;
