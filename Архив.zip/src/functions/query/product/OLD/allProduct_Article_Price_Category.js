import gql from 'graphql-tag';

export default gql`
query allProduct_Article_Price_Category{
    allProduct_Article_Price_Category{
      Article_Price_Category1
      Article_Price_Category2
      Article_Price_Category3
      Article_Price_Category4
      Article_Price_Category5
      Article_Price_Category6
      Article_Price_Category7
      Article_Price_Category8
      Article_Price_Category9
      Article_Price_Category10
}
}`;
