import gql from 'graphql-tag';

export default gql`
query allProduct_Artikel_Gruppe{
    allProduct_Artikel_Gruppe{
      name
      id
}
}`;
