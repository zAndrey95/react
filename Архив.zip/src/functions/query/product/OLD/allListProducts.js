import gql from 'graphql-tag';

export default gql`
query allListProducts($SearchValue:String, $From:Int){
    allListProducts(SearchValue: $SearchValue, From:$From){
	productNm
	nameProduct
	id
}
}`;
