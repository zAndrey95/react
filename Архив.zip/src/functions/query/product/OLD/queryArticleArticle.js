import gql from 'graphql-tag';

export default gql `
query allListProduct($orderTitle: String, $search: String, $order: Boolean) {
  allListProduct(orderTitle: $orderTitle, search: $search, order: $order){
    id
    ModNm
    Description
  }
}`;
