import gql from 'graphql-tag';

export default gql`
query allArtikleProduktionGeneral($Intern:Int){
    allArtikleProduktionGeneral(Intern: $Intern){
      Intern
      LinkRezept
      IsDough
      IsFermentationInterrupt
      Teigeinlage
      SummierenAufArtikel
      IsAufBackzettel
      AnzahlProBlech
      AnzahlBlechProWagen
      FaktorLtKg
      RundenAuf
      isTeigSplitting
      TeigSplittingTeig1
      TeigSplittingTeig2
}
}`;
