import gql from 'graphql-tag';

export const Active = gql`
query allArtikleBruchActiveElement($Intern: Int){
  allArtikleBruchActiveElement(Intern: $Intern){
    Intern
    ConcatenatedField
  }
}`;

export const List = gql`
query allArtikleBruchList($search: String){
  allArtikleBruchList(search: $search){
    Intern
    ConcatenatedField
  }
}`;
