import gql from 'graphql-tag';

export default gql`
query allProduct_Artikel_Gruppe2{
    allProduct_Artikel_Gruppe2{
      name
      id
}
}`;
