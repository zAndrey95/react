import gql from 'graphql-tag';

export default gql`
query allfkProductLists{
    allfkProductLists{
		productListName
		productListId
}
}`;
