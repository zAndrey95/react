import gql from 'graphql-tag';

export default gql`
query allProduct_Artikel_Preikategorien($id:Int){
    allProduct_Artikel_Preikategorien(id: $id){
      Intern
      ToDate
      FromDate
      Price1
      Price2
      Price3
      Price4
      Price5
      Price6
      Description
}
}`;
