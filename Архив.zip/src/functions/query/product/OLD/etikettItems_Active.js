import gql from 'graphql-tag';

export const Active = gql`
query allArtikleEtikettRezeptActiveElement($Intern: Int){
  allArtikleEtikettRezeptActiveElement(Intern: $Intern){
    Intern
    ConcatenatedField
  }
}`;

export const List = gql`
query allArtikleEtikettRezeptList($search: String){
  allArtikleEtikettRezeptList(search: $search){
    Intern
    ConcatenatedField
  }
}`;


export const allData = gql`
  query allData($Intern: Int, $search: String){
    allArtikleEtikettRezeptActiveElement(Intern: $Intern){
      Intern
      ConcatenatedField
    }
    allArtikleEtikettRezeptList(search: $search){
      Intern
      ConcatenatedField
    }
  }
`;
