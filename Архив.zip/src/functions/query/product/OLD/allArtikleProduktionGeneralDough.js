import gql from 'graphql-tag';

export default gql`
query allArtikleProduktionGeneralDough{
    allArtikleProduktionGeneralDough{
      Intern
      ConcatenatedField
}
}`;
