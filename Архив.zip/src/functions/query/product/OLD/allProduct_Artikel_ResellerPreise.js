import gql from 'graphql-tag';

export default gql`
query allProduct_Artikel_ResellerPreise($id:Int){
    allProduct_Artikel_ResellerPreise(id: $id){
      Intern
      KundenNR
      LinkArticle
      LinkCustomer
      Description
      Price
      AktNameIntern
}
}`;
