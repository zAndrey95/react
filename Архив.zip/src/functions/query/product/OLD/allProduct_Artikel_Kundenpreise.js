import gql from 'graphql-tag';

export default gql `
query allProduct_Artikel_Kundenpreise($id:Int){
    allProduct_Artikel_Kundenpreise(id: $id){
      Intern
      ToDate
      FromDate
      KundenNr
      AktNameIntern
      Price
      FromAmount
      Discount
      DiscountsDisabled
      Description
      LinkCustomer
}
}`;