import gql from 'graphql-tag';

export default gql`
query allAssistKonfiguration($ConfigID:Int){
    allAssistKonfiguration(ConfigID: $ConfigID){
      ConfigID
      ShowDoughInLiterInProductionLists
}
}`;
