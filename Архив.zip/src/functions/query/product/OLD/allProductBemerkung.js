import gql from 'graphql-tag';

export default gql`
query allProductBemerkung($id:Int){
    allProductBemerkung(id: $id){
      Intern
      memo
}
}`;
