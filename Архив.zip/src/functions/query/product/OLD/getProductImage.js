import gql from 'graphql-tag';

export default gql`
query getProductImg($id:Int){
    getProductImg(id: $id){
      img
}
}`;
