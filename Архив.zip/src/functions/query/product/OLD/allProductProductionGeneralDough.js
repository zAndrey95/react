import gql from 'graphql-tag';

export default gql`
query allProductProductionGeneralDough{
  allProductProductionGeneralDough{
    ConcatenatedField
  }
}`;
