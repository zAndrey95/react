import gql from 'graphql-tag';

export default gql`
query allArtikleProduktionGeneralRecip{
    allArtikleProduktionGeneralRecip{
      Intern
      ConcatenatedField
}
}`;
