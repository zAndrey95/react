import gql from 'graphql-tag';

export default gql`
query getProductDeliveryPeriod($LinkArtikel:Int){
    getProductDeliveryPeriod(LinkArtikel: $LinkArtikel){
      Intern
  		LinkArtikel
  		VomDatum
  		BisDatum
  		Bemerkung
  		IsCustomWeekDaySetting
  		IsRepeatYearly
}
}`;
