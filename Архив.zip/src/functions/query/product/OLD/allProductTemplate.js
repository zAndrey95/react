import gql from 'graphql-tag';

export default gql`
query allProductTemplate{
    allProductTemplate{
		id
		PageName
		isVisible
	  PageIndex
		ConcatenatedField
}
}`;
