import gql from 'graphql-tag';

export default gql`
query getfkProductListsRelations($productLink: Int){
    getfkProductListsRelations(productLink: $productLink){
		productListsRelationID
		productLink
		productLinkList
}
}`;
