import gql from 'graphql-tag';

export default gql`
query getProductEtikett($productId: Int){
    getProductEtikett(productId: $productId){
    IdentificationLabel2
	EanNR
	StockCustomer
	InfoCustomer
	IsEANManagedByCA
	Declaration
	ForSaleDays
	SalesWeight:
	ToSpendDays
	ShelfLifeDays
	MustBeKeptCool
	Storage
	}
}`;