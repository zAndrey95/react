import gql from 'graphql-tag';

export default gql`
query view_ProductKonfigurationWG{
    view_ProductKonfigurationWG{
		Intern
		ResultName
}
}`;
