import gql from 'graphql-tag';

export default gql`
query allProduct_Artikel_Kundenpreise_Modal{
    allProduct_Artikel_Kundenpreise_Modal{
      Intern
      AktNmeIntern
      KundenNr
}
}`;
