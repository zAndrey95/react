import gql from 'graphql-tag';

export default gql`
query getProductInfo{
    allProductInfo{
    	productId
  		delMo
  		delTu
  		delWe
  		delTh
  		delFr
  		delSa
  		delSu
  		DescriptionAnotherLng
  		OrderPeriodInDays
  		weight
  		IsBreakTitle
  		BreakSummingUp
  		BreakUsedParts
      WillReplacedWithProductionCalc
	}
}`;
