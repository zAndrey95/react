import gql from 'graphql-tag';

export default gql `
query allArticleProduktionCalculation($Intern:Int){
    allArticleProduktionCalculation(Intern: $Intern){
      Intern
      ArtikelNr
      Bezeichnung
      Multiplier
      IsFermentationInterrupt
}
}`;
