import gql from 'graphql-tag';

export default gql`
query getfkProductProductionCalc($productLink: Int){
  getProductProductionCalc(productLink: $productLink){
    id
	productNr
	name
	Multiplier
	IsFermentationInterrupt
  }
}
`;
