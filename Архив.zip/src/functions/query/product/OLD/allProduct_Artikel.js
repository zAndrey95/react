import gql from 'graphql-tag';

export default gql`
query allProduct_Artikel($id:Int){
    allProduct_Artikel(id: $id){
      name
      id
      isTitel
      isNetto
      isActive
      LinkGruppe
      LinkGruppe2
      LinkGruppe3
      itemsNm
      amount1
      amount2
      amount3
      amount4
      amount5
      amount6
      amount7
      amount8
      amount9
      amount10
      articleImage
      BezeichnungEtikett2
      EANNr,
      IsEANmanagedByCA,
      LinkEtikettRezept,
      Deklaration,
      ZuVerkaufenTage,
      VerkaufsGewicht,
      ZuVerbrauchenTage,
      HaltbarkeitTage,
      MustBeKeptCool,
      Lagerung,
      LinkCashAssistSchablone,
      Umsatzgruppe,
      CAVisibilityStatusID,
      BruchSummierenAuf,
      BruchVerwendeteTeile,
      IsBruchTitel
  }
}`;
