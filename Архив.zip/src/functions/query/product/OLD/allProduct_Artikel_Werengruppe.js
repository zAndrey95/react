import gql from 'graphql-tag';

export default gql`
query allProduct_Artikel_Werengruppe{
    allProduct_Artikel_Werengruppe{
      name
      id
}
}`;
