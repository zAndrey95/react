import gql from 'graphql-tag';

export default gql`
query allfkRezeptAssistRezept{
  allfkRezeptAssistRezept{
    ConcatenatedField
  }
}`;
