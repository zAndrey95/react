import gql from 'graphql-tag';

export default gql`
query view_ProductVisibilityStatuses{
    view_ProductVisibilityStatuses{
		CAVisibilityStatusID
		CAVisibilityStatusName
}
}`;
