import gql from 'graphql-tag';

export default gql`
query allProductEtikettRezaptAssist{
    allProductEtikettRezaptAssist{
      Intern
    	Nummer
    	Bezeichnubg
    	ConcatenatedField
}
}`;
