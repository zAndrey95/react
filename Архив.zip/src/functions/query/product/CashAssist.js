import gql from 'graphql-tag';

export default gql`
query getProductCashAssist($idSc: Int, $idSG: Int, $idV: Int){

  getProductCashAssistShablone(id: $idSc){
    id
    concatenatedField
  }
  getProductCashAssistSalesGroup(id: $idSG){
    id
    concatenatedField
  }
  getProductCashAssistVisibility(id: $idV){
    id
    concatenatedField
  }

  listProductCashAssistShablone{
    id
    concatenatedField
  }

  listProductCashAssistSalesGroup{
    id
    concatenatedField
  }

  listProductCashAssistVisibility{
    id
    concatenatedField
  }
}`;
