import gql from 'graphql-tag';

export default gql`
query ProductAddInfo($id: Int){
    ProductAddInfo(id: $id){
    	id
  		descriptionAnotherLng
	}
}`;
