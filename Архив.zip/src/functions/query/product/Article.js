import  gql from 'graphql-tag';

export var ListItem =  gql`
query listProduct($limit: Int) {
    listProduct(limit: $limit) {
        id
        productId
        name
    }
}`;

export var Data =  gql` 
query dataProduct($id: Int, $idActive: Int, $idActive2: Int, $idActive3: Int) {
    getProductArticle(id: $id){
        id
        articleNo
        designation
        isNet
        isActivated
        isTitle
        linkGroup
        linkGroup2
        linkGroup3
        amount1
        amount2
        amount3
        amount4
        amount5
        amount6
        amount7
        amount8
        amount9
        amount10
    }
    
     getProductArticleGroupActive(id: $idActive) {
            id
            designation
        }
        
    getProductArticleGroup2Active(id: $idActive2) {
        id
        designation
    }
    
    getProductArticleGroup3Active(id: $idActive3) {
        id
        designation
    }
}`;

export var Group = gql`
    query listGroups {
        listProductArticleGroup {
            id
            designation
        }
        
        listProductArticleGroup2 {
            id
            number
            designation
        }
        
        listProductArticleGroup3 {
            id
            number
            designation
        }
    }
`;