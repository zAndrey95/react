import gql from 'graphql-tag';

export default gql`
query allOpenDebitor($dateFrom: Datum, $dateTill: Datum, $datePayment: Datum){
    allOpenDebitor(dateFrom: $dateFrom, dateTill: $dateTill, datePayment: $datePayment){
      id
      date
      invoiceNo
      customerNo
      name
      total
      remainingAmount
      termOfPayment
      paymentDate
      paymentDelay
      debtInTime
      unexpiredDebt
      overdue1_15Days
      overdue16_30Days
      overdueMore30Days
      reminders
      dateFrom
      dateTill
      datePayment
    }
}`;
