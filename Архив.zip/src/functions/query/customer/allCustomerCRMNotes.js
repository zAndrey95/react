
import gql from 'graphql-tag';

export default gql`
	query allCustomerCRMNotes($LinkCustomer: Int){
		allCustomerCRMNotes(LinkCustomer: $LinkCustomer){
			LinkCustomer,
			AddedOn,
			Note,
			RecordID
        }
}`;