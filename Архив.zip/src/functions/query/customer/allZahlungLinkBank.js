import gql from 'graphql-tag';

export default gql`
query allZahlungLinkBank{
    allZahlungLinkBank{
      Intern
      bankName
    }
}`;