import gql from 'graphql-tag';

export default gql`
query allCustomer_Lists{
    allCustomer_Lists{
		CustomerListID
		CustomerListName
}
}`;
