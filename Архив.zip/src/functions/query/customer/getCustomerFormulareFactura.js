import gql from 'graphql-tag';

export default gql`
query getCustomerFormulareFactura($Intern: Int!){
    getCustomerFormulareFactura(Intern: $Intern){
		Intern
		InvoiceReportID
		InvoiceSummaryReportID
		InvoicePaymentSlipReportID
		FakturaAbrechnung
		DebitorStatus
		InvoiceCopies
		BemerkungFaktura
    }
}`;