import gql from 'graphql-tag';

export default gql`
	query view_fkReductionsAndPricesTakeFromKinds{
  		view_fkReductionsAndPricesTakeFromKinds{
    		ReductionsAndPricesKindName
    		LanguageID
  		}
	}`;