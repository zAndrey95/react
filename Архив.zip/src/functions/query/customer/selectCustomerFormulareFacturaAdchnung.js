import gql from 'graphql-tag';

export default gql`
query selectCustomerFormulareFacturaAdchnung{
    selectCustomerFormulareFacturaAdchnung{
		InvoiceIntervalID
		InvoiceIntervalName
}
}`;
