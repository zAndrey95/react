import gql from 'graphql-tag';

export default gql`
query allCustomerInfoLiefershein($id: Int){
    allCustomerInfo(id: $id){
		OrderReportID
		LinkLSGruppe
		MemoLieferschein
		DeliveryNoteCopies

	}
}`;