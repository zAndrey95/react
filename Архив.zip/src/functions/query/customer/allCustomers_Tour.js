import gql from 'graphql-tag';

export default gql`
query allCustomers_Tour($Intern: Int){
    allCustomers_Tour(Intern: $Intern){
		Intern,
		Ruestplatz,
        RuestplatzSa,
        RuestplatzSo, 
        TourenplanImmer, 
        TourenplanBemerkung, 
        LinkTourenplan, 
        LinkTourenplanSa, 
        LinkTourenplanSo,
        TourenplanReihenfolge, 
        TourenplanReihenfolgeSa, 
        TourenplanReihenfolgeSo,
        TourenplanZeit, 
        TourenplanZeitSa,
        TourenplanZeitSo
	}
}`;