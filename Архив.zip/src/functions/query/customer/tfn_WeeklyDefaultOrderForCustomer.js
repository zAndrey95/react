import gql from 'graphql-tag';

export default gql`
query tfn_WeeklyDefaultOrderForCustomer($id: Int, $currentDate: String){
    tfn_WeeklyDefaultOrderForCustomer(id: $id, currentDate: $currentDate){
		itemNr
		description
		qtyMo
		qtyTu
		qtyWe
		qtyTh
		qtyFr
		qtySa
		qtySu
		GUID
		DateMon
		IsMonAvailable
 		IsTueAvailable
  		IsWedAvailable
  		IsThuAvailable
  		IsFriAvailable
  		IsSatAvailable
  		IsSunAvailable
  		isAktiviert
  		IsGroupAvailable
    }
}`;