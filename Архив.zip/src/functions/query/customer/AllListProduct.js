import gql from 'graphql-tag';

export default gql`
query AllListProduct{
    allProductList{
			Bezeichnung
			ModifiedNo
		      Intern
		      Betrag1
    }
}`;