import gql from 'graphql-tag';

export default gql`
	query view_fkDiscounts {
		view_fkDiscounts{
      		DiscountName
        }
    }`;
