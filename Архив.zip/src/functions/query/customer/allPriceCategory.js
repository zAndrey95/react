import gql from 'graphql-tag';

export default gql`
query allPriceCategory{
    allPriceCategory{
		ArtikelPreisKategorie1
	    ArtikelPreisKategorie2
		ArtikelPreisKategorie3
		ArtikelPreisKategorie4
		ArtikelPreisKategorie5
		ArtikelPreisKategorie6
		ArtikelPreisKategorie7
		ArtikelPreisKategorie8
		ArtikelPreisKategorie9
		ArtikelPreisKategorie10
    }
}`;