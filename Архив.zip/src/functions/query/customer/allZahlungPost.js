import gql from 'graphql-tag';

export default gql`
query allZahlungPost($idCustomer: Int){
    allZahlungPost(idCustomer: $idCustomer){
		idCustomer
		PostSectorID
		Name
    }
}`;