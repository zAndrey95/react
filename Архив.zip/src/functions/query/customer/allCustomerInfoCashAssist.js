import gql from 'graphql-tag';

export default gql`
query allCustomerInfoCalendar($id: Int){
    allCustomerInfo(id: $id){
	    cashAssistPrice
	    isCashAssistCredit
	}
}`;