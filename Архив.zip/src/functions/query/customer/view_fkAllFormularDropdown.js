import gql from 'graphql-tag';

export default gql`
	query view_fkAllFormularDropdown {
		view_fkAllFormularDropdown{
      		Formular
        }
    }`;
