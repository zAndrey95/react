import gql from 'graphql-tag';

export default gql`
query selectCustomerLiefersheinFacturaGroup{
    selectCustomerLiefersheinFacturaGroup{
		ResID
		ResName
}
}`;
