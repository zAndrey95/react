import gql from 'graphql-tag';

export default gql`
query selectCustomerFormulareFacturaDebitor{
    selectCustomerFormulareFacturaDebitor{
		DebitorStatusID
		DebitorStatusName
}
}`;