import gql from 'graphql-tag';

export default gql`
query ($Intern: Int!){
    getCustomerFormulareLiefershein(Intern: $Intern){
		Intern
		OrderReportID
		LinkLSGruppe
		MemoLieferschein
		MemoLieferschein2
    }
}`;