import gql from 'graphql-tag';

export default gql`
query allLanguages{
  allLanguages{
    LanguageID
	LanguageName
  }
}`;