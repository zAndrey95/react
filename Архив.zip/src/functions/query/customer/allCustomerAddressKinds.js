import gql from 'graphql-tag';

export default gql`
query allCustomerAddressKinds{
  allCustomerAddressKinds{
    CustomerAddressKindID
  }
}`;