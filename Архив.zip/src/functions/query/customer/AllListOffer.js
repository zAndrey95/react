import gql from 'graphql-tag';

export default gql`
query AllListOffer{
    allOfferList{
			Intern
			ListenName
    }
}`;