import gql from 'graphql-tag';

export default gql`
query {
    allCustomer_Konditional_Zahlung_Rebett{
		PostSectorID
		Name
	}
}`;