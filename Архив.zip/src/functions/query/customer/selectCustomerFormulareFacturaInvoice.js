import gql from 'graphql-tag';

export default gql`
query selectCustomerFormulareFacturaInvoice{
    selectCustomerFormulareFacturaInvoice{
		ReportID
		Formular
		DateiName
		UserFormularID
		DefaultFormularID
		ReportTypeName

}
}`;