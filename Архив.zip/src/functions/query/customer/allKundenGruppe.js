import gql from 'graphql-tag';

export default gql`
query allKundenGruppe{
  allKundenGruppe{
    Intern
    Gruppe
  }
}`;