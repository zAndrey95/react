import gql from 'graphql-tag';

export default gql`
query allCustomer_Vorgadedestellung($LinkKunde: Int){
    allCustomer_Vorgadedestellung(LinkKunde: $LinkKunde){
		Intern
		Name
		linkCustomer
		isMonday
		isTuesday
		isWednesday
		isThursday
		isFriday
		isSaturday
		isSunday
		comment
		tillDate
	}
}`;