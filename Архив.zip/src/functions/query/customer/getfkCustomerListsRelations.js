import gql from 'graphql-tag';

export default gql`
query getfkCustomerListsRelations($LinkCustomer: Int){
    getfkCustomerListsRelations(LinkCustomer: $LinkCustomer){
		LinkCustomer
		LinkCustomerList
		CustomerListsRelationID
	}
}`;