import gql from 'graphql-tag';

export default gql`
query allCustomerInfoVorgadedestellung($id: Int){
    allCustomerInfo(id: $id){
		VorgabeLieferschein
		VorgabeAuto
		FlexibleOrders
		EnabledDeliverySplitting
	}
}`;