import gql from 'graphql-tag';

export default gql`
query allCustomerInfo($id: Int){
    allCustomerInfo(id: $id){
		telefonG
		telefonP
		telefonG
		changeNm
		customerNm
		contactPerson
		nameCustomer
		id
		salutationCustomer
		additiveCustomer
		roadCustomer
		zipCode
		place
		natel
		email
		fax
		customerAddressKindID
		postOfficeBox
		internet
		searchValue
		payment
		isActivated
		LinkGruppe
		OtherEMailAddresses
		UseAnotherLngDescriptions
		cashAssistPrice
	    IsCashAssistKredit
	}
}`;