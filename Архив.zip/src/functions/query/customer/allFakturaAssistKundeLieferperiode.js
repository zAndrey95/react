import gql from 'graphql-tag';

export default gql`
query allFakturaAssistKundeLieferperiode{
    allFakturaAssistKundeLieferperiode{
		fromDate
		tillDate
		comment
	}
}`;