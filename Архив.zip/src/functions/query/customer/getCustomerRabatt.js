import gql from 'graphql-tag';

export default gql`
query getCustomerRabatt($Intern: Int){
    getCustomerRabatt(Intern: $Intern){
    	Intern
		RabattInProzent1
		RabattInProzent2
		RabattInProzent3
		RabattInProzent4
		RabattInProzent5
		RabattInProzent6
		RabattInProzent7
		RabattInProzent8
		RabattInProzent9
		RabattInProzent10
		RabattInProzent11
		RabattInProzent12
		RabattInProzent13
		RabattInProzent14
		RabattInProzent15
		RabattInProzent16
		RabattInProzent17
		RabattInProzent18
		RabattInProzent19
		RabattInProzent20
		RabattCode
		LinkMengenrabatt
		CustomerRabattDropdown{
			Intern
			Bezeichnung
		}


	}
}`;