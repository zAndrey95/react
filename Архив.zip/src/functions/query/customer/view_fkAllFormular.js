import gql from 'graphql-tag';

export default gql`
	query view_fkAllFormular{
  		view_fkAllFormular{
    		Formular
  		}
	}`;