import gql from 'graphql-tag';

export default gql`
query allResellerPreise($LinkCustomer: Int){
    allResellerPreise(LinkCustomer: $LinkCustomer){
		LinkCustomer
		LinkArticle
		Intern
		Price
		Description
		Bezeichnung
    }
}`;