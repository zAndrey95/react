import gql from 'graphql-tag';

export default gql`
query allSpecialPrices($LinkCustomer: Int){
    allSpecialPrices(LinkCustomer: $LinkCustomer){
		Intern
		LinkCustomer
		LinkArticle
		FromDate
		ToDate
		Price
		FromAmount
		Discount
		DiscountsDisabled
		Description
		LinkSpecialPriceType
		CurrentPrice
    }
}`;