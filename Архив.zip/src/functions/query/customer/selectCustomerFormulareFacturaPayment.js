import gql from 'graphql-tag';

export default gql`
query selectCustomerFormulareFacturaPayment{
    selectCustomerFormulareFacturaPayment{
		ReportID
		Formular
		DateiName
		UserFormularID
		DefaultFormularID
		ReportTypeName

}
}`;