import gql from 'graphql-tag';

export default gql`
query allZahlung($Intern: Int){
    allZahlung(Intern: $Intern){
    	LinkPostSector
		ZahlungsZiel
		SkontoInProzent
		SkontoTage
		DebitorKonto
		SAPBetriebsNr
		ErtragKonto
		Kostenstelle
		CustomPaymentText
		Intern
    }
}`;