import gql from 'graphql-tag';

export default gql`
query selectCustomerFormulareFacturaForm{
    selectCustomerFormulareFacturaForm{
		ReportID
		Formular
		DateiName
		UserFormularID
		DefaultFormularID
		ReportTypeName

}
}`;