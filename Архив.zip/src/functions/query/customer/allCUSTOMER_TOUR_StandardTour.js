import gql from 'graphql-tag';

export default gql`
query allCUSTOMER_TOUR_StandardTour{
    allCUSTOMER_TOUR_StandardTour{
		Intern
        Bezeichnung
}
}`;