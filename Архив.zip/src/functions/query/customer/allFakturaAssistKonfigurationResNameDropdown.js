import gql from 'graphql-tag';

export default gql`
	query allFakturaAssistKonfigurationResNameDropdown {
		allFakturaAssistKonfigurationResNameDropdown{
      		ResName
  		}
	}`;
