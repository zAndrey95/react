import gql from 'graphql-tag';

export default gql`
query allListCustomers($SearchValue:String, $From:Int){
    allListCustomers(SearchValue: $SearchValue, From:$From){
	id
	nameCustomer
}
}`;
