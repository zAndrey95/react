import gql from 'graphql-tag';

export default gql`
	query view_fkCustomerDefaultOrderKinds{
  		view_fkCustomerDefaultOrderKinds{
    		CustomerDefaultOrderKindName
  		}
	}`;