import gql from 'graphql-tag';

export default gql`
query selectCustomerLiefersheinFacturaFormular{
    selectCustomerLiefersheinFacturaFormular{
		ReportID
		Formular
		DefaultFormularID
		ReportGroupID
		LanguageID

}
}`;