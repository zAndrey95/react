import gql from 'graphql-tag';

export default gql`
query allCheckOrders(
	$id: Int!, 
	$date: String!
	){
	    allCheckOrders(
	    	id:$id, 
	    	date: $date
	    ){
				UserFullName
				LieferscheinNr
				dOperation

		}
}`;
