import gql from 'graphql-tag';

export default gql`
query view_fkOrderTypes{
	    view_fkOrderTypes{
			OrderTypeID
			OrderTypeName
		}
}`;
