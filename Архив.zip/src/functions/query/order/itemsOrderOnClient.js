import gql from 'graphql-tag';

export default gql`
query itemsOrderOnClient{
	    itemsOrderOnClient @client{
			TempLS
      		OfferID
      		date
      		formattedDate
		}
}`;
