import gql from 'graphql-tag';

export default gql`
query getOrderDeliveryTime(
	$id: Int
	){
	    getOrderDeliveryTime(
	    	id: $id
	    ){
			sunday
			saturday
			weekdays
		}
}`;
