import gql from 'graphql-tag';

export default gql`
query allOrderCreateGrid(
	$TempLS: Int!,
	$OfferID: Int,
	$id: Int,
	$date: String,
	$table: String,
	$VorgabeLieferschein: Int,
	$LinkOrder: Int
	){
	    allOrderCreateGrid(
	    	TempLS: $TempLS,
			OfferID: $OfferID,
			id: $id,
			date: $date,
			table: $table,
			VorgabeLieferschein: $VorgabeLieferschein,
			LinkOrder: $LinkOrder
	    ){
			LinkArtikel
			LookUp_ArtikelNr
			Menge
			LookUp_Bezeichnung
			Addition
			PreisLieferung
			Total
			RabattP
			MWStCode
			ArtikelNr
			Bezeichnung
			OrderPositionID
			IndTextProduction
			IndTextDeliveryNote
			PreisEinheit
			Gewicht
			LinkVirtualPosition
			LinkEtikettRezept
		}
}`;
