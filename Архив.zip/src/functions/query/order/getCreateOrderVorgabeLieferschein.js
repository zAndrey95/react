import gql from 'graphql-tag';

export default gql`
query getCreateOrderVorgabeLieferschein(
	$id: Int!
	){
	    getCreateOrderVorgabeLieferschein(
	    	id:$id
	    ){
				VorgabeLieferschein
		}
}`;
