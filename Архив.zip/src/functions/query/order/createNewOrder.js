import gql from 'graphql-tag';

export default gql`
mutation createNewOrder(
	$userId: Int!, 
	$orderType: Int!, 
	$date: String!, 
	$textId: Int,
	$Intern: Int!,
	$variables:[CreateOrderVariables]
	){
	    createNewOrder(
	    	userId:$userId, 
	    	orderType: $orderType, 
	    	date: $date,
	    	textId: $textId,
	    	Intern: $Intern,
	    	variables: $variables
	    ){
				ErrorCode
				ErrorText
				OrderID
				OrderNo
				__typename
		}
}`;
