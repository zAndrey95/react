import gql from 'graphql-tag';

export default gql`
query getOrderUpdateOrderAllInputs(
	$id: Int!
	){
	    getOrderUpdateOrderAllInputs(
	    	id: $id
	    ){
			Intern
			SAPBestellNr
			LieferscheinTyp
			LinkText
			FakturaNr
			Datum
			LinkKunde
			CAIsExported
			DeliveryTime
			IsPrint
			Memo
			CashAssistKasse
			CashAssistBelegNr
			CALieferzeit
			CALieferart
			CABenutzer
		}
}`;
