import gql from 'graphql-tag';

export default gql`
query procedureCustomersListForCreatingOrdersOnDate(
	$date: String, 
	$folderName: String, 
	$group: Int, 
	$orderType: Int,
	$search: String,
	$offset: Int,
	$sortName: String,
	$isIncrease: Boolean


	){
	    procedureCustomersListForCreatingOrdersOnDate(
	    	date:$date, 
	    	folderName: $folderName, 
	    	group: $group,
	    	orderType: $orderType,
	    	search: $search,
			offset: $offset,
			sortName: $sortName,
			isIncrease: $isIncrease
	    ){
				Intern
				KundenNr
				AktNameIntern
				NameRes
				TempLS
				OfferID
				VorgabeAuto
				IsEmptyOrder
				HasLSOnDate
				IsDelivered
		}
}`;
