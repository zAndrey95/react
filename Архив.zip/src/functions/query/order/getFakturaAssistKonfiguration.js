import gql from 'graphql-tag';

export default gql`
query getFakturaAssistKonfiguration{
    getFakturaAssistKonfiguration{
		LSGruppe1
		LSGruppe2
		LSGruppe3
		LSGruppe4
		LSGruppe5
		LSGruppe6
		LSGruppe7
		LSGruppe8
		LSGruppe9
		LSGruppe10
}
}`;
