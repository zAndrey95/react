import gql from 'graphql-tag';

export default gql`
query getOrderCalendar{
	    getOrderCalendar @client{
			date
      		formattedDate
      		__typename
		}
}`;
