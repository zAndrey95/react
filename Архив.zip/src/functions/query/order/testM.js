import gql from 'graphql-tag';

export default gql`
mutation changeGg($id: String!) {
	changeAllOrderCreateGridClient(id: $id) @client{
		__typename
      LinkArtikel
      LookUp_ArtikelNr
      Menge
      LookUp_Bezeichnung
      Addition
      PreisLieferung
      Total
      RabattP
      MWStCode
      ArtikelNr
      Bezeichnung
      OrderPositionID
      IndTextProduction
      IndTextDeliveryNote
      PreisEinheit
      Gewicht
      LinkVirtualPosition
      LinkEtikettRezept
	}
}`;
