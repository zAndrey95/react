import gql from 'graphql-tag';

export default gql`
query getOrderHead(
	$id: Int
	){
	    getOrderHead(
	    	id: $id
	    ){
			KundenNr
			BemerkungLieferschein
			TelefonG
			TelefonGII
			TelefonP
			Natel
			Fax
			EMail
			Adresse
			Address
		}
}`;
