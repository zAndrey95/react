import gql from 'graphql-tag';

export default gql`
query allOrderOverviewDough(
	$firstDate: String!,
	$secondDate: String!
	){
	    allOrderOverviewDough(
	    	firstDate: $firstDate,
			secondDate: $secondDate
	    ){
			Intern
		    ArtikelNr
		    KundenNr
		    Menge
		    Bezeichnung
		    AktNameIntern
		    IndTextDeliveryNote
		    IndTextProduction
		    Datum
		    LieferscheinNr
		    Total
		    TotalNetto
		    Betrag
		    RabattP
		    Nummer
		}
}`;
