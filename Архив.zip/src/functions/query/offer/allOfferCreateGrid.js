import gql from 'graphql-tag';

export default gql`
query allOfferCreateGrid(
	$TempLS: Int!,
	$OfferID: Int,
	$id: Int,
	$date: String,
	$userTable: String,
	$LinkOffer: Int
	){
	    allOfferCreateGrid(
	    	TempLS: $TempLS,
			OfferID: $OfferID,
			id: $id,
			date: $date,
			userTable: $userTable,
			LinkOffer: $LinkOffer
	    ){
			LinkArtikel
			LookUp_ArtikelNr
			Menge
			LookUp_Bezeichnung
			Addition
			PreisLieferung
			Total
			RabattP
			MWStCode
			ArtikelNr
			Bezeichnung
			OfferPositionID
			IndTextProduction
			IndTextDeliveryNote
			PreisEinheit
			LinkVirtualPosition
		}
}`;
