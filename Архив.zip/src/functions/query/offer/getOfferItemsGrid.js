 import gql from 'graphql-tag';



export default gql`
query getOfferItemsGrid(
	$folderName: String!, 
	$date: String!, 
	$secondDate: String
	){
	    getOfferItemsGrid(
	    	folderName:$folderName, 
	    	date: $date,
	    	secondDate: $secondDate
	    ){
			Intern
	        OfferForDate
	        OfferNr
	        KundenNr
	        NameRes
	        TempOfferID
	        OfferID
	        Accepted
	        Declined
	        Total
		}
}`;


