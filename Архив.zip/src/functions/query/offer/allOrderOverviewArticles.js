import gql from 'graphql-tag';

export default gql`
query allOrderOverviewArticles(
	$firstDate: String!,
	$secondDate: String!
	){
	    allOrderOverviewArticles(
	    	firstDate: $firstDate,
			secondDate: $secondDate
	    ){
			Intern
			ArtikelNr
			KundenNr
			Menge
			Bezeichnung
			AktNameIntern
			IndTextDeliveryNote
			IndTextProduction
			Datum
			LieferscheinNr
			Total
			TotalNetto
			Betrag
			RabattP
		}
}`;
