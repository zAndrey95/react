import gql from 'graphql-tag';

export default gql`
query allOrderCustomersWithout(
	$firstDate: String!,
	$secondDate: String!
	){
	    allOrderCustomersWithout(
	    	firstDate: $firstDate,
			secondDate: $secondDate
	    ){
			EmptyOrderID
			OrderDate
			KundenNr
			AktNameIntern
		}
}`;
