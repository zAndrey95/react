import gql from 'graphql-tag';

export default gql`
query allOrderRecalculationValues(
	$date: String!, 
	$id: Int!, 
	$linkArticle: [Int], 
	$Menge: [Int]
	){
	    allOrderRecalculationValues(
	    	date:$date, 
	    	id: $id, 
	    	linkArticle: $linkArticle,
	    	Menge: $Menge
	    ){
				PreisLieferung
				RabattP
		}
}`;
