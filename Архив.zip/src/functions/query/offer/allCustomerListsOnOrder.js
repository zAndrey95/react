import gql from 'graphql-tag';

export default gql`
query allCustomerListsOnOrder{
	    allCustomerListsOnOrder{
			AktNameIntern
  			Intern
 			KundenNr
		}
}`;
