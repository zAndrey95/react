import gql from 'graphql-tag';

export default gql`
mutation createOffer(
	$id: Int!, 
	$date: String!, 
	$secondDate: String!,
	$variables:[CreateOfferVariables]
	){
	    createOffer(
	    	id:$id, 
	    	orderType: $orderType, 
	    	date: $date,
	    	secondDate: $secondDate,
	    	variables: $variables
	    ){
				Intern
			    OfferNr
			    OfferForDate
			    LastValidDate
			    Total
			    LinkKunde
				__typename
		}
}`;
