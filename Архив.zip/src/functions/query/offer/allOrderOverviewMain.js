import gql from 'graphql-tag';

export default gql`
query allOrderOverviewMain(
	$firstDate: String!,
	$secondDate: String!
	){
	    allOrderOverviewMain(
	    	firstDate: $firstDate,
			secondDate: $secondDate
	    ){
			Intern
			Datum
			KundenNr
			AktNameIntern
			LieferscheinNr
			Total
			TotalNetto
			OrderTypeName
			UserFullName
			ResName
			Gruppe
		}
}`;
