import gql from 'graphql-tag';

export default gql`
query allGridInEditOrder(
	$folderName: String!,
	$date: String,
	$secondDate: String,
	$firstRange: Int,
	$secondRange: Int,
	$id: Int,
	$linkCustomerList: Int
	){
	    allGridInEditOrder(
	    	folderName:$folderName, 
	    	date: $date, 
	    	secondDate: $secondDate,
	    	firstRange: $firstRange,
	    	secondRange: $secondRange,
	    	id: $id,
	    	linkCustomerList: $linkCustomerList,
	    ){
	    	Intern
        	Datum
        	LieferscheinNr
        	FakturaNr
        	KundenNr
        	AktNameIntern
        	LieferscheinTyp
        	Total
        	LinkKunde
        	IsDelete
        	OrderTypeName
		}
}`;
