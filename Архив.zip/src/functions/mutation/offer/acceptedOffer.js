import gql from 'graphql-tag';

export default gql`
mutation acceptedOffer(
	$id: Int!
	){
	    acceptedOffer(
	    	id:$id
	    ){
				serverStatus
				insertId
				__typename
		}
}`;
