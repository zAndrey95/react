import gql from 'graphql-tag';

export default gql`
mutation declinedOffer(
	$id: Int!
	){
	    declinedOffer(
	    	id:$id
	    ){
				serverStatus
				insertId
				__typename
		}
}`;
