import gql from 'graphql-tag';

export default gql`
mutation dublicateOffer(
	$id: Int!, 
	$date: String!, 
	$secondDate: String!,
	$variables:[CreateOfferVariables]
	){
	    dublicateOffer(
	    	id:$id, 
	    	orderType: $orderType, 
	    	date: $date,
	    	secondDate: $secondDate,
	    	variables: $variables
	    ){
				ErrorCode
   				ErrorText
			    OfferID
			    OfferNo
				__typename
		}
}`;
