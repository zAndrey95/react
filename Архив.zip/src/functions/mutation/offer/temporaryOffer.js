import gql from 'graphql-tag';

export default gql`
mutation createTemporaryOffer(
	$id: Int!, 
	$date: String!, 
	$secondDate: String!,
	$TempOffer: Int!,
	$OfferId: Int!,
	$Declined: Boolean!,
	$Accepted: Boolean!,
	$variables:[CreateOfferVariables]
	){
	    createTemporaryOffer(
	    	id:$id, 
	    	date: $date,
	    	secondDate: $secondDate,
	    	TempOffer: $TempOffer,
	    	OfferId: $OfferId,
	    	Declined: $Declined,
	    	Accepted: $Accepted,
	    	variables: $variables
	    ){
				ErrorCode
			    ErrorText
			    OfferID
			    OfferNo
				__typename
		}
}`;
