import gql from 'graphql-tag';

export default gql`
	mutation addRecordIDInProduktionPrint($OnDate: String){
		addRecordIDInProduktionPrint( OnDate: $OnDate){
			OnDate
        }
}`;