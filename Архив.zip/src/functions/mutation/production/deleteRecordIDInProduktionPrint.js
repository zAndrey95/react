import gql from 'graphql-tag';

export default gql`
	mutation deleteRecordIDInProduktionPrint($OnDate: String){
		deleteRecordIDInProduktionPrint( OnDate: $OnDate){
			OnDate
        }
}`;