import gql from 'graphql-tag';

export default gql`
	mutation editProductionEditFilter(
		$Intern: Int, 
		$FilterDef: String,
		$FilterDefKunde: String,
		$FilterDefOrderTypes: String,
		$FilterDefSQL: String,
		$FilterDefKundeSQL: String, 
		$OrderPositionsOnlyIndividualText: Boolean, 
		$HighlightArticlesFromProductionCalculation: Boolean, 
		$IsSplitDoughBeforePrint: Boolean){
  		editProductionEditFilter(
  			Intern: $Intern, 
  			FilterDef: $FilterDef, 
  			FilterDefKunde: $FilterDefKunde, 
  			FilterDefOrderTypes: $FilterDefOrderTypes, 
  			FilterDefSQL: $FilterDefSQL, 
  			FilterDefKundeSQL: $FilterDefKundeSQL,
  			OrderPositionsOnlyIndividualText: $OrderPositionsOnlyIndividualText,
  			HighlightArticlesFromProductionCalculation: $HighlightArticlesFromProductionCalculation,
  			IsSplitDoughBeforePrint: $IsSplitDoughBeforePrint){
				Intern
				FilterDef
				FilterDefKunde
				FilterDefOrderTypes
				FilterDefSQL
				FilterDefKundeSQL
				OrderPositionsOnlyIndividualText
				HighlightArticlesFromProductionCalculation
				IsSplitDoughBeforePrint
  }
}`;