import gql from 'graphql-tag';

export default gql`
	mutation addProduct_Artikel_Preikategorien(
		$LinkArticle: Int!,
		$FromDate: String,
		$ToDate: String,
		$Price1: String,
		$Price2: String,
		$Price3: String,
		$Price4: String,
		$Price5: String,
		$Price6: String,
		$Price7: String,
		$Price8: String,
		$Price9: String,
		$Price10: String,
		$Description: String)
			{
	  		addProduct_Artikel_Preikategorien(
					LinkArticle: $LinkArticle,
					FromDate: $FromDate,
					ToDate: $ToDate,
					Price1: $Price1,
					Price2: $Price2,
					Price3: $Price3,
					Price4: $Price4,
					Price5: $Price5,
					Price6: $Price6,
					Price7: $Price7,
					Price8: $Price8,
					Price9: $Price9,
					Price10: $Price10,
					Description: $Description)
						{
							LinkArticle
						}
}`;
