import gql from 'graphql-tag';

export default gql`
	mutation addfkProductListsRelations($productLink: Int!, $productLinkList: Int!){
		addfkProductListsRelations(productLink: $productLink, productLinkList: $productLinkList){
      		productLink
   			productLinkList
    		productListsRelationID
        }
}`;
