import gql from 'graphql-tag';

export default gql`
	mutation updateAssistKonfiguration($ConfigID: Int!){
		updateAssistKonfiguration(ConfigID: $ConfigID){
			ConfigID
			ShowDoughInLiterInProductionLists
        }
}`;
