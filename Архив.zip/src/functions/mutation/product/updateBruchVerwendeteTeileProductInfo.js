import gql from 'graphql-tag';

export default gql`
	mutation updateBruchVerwendeteTeileProductInfo($productId: Int!, $BreakUsedParts: Int){
  		updateBruchVerwendeteTeileProductInfo(productId: $productId, BreakUsedParts: $BreakUsedParts){
    		productId
    		BreakUsedParts
  }
}`;