import gql from 'graphql-tag';

export default gql`
	mutation deletefkProductListsRelations($productListsRelationID: Int!){
		deletefkProductListsRelations(productListsRelationID: $productListsRelationID){
			productListsRelationID
        }
}`;
