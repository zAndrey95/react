import gql from 'graphql-tag';

export default gql`
	mutation updateOrderPeriodInDays_weightProductInfo($productId: Int!, $weight: Int, $OrderPeriodInDays: Int){
  		updateOrderPeriodInDays_weightProductInfo(productId: $productId, weight: $weight, OrderPeriodInDays: $OrderPeriodInDays){
    		productId
    		weight
    		OrderPeriodInDays
  }
}`;

