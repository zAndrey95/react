import gql from 'graphql-tag';

export default gql`
	mutation updateProduct_Artikel(
		$id: Int!,
		$name: String,
		$itemsNm: String,
		$LinkGruppe:Int,
		$LinkGruppe2:Int,
		$LinkGruppe3:Int,
		$isTitel: Boolean,
		$isNetto: Boolean,
		$isActive: Boolean,
		$amount1: String,
		$amount2: String,
		$amount3: String,
		$amount4: String,
		$amount5: String,
		$amount6: String,
		$amount7: String,
		$amount8: String,
		$amount9: String,
		$amount10: String,
		$articleImage: String,
		$BezeichnungEtikett2: String,
		$EANNr: String,
		$LagerungKunde: String,
		$InfoKunde: String,
		$IsEANmanagedByCA: Boolean,
		$LinkEtikettRezept: Int,
		$Deklaration: String,
		$ZuVerkaufenTage: Int,
		$VerkaufsGewicht: Int,
		$ZuVerbrauchenTage: Int,
		$HaltbarkeitTage: Int,
		$MustBeKeptCool: Boolean,
		$Lagerung: String,
		$BruchSummierenAuf: Int,
		$BruchVerwendeteTeile: Int,
		$IsBruchTitel: Boolean)
			{
	  		updateProduct_Artikel(
					id: $id,
					name: $name,
					itemsNm: $itemsNm,
					LinkGruppe: $LinkGruppe,
					LinkGruppe2: $LinkGruppe2,
					LinkGruppe3: $LinkGruppe3,
					isTitel: $isTitel,
					isNetto: $isNetto,
					isActive: $isActive,
					amount1: $amount1,
					amount2: $amount2,
					amount3: $amount3,
					amount4: $amount4,
					amount5: $amount5,
					amount6: $amount6,
					amount7: $amount7,
					amount8: $amount8,
					amount9: $amount9,
					amount10: $amount10,
					articleImage: $articleImage,
					BezeichnungEtikett2: $BezeichnungEtikett2,
					EANNr: $EANNr,
					LagerungKunde: $LagerungKunde,
					InfoKunde: $InfoKunde,
					IsEANmanagedByCA: $IsEANmanagedByCA,
					LinkEtikettRezept: $LinkEtikettRezept,
					Deklaration: $Deklaration,
					ZuVerkaufenTage: $ZuVerkaufenTage,
					VerkaufsGewicht: $VerkaufsGewicht,
					ZuVerbrauchenTage: $ZuVerbrauchenTage,
					HaltbarkeitTage: $HaltbarkeitTage,
					MustBeKeptCool: $MustBeKeptCool,
					Lagerung: $Lagerung,
					BruchSummierenAuf: $BruchSummierenAuf,
		      BruchVerwendeteTeile: $BruchVerwendeteTeile,
		      IsBruchTitel: $IsBruchTitel)
						{
			    		id
							name
			    		itemsNm
							LinkGruppe
					    LinkGruppe2
					    LinkGruppe3
							isTitel
							isNetto
							isActive
							amount1
							amount2
							amount3
							amount4
							amount5
							amount6
							amount7
							amount8
							amount9
							amount10
							articleImage
							BezeichnungEtikett2
							EANNr
							LagerungKunde
							InfoKunde
							IsEANmanagedByCA
							LinkEtikettRezept
							Deklaration
							ZuVerkaufenTage
							VerkaufsGewicht
							ZuVerbrauchenTage
							HaltbarkeitTage
							MustBeKeptCool
							Lagerung
							BruchSummierenAuf
							BruchVerwendeteTeile
							IsBruchTitel
						}
}`;
