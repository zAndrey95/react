import gql from 'graphql-tag';

export default gql`
	mutation addProduct_Artikel_Kundenpreise(
		$LinkArticle: Int!,
		$LinkCustomer: Int,
		$FromDate: String,
		$ToDate: String,
		$Price: String,
		$FromAmount: String,
		$Discount: String,
		$DiscountsDisabled: Boolean,
		$Description: String)
			{
	  		addProduct_Artikel_Kundenpreise(
					LinkArticle: $LinkArticle,
					LinkCustomer: $LinkCustomer,
					ToDate: $ToDate,
					FromDate: $FromDate,
					Price: $Price,
					FromAmount: $FromAmount,
					Discount: $Discount,
					DiscountsDisabled: $DiscountsDisabled,
					Description: $Description)
						{
							LinkArticle
						}
}`;
