import gql from 'graphql-tag';

export default gql`
	mutation updateProduct_Artikel_Kundenpreise(
		$Intern: Int,
		$LinkArticle: Int!,
		$LinkCustomer: Int,
		$FromDate: String,
		$ToDate: String,
		$Price: String,
		$FromAmount: String,
		$Discount: String,
		$DiscountsDisabled: Boolean,
		$Description: String)
			{
	  		updateProduct_Artikel_Kundenpreise(
					Intern: $Intern,
					LinkArticle: $LinkArticle,
					LinkCustomer: $LinkCustomer,
					ToDate: $ToDate,
					FromDate: $FromDate,
					Price: $Price,
					FromAmount: $FromAmount,
					Discount: $Discount,
					DiscountsDisabled: $DiscountsDisabled,
					Description: $Description)
						{
							LinkArticle
						}
}`;
