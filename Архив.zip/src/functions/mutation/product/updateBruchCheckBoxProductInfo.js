import gql from 'graphql-tag';

export default gql`
	mutation updateBruchCheckBoxProductInfo($productId: Int!, $IsBreakTitle: Boolean){
  		updateBruchCheckBoxProductInfo(productId: $productId, IsBreakTitle: $IsBreakTitle){
    		productId
    		BreakUsedParts
  }
}`;