import gql from 'graphql-tag';

export default gql`
	mutation deletefkProductLists($productListId: Int!){
		deletefkProductLists(productListId: $productListId){
			productListId
        }
}`;
