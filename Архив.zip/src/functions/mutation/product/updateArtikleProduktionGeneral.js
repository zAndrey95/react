import gql from 'graphql-tag';

export default gql`
	mutation updateArtikleProduktionGeneral(
		$Intern: Int!,
    $LinkRezept: Int,
    $IsDough: Boolean,
    $IsFermentationInterrupt: Boolean,
    $Teigeinlage: String,
    $SummierenAufArtikel: Int,
    $IsAufBackzettel: Boolean,
    $AnzahlProBlech: Int,
    $AnzahlBlechProWagen: Int,
		$FaktorLtKg: Float,
		$RundenAuf: Float,
		$isTeigSplitting: Boolean,
		$TeigSplittingTeig1: Int,
		$TeigSplittingTeig2: Int
		)
			{
	  		updateArtikleProduktionGeneral(
					Intern: $Intern,
					LinkRezept: $LinkRezept,
					IsDough: $IsDough,
					IsFermentationInterrupt: $IsFermentationInterrupt,
					Teigeinlage: $Teigeinlage,
					SummierenAufArtikel: $SummierenAufArtikel,
					IsAufBackzettel: $IsAufBackzettel,
					AnzahlProBlech: $AnzahlProBlech,
					AnzahlBlechProWagen: $AnzahlBlechProWagen,
					FaktorLtKg: $FaktorLtKg,
					RundenAuf: $RundenAuf,
					isTeigSplitting: $isTeigSplitting,
					TeigSplittingTeig1: $TeigSplittingTeig1,
					TeigSplittingTeig2: $TeigSplittingTeig2
					)
						{
							Intern
							LinkRezept
							IsDough
							IsFermentationInterrupt
							Teigeinlage
							SummierenAufArtikel
							IsAufBackzettel
							AnzahlProBlech
							AnzahlBlechProWagen
							FaktorLtKg
							RundenAuf
							isTeigSplitting
							TeigSplittingTeig1
							TeigSplittingTeig2

						}
}`;
