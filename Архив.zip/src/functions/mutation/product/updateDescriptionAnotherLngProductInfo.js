import gql from 'graphql-tag';

export default gql`
	mutation updateDescriptionAnotherLngProductInfo($productId: Int!, $DescriptionAnotherLng: String){
  		updateDescriptionAnotherLngProductInfo(productId: $productId, DescriptionAnotherLng: $DescriptionAnotherLng){
    		productId
    		DescriptionAnotherLng
  }
}`;