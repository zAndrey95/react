import gql from 'graphql-tag';

export default gql`
	mutation addfkProductLists($productListName: String!){
		addfkProductLists( productListName: $productListName){
			productListName
			productListId
        }
}`;
