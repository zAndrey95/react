import gql from 'graphql-tag';

export default gql`
	mutation updatefkProductLists($productListId: Int!, $productListName: String){
  		updatefkProductLists(productListId: $productListId, productListName: $productListName){
    		productListId
    		productListName
  }
}`;
