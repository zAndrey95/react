import gql from 'graphql-tag';

export default gql`
mutation updateDaysAvailability(
	$productId: Int,
	$delMo: Boolean,
	$delTu: Boolean,
	$delWe: Boolean,
	$delTh: Boolean,
	$delFr: Boolean,
	$delSa: Boolean,
	$delSu: Boolean,
 	){
  		updateDaysAvailability(
    		productId: $productId,
			delMo: $delMo,
			delTu: $delTu,
			delWe: $delWe,
			delTh: $delTh,
			delFr: $delFr,
			delSa: $delSa,
			delSu: $delSu,
  		){
    			productId
    			delMo
    			delTu
				delWe
				delTh
				delFr
				delSa
				delSu
  }
}`;