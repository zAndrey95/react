import gql from 'graphql-tag';

export default gql`
	mutation updateProductBemerkung($Intern: Int!, $memo: String){
  		updateProductBemerkung(Intern: $Intern, memo: $memo){
    		Intern
    		memo
  }
}`;
