import gql from 'graphql-tag';

export default gql`
mutation showCheckOrders(
	$id: Int!, 
	$date: String!
	){
	    showCheckOrders(
	    	id:$id, 
	    	date: $date
	    ){
				UserFullName
				LieferscheinNr
				dOperation

		}
}`;
