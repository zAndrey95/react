import gql from 'graphql-tag';

export default gql`
mutation createTemporaryOrder(
	$id: Int, 
	$date: String, 
	$TempLS: Int,
	$variables:[TemporaryOrderVariables]
	){
	    createTemporaryOrder(
	    	id:$id, 
	    	date: $date,
	    	TempLS: $TempLS,
	    	variables: $variables
	    ){
				insertId
		}
}`;
