import gql from 'graphql-tag';

export default gql`
mutation noOrderOnOrderCreate(
	$id: Int!, 
	$date: String!
	){
	    noOrderOnOrderCreate(
	    	id:$id, 
	    	date: $date
	    ){
				LinkCustomer

		}
}`;
