import gql from 'graphql-tag';

export default gql`
mutation editNewOrder(
	$userId: Int!, 
	$orderType: Int!, 
	$date: String!, 
	$textId: Int,
	$Intern: Int!,
	$editOrderId: Int!,
	$variables:[CreateOrderVariables]
	){
	    editNewOrder(
	    	userId:$userId, 
	    	orderType: $orderType, 
	    	date: $date,
	    	textId: $textId,
	    	Intern: $Intern,
	    	editOrderId: $editOrderId,
	    	variables: $variables
	    ){
				ErrorCode
				ErrorText
		}
}`;
