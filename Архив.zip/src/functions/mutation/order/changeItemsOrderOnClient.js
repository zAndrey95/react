import gql from 'graphql-tag';

export default gql`
mutation changeItemsOrderOnClient($TempLS: Int, $OfferID: Int, $date: String, $formattedDate: String) {
	changeItemsOrderOnClient(TempLS: $TempLS, OfferID: $OfferID, date: $date, formattedDate: $formattedDate ) @client{
		__typename
            TempLS
            OfferID
            date
            formattedDate
            __typename
	}
}`;
