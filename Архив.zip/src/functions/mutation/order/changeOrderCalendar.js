import gql from 'graphql-tag';

export default gql`
mutation changeOrderCalendar($date: String, $formattedDate: String) {
	changeOrderCalendar(date: $date, formattedDate: $formattedDate ) @client{
            date
            formattedDate
            __typename
	}
}`;
