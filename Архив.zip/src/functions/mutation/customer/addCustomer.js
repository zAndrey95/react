import gql from 'graphql-tag';

export default gql`
mutation addCustomer($changeNm: String, $nameCustomer: String, $salutationCustomer: String, $additiveCustomer: String, $roadCustomer: String, $zipCode: String, $place: String, $telefonG: String, $natel: String, $email: String){
    addCustomer( changeNm: $changeNm, nameCustomer: $nameCustomer, salutationCustomer: $salutationCustomer, additiveCustomer:$additiveCustomer, roadCustomer: $roadCustomer, zipCode: $zipCode, place: $place, telefonG: $telefonG, natel: $natel, email: $email) {	
    	id
    	changeNm
		nameCustomer
		salutationCustomer
		additiveCustomer
		roadCustomer
		zipCode
		place
		telefonG
		natel
		email
    }
}`;
