import gql from 'graphql-tag';

export default gql`
mutation deleteResellerPreise($Intern: Int){
    deleteResellerPreise(Intern: $Intern) {	
      Intern
    }
}`;