import gql from 'graphql-tag';

export default gql`
mutation updateKundenGruppe($Intern:Int, $Gruppe: String){
  updateKundenGruppe(Intern: $Intern, Gruppe:$Gruppe){
    Intern
    Gruppe
  }
}`;