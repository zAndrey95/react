import gql from 'graphql-tag';

export default gql`
mutation getPR_ReCalculateOrders($id: Int,$fromDate: String,$toDate: String,$bit3: Boolean,$bit1: Boolean,$bit2: Boolean){
    getPR_ReCalculateOrders(id: $id,fromDate: $fromDate,toDate: $toDate,bit3: $bit3,bit1: $bit1,bit2: $bit2){
		id
	fromDate
	toDate
	bit3
	bit1
	bit2
	fieldCount
	affectedRows
	insertId
	serverStatus
	warningCount
	message
	protocol41
	changedRows
	}
}`;

