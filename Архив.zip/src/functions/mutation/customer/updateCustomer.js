import gql from 'graphql-tag';

export default gql`
	mutation updateCustomer
	(		
		$id: Int,
		$changeNm: String,
		$nameCustomer: String,
		$salutationCustomer: String,
		$additiveCustomer: String,
		$roadCustomer: String,
		$zipCode: String,
		$place: String,
		$telefonG: Int,
		$telefonP: Int,
		$telefonG2: Int,
		$natel: String,
		$email: String,
		$isActivated: Boolean,
		$LinkGruppe: Int,
		$contactPerson: String
		$internet: String
		$fax: String
		$OtherEMailAddresses: String
		$postOfficeBox: String
		$UseAnotherLngDescriptions: Boolean
		$Natel: String
		$cashAssistPrice: Int
	    $IsCashAssistKredit: Boolean
	)
			{
		        updateCustomer
		        ( 
				    id:$id,
				    changeNm: $changeNm, 
				    nameCustomer: $nameCustomer, 
				    salutationCustomer: $salutationCustomer, 
				    additiveCustomer:$additiveCustomer, 
				    roadCustomer: $roadCustomer, 
				    zipCode: $zipCode, 
				    place: $place, 
				    telefonG: $telefonG, 
				    natel: $natel,
				    isActivated: $isActivated
				    email: $email
				    LinkGruppe: $LinkGruppe
					contactPerson: $contactPerson
					internet: $internet
					telefonP: $telefonP
					telefonG2: $telefonG2
					fax: $fax
					postOfficeBox: $postOfficeBox
					OtherEMailAddresses: $OtherEMailAddresses
					UseAnotherLngDescriptions: $UseAnotherLngDescriptions
					Natel: $Natel
					cashAssistPrice: $cashAssistPrice
					IsCashAssistKredit: $IsCashAssistKredit
				)
				    {
				    id
				    changeNm
				    nameCustomer
				    salutationCustomer
				    additiveCustomer
				    roadCustomer
				    zipCode
				    place
				    telefonG
				    natel
				    email
				    isActivated
				    LinkGruppe
				    contactPerson
				    internet
				    telefonG2
				    telefonP
				    fax
				    postOfficeBox
				    OtherEMailAddresses
				    UseAnotherLngDescriptions
				    Natel		    
					cashAssistPrice
				    IsCashAssistKredit
                    }
}`;
