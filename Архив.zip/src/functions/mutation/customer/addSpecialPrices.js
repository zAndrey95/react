import gql from 'graphql-tag';

	export default gql`
	mutation addSpecialPrices($LinkCustomer: Int, $LinkArticle: Int, $FromDate: String, $ToDate: String, $Price: Float, $FromAmount: Float, $Discount: Float, $DiscountsDisabled: Boolean, $Description: String, $LinkSpecialPriceType: Int){
	    addSpecialPrices( LinkCustomer: $LinkCustomer, LinkArticle: $LinkArticle, FromDate: $FromDate, ToDate:$ToDate, Price: $Price, FromAmount: $FromAmount, Discount: $Discount, DiscountsDisabled: $DiscountsDisabled, Description: $Description, LinkSpecialPriceType: $LinkSpecialPriceType) {	
	    	LinkCustomer
			LinkArticle
			FromDate
			ToDate
			Price
			FromAmount
			Discount
			DiscountsDisabled
			Description
			LinkSpecialPriceType
	    }
}`;