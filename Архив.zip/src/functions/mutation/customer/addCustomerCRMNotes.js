import gql from 'graphql-tag';

export default gql`
	mutation addCustomerCRMNotes($LinkCustomer: Int, $AddedOn: String, $Note: String){
		addCustomerCRMNotes(LinkCustomer: $LinkCustomer, AddedOn: $AddedOn, Note: $Note){
			LinkCustomer
			AddedOn
			Note
        }
}`;