import gql from 'graphql-tag';

export default gql`
mutation deleteCustomer($Intern: String){
    deleteCustomer(Intern: $Intern) {	
      Intern
      Name
      ModifiedNo

    }
}`;
