import gql from 'graphql-tag';

export default gql`
	mutation addfkCustomerListsRelations($LinkCustomer: Int!, $LinkCustomerList: Int!){
		addfkCustomerListsRelations(LinkCustomer: $LinkCustomer, LinkCustomerList: $LinkCustomerList){
      		LinkCustomer
   			LinkCustomerList
    		CustomerListsRelationID
        }
}`;
