import gql from 'graphql-tag';

export default gql`
	mutation updateCustomerCalendar(
	    $Intern: Int, 
		$LieferungMontag: Boolean, 
		$LieferungDienstag: Boolean, 
		$LieferungMittwoch: Boolean, 
		$LieferungDonnerstag: Boolean, 
		$LieferungFreitag: Boolean, 
		$LieferungSamstag: Boolean, 
		$LieferungSonntag: Boolean
		){
    updateCustomerCalendar( 
	    Intern:$Intern,
	    LieferungMontag: $LieferungMontag, 
		LieferungDienstag: $LieferungDienstag, 
		LieferungMittwoch: $LieferungMittwoch, 
		LieferungDonnerstag: $LieferungDonnerstag, 
		LieferungFreitag: $LieferungFreitag, 
		LieferungSamstag: $LieferungSamstag, 
		LieferungSonntag: $LieferungSonntag
	    ) {	
    Intern
    LieferungMontag
	LieferungDienstag
	LieferungMittwoch
	LieferungDonnerstag
	LieferungFreitag
	LieferungSamstag 
	LieferungSonntag
    }
}`;
