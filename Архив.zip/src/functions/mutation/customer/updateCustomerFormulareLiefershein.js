import gql from 'graphql-tag';

export default gql`
	mutation updateCustomerFormulareLiefershein
	(		
		$Intern: Int,
		$InvoiceReportID: Int,
		$InvoiceSummaryReportID: Int,
		$InvoicePaymentSlipReportID: Int,
		$FakturaAbrechnung: Int,
		$DebitorStatus: Int,
		$InvoiceCopies: String,
		$BemerkungFaktura: String
	)
			{
		        updateCustomerFormulareLiefershein
		        ( 
				    Intern:$Intern,
				    InvoiceReportID: $InvoiceReportID, 
				    InvoiceSummaryReportID: $InvoiceSummaryReportID, 
				    InvoicePaymentSlipReportID: $InvoicePaymentSlipReportID, 
				    FakturaAbrechnung:$FakturaAbrechnung, 
				    DebitorStatus: $DebitorStatus, 
				    InvoiceCopies: $InvoiceCopies, 
				    BemerkungFaktura: $BemerkungFaktura
				)
				    {
				    Intern
				    InvoiceReportID
				    InvoiceSummaryReportID
				    InvoicePaymentSlipReportID
				    FakturaAbrechnung
				    DebitorStatus
				    InvoiceCopies
				    BemerkungFaktura
				    
                    }
}`;
