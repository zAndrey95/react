import gql from 'graphql-tag';

export default gql`
	mutation updateSpecialPrices(
	    $Intern: Int, 
		$LinkCustomer: Int, 
		$LinkArticle: Int, 
		$FromDate: String, 
		$ToDate: String, 
		$Price: Float, 
		$FromAmount: Float, 
		$Discount: Float
		$DiscountsDisabled: Boolean
		$Description: String
		$LinkSpecialPriceType: Int 
		){
    updateSpecialPrices( 
	    Intern:$Intern,
	    LinkCustomer: $LinkCustomer, 
		LinkArticle: $LinkArticle, 
		FromDate: $FromDate, 
		ToDate: $ToDate, 
		Price: $Price, 
		FromAmount: $FromAmount, 
		Discount: $Discount
		DiscountsDisabled: $DiscountsDisabled
		Description: $Description
		LinkSpecialPriceType: $LinkSpecialPriceType
	    ) {	
    Intern
    LinkCustomer
	LinkArticle
	FromDate
	ToDate
	Price
	FromAmount 
	Discount
	DiscountsDisabled
	Description
	LinkSpecialPriceType

    }
}`;