import gql from 'graphql-tag';

export default gql`
	mutation updateResellerPreise(
	    $Intern: Int, 
		$LinkArticle: Int, 
		$Price: Float, 
		$Description: String){
				updateResellerPreise( 
	    		Intern: $Intern, 
	    		LinkArticle: $LinkArticle, 
	    		Price:$Price, 
	    		Description: $Description){
	    			Intern
			    	LinkArticle
					Description
					Price
    }
}`;