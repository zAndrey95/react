import gql from 'graphql-tag';

export default gql`
	mutation updateCustomerRabatt
	(		
		$Intern: Int,
		$RabattInProzent1: Float,
		$RabattInProzent2: Float,
		$RabattInProzent3: Float,
		$RabattInProzent4: Float,
		$RabattInProzent5: Float,
		$RabattInProzent6: Float,
		$RabattInProzent7: Float,
		$RabattInProzent8: Float,
		$RabattInProzent9: Float,
		$RabattInProzent10: Float,
		$RabattInProzent11: Float,
		$RabattInProzent12: Float,
		$RabattInProzent13: Float,
		$RabattInProzent14: Float,
		$RabattInProzent15: Float,
		$RabattInProzent16: Float,
		$RabattInProzent17: Float,
		$RabattInProzent18: Float,
		$RabattInProzent19: Float,
		$RabattInProzent20: Float,
		$RabattCode: Int,
		$LinkMengenrabatt: Int
	)
			{
		        updateCustomerRabatt
		        ( 
					Intern: $Intern,
					RabattInProzent1: $RabattInProzent1,
					RabattInProzent2: $RabattInProzent2,
					RabattInProzent3: $RabattInProzent3,
					RabattInProzent4: $RabattInProzent4,
					RabattInProzent5: $RabattInProzent5,
					RabattInProzent6: $RabattInProzent6,
					RabattInProzent7: $RabattInProzent7,
					RabattInProzent8: $RabattInProzent8,
					RabattInProzent9: $RabattInProzent9,
					RabattInProzent10: $RabattInProzent10,
					RabattInProzent11: $RabattInProzent11,
					RabattInProzent12: $RabattInProzent12,
					RabattInProzent13: $RabattInProzent13,
					RabattInProzent14: $RabattInProzent14,
					RabattInProzent15: $RabattInProzent15,
					RabattInProzent16: $RabattInProzent16,
					RabattInProzent17: $RabattInProzent17,
					RabattInProzent18: $RabattInProzent18,
					RabattInProzent19: $RabattInProzent19,
					RabattInProzent20: $RabattInProzent20,
					RabattCode: $RabattCode,
					LinkMengenrabatt: $LinkMengenrabatt
				)
				    {
					    Intern
						RabattInProzent1
						RabattInProzent2
						RabattInProzent3
						RabattInProzent4
						RabattInProzent5
						RabattInProzent6
						RabattInProzent7
						RabattInProzent8
						RabattInProzent9
						RabattInProzent10
						RabattInProzent11
						RabattInProzent12
						RabattInProzent13
						RabattInProzent14
						RabattInProzent15
						RabattInProzent16
						RabattInProzent17
						RabattInProzent18
						RabattInProzent19
						RabattInProzent20
						RabattCode
						LinkMengenrabatt
				    
                    }
}`;