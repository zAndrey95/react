import gql from 'graphql-tag';

export default gql`
mutation addResellerPreise(
	$Intern: Int, 
	$LinkArticle: Int, 
	$LinkCustomer: Int, 
	$Price: Float, 
	$Description: String){
			addResellerPreise( 
    		Intern: $Intern, 
    		LinkArticle: $LinkArticle, 
    		LinkCustomer: $LinkCustomer, 
    		Price:$Price, 
    		Description: $Description){
    			Intern
		    	LinkArticle
				LinkCustomer
				Description
				Price
    }
}`;