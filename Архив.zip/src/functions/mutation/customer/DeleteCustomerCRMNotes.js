import gql from 'graphql-tag';

export default gql`
mutation deleteCustomerCRMNotes($RecordID: Int!){
  deleteCustomerCRMNotes(RecordID: $RecordID) {
    RecordID
  }
}`;