import gql from 'graphql-tag';

export default gql`
	mutation deleteCustomerLists($CustomerListID: Int!){
		deleteCustomerLists(CustomerListID: $CustomerListID){
			CustomerListID
        }
}`;
