import gql from 'graphql-tag';

export default gql`
	mutation deletefkCustomerListsRelations($CustomerListsRelationID: Int!){
		deletefkCustomerListsRelations(CustomerListsRelationID: $CustomerListsRelationID){
			CustomerListsRelationID
        }
}`;
