import gql from 'graphql-tag';

export default gql`
	mutation updateCustomerFormulare
	(		
		$Intern: Int,
		$OrderReportID: Int,
		$LinkLSGruppe: Int,
		$MemoLieferschein: String,
		$MemoLieferschein2: String
	)
			{
		        updateCustomerFormulare
		        ( 
				    Intern:$Intern,
				    OrderReportID: $OrderReportID, 
				    LinkLSGruppe: $LinkLSGruppe, 
				    MemoLieferschein: $MemoLieferschein, 
				    MemoLieferschein2:$MemoLieferschein2
				)
				    {
				    Intern
				    OrderReportID
				    LinkLSGruppe
				    MemoLieferschein
				    MemoLieferschein2
                    }
}`;


