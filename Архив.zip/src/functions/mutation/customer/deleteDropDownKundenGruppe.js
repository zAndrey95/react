import gql from 'graphql-tag';

export default gql`
mutation deleteKundenGruppe($Intern: Int){
  deleteKundenGruppe(Intern: $Intern){
    Intern
  }
}
`;
