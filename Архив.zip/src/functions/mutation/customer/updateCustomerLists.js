import gql from 'graphql-tag';

export default gql`
	mutation updateCustomerLists($CustomerListID: Int!, $CustomerListName: String){
  		updateCustomerLists(CustomerListID: $CustomerListID, CustomerListName: $CustomerListName){
    		CustomerListID
    		CustomerListName
  }
}`;
