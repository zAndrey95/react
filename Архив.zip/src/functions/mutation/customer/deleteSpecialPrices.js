import gql from 'graphql-tag';

export default gql`
mutation deleteSpecialPrices($Intern: Int!){
  deleteSpecialPrices(Intern: $Intern) {
    Intern
  }
}`;