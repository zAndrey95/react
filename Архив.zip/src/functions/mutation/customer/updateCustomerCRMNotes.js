import gql from 'graphql-tag';

export default gql`
	mutation updateCustomerCRMNotes(
	    $LinkCustomer: Int, 
		$AddedOn: String, 
		$Note: String, 
		$RecordID: Int
		){
    updateCustomerCRMNotes( 
	    LinkCustomer:$LinkCustomer,
	    AddedOn: $AddedOn, 
		Note: $Note, 
		RecordID: $RecordID, 
	    ) {	
    LinkCustomer
    AddedOn
	Note
	RecordID
	 __typename
    }
}`;