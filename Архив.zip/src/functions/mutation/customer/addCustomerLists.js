import gql from 'graphql-tag';

export default gql`
	mutation addCustomerLists($CustomerListName: String){
		addCustomerLists( CustomerListName: $CustomerListName){
			CustomerListName
			CustomerListID
        }
}`;
