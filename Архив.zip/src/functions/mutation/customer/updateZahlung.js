import gql from 'graphql-tag';

export default gql`
	mutation updateZahlung(
		$LinkPostSector: Int,
		$ZahlungsZiel: Int,
	 	$SkontoInProzent: Float,
	 	$SkontoTage: Int,
	 	$DebitorKonto: Int,
	 	$SAPBetriebsNr: String,
	 	$ErtragKonto: Int,
	 	$Kostenstelle: Int,
	 	$CustomPaymentText: String,
	 	$Intern: Int
	 	){
  			updateZahlung(
  				LinkPostSector: $LinkPostSector
  				ZahlungsZiel: $ZahlungsZiel,
	 			SkontoInProzent: $SkontoInProzent,
	 			SkontoTage: $SkontoTage,
	 			DebitorKonto: $DebitorKonto,
	 			SAPBetriebsNr: $SAPBetriebsNr,
	 			ErtragKonto: $ErtragKonto,
	 			Kostenstelle: $Kostenstelle,
	 			CustomPaymentText: $CustomPaymentText,
	 			Intern: $Intern)
	 			{
	 				LinkPostSector
    		 		ZahlungsZiel
					SkontoInProzent
					SkontoTage
					DebitorKonto
					SAPBetriebsNr
					ErtragKonto
					Kostenstelle
					CustomPaymentText
					Intern
  }
}`;
