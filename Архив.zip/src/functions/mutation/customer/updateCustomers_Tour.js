import gql from 'graphql-tag';

export default gql`
	mutation updateCustomers_Tour
	(		
		$Intern: Int,
		$Ruestplatz: Int,
		$RuestplatzSa: Int,
		$RuestplatzSo: Int,
		$TourenplanImmer: Boolean,
		$TourenplanBemerkung: String,
		$LinkTourenplan: Int,
		$LinkTourenplanSa: Int,
		$LinkTourenplanSo: Int,
		$TourenplanReihenfolge: Int,
		$TourenplanReihenfolgeSa: Int,
		$TourenplanReihenfolgeSo: Int,
		$TourenplanZeit: String,
		$TourenplanZeitSa: Int,
		$TourenplanZeitSo: Int
	)
			{
		        updateCustomers_Tour
		        ( 
				    Intern:$Intern,
				    Ruestplatz: $Ruestplatz, 
				    RuestplatzSa: $RuestplatzSa, 
				    RuestplatzSo: $RuestplatzSo, 
				    TourenplanImmer:$TourenplanImmer, 
				    TourenplanBemerkung: $TourenplanBemerkung, 
				    LinkTourenplan: $LinkTourenplan, 
				    LinkTourenplanSa: $LinkTourenplanSa, 
				    LinkTourenplanSo: $LinkTourenplanSo, 
				    TourenplanReihenfolge: $TourenplanReihenfolge,
				    TourenplanReihenfolgeSa: $TourenplanReihenfolgeSa,
				    TourenplanReihenfolgeSo: $TourenplanReihenfolgeSo,
				    TourenplanZeit: $TourenplanZeit,
					TourenplanZeitSa: $TourenplanZeitSa,
					TourenplanZeitSo: $TourenplanZeitSo
				)
				    {
				    Intern
				    Ruestplatz
				    RuestplatzSa
				    RuestplatzSo
				    TourenplanImmer
				    TourenplanBemerkung
				    LinkTourenplan
				    LinkTourenplanSa
				    LinkTourenplanSo
				    TourenplanReihenfolge
				    TourenplanReihenfolgeSa
				    TourenplanReihenfolgeSo
				    TourenplanZeit
				    TourenplanZeitSa
				    TourenplanZeitSo
				    
                    }
}`;
