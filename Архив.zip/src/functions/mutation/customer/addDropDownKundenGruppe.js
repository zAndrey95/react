import gql from 'graphql-tag';

export default gql`
mutation addKundenGruppe($Gruppe: String){
  addKundenGruppe(Gruppe:$Gruppe){
    Gruppe
  }
}`;