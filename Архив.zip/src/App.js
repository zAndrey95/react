import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';

import Routes from './registration/Routes.js';
import { authUser, signOutUser } from './registration/libs/awsLib.js';
import Main from './main/index.js';

import './style/Main.css'

class App extends Component {
  constructor(props) {
  super(props);

  this.state = {
    isAuthenticated: false,
    isAuthenticating: true
  };
}

  userHasAuthenticated = authenticated => {
    this.setState({ isAuthenticated: authenticated });
  }

  handleLogout = event => {
    signOutUser();

    this.userHasAuthenticated(false);

    this.props.history.push("/login");
  }

  async componentDidMount() {
  try {
    if (await authUser()) {
      this.userHasAuthenticated(true);
    }
  }
  catch(e) {
    alert(e);
  }

  this.setState({ isAuthenticating: false });
}

  render() {
    const childProps = {
      isAuthenticated: this.state.isAuthenticated,
      userHasAuthenticated: this.userHasAuthenticated
    };

    return (
      !this.state.isAuthenticating &&
      <div>
        <div>
        {this.state.isAuthenticated
          ? <Main handleLogout = {this.handleLogout.bind(this)} />
          : <Routes childProps={childProps} />
        }
        </div>
      </div>
    );
  }
}

export default withRouter(App);
