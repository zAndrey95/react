import React from 'react'
import styled from 'styled-components'

import Routes from './Routes'
import Header from '../components/container/header/Header'
import Footer from '../components/container/footer/Footer'

const Main = () => (
  <Background>
	  <Header/>
	  <div className="main">
	  	<Routes/>
	  </div>
	  <Footer/>
  </Background>
);
export default Main;

const Background = styled.div`
  background-color: #f7fdff;
`;
