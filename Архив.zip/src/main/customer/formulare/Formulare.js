import React, { Component } from 'react';
import {Col} from 'react-bootstrap';
import {Route, Switch} from 'react-router-dom';


import Menu from './menu/Menu.js'
import Factura from './table/factura/Factura.js'
import Liefershein from './table/liefershein/Liefershein.js'


class Formulare extends Component {
  render() {
    return (
      
      	<React.Fragment>
            <Col lg={12} >
              <Menu
                intern={this.props.intern}
              />
            </Col>

            <Col lg={12}>
              <Switch>
                  <Route path={'/customers/' + this.props.intern + '/formulare/liefershein'} render={props =>
                    <Liefershein
                        intern={this.props.intern} 
                      /> }
                  />

                  <Route path={'/customers/' + this.props.intern + '/formulare/factura'} render={props =>
                    <Factura  
                      intern={this.props.intern} 
                    /> }
                  />
              </Switch>
            </Col>
        </React.Fragment>   
    );
  }
}

export default Formulare;
