import React, { Component } from 'react';
import { Col, Row } from 'react-bootstrap';
import Modal from 'react-modal';
import { graphql, compose, Query } from 'react-apollo';

import SimpleDropdown from '../../../../../../../../@appElements/dropDown/SimpleDropdown'
import Title from '../../../../../../../../@appElements/title/Title.js';
import Input from '../../../../../../../../@appElements/input/Input.js';
import CheckBox from '../../../../../../../../@appElements/checkBox/CheckBox.js';
import Textarea from '../../../../../../../../@appElements/textarea/Textarea.js';

import getCustomerFormulareLiefershein from '../../../../../../../../functions/query/customer/getCustomerFormulareLiefershein.js'
import selectCustomerLiefersheinFacturaFormular from '../../../../../../../../functions/query/customer/selectCustomerLiefersheinFacturaFormular.js'
import selectCustomerLiefersheinFacturaGroup from '../../../../../../../../functions/query/customer/selectCustomerLiefersheinFacturaGroup.js'

import updateCustomerFormulare from '../../../../../../../../functions/mutation/customer/updateCustomerFormulare.js'
import {Mutations} from '../../../../../../../../@appElements/functions/Mutation.js';

class Liefershein extends Component {

  constructor() {
    super();
    this.state = {
      OrderReportID: 0,
      LinkLSGruppe:"",
      MemoLieferschein:"",
      MemoLieferschein2:"",
      selectForm:["", ""],
      selectGroup:["", ""],
    };
  }

  onCompleted=(props)=>{
    let data = props.getCustomerFormulareLiefershein[0];
    this.setState({
      OrderReportID:data.OrderReportID,
      LinkLSGruppe:data.LinkLSGruppe,
      MemoLieferschein:data.MemoLieferschein,
      MemoLieferschein2:data.MemoLieferschein2,
    })
  }

  onCompletedFormular=(props)=>{
    this.setState({
      selectForm: props.selectCustomerLiefersheinFacturaFormular,
    })
  }

  onCompletedGroup=(props)=>{
    this.setState({
      selectGroup: props.selectCustomerLiefersheinFacturaGroup,
    })
  }

  updateCustomerFormulare=(e)=>{
    const key = e.target.name;
    const value = this.state[key];
    Mutations(
      {[key]: value},
      this.props.updateCustomerFormulare, 
      "Intern",
      this.props.intern
      );
  }

  updateDrop=(LinkGruppe, nameDrop)=>{
    Mutations(
      {[nameDrop]: LinkGruppe? LinkGruppe:this.state[nameDrop]},
      this.props.updateCustomerFormulare, 
      "Intern",
      this.props.intern
      );
    
  }

  getValueOfInput = (event) => {
    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})
  }

  render() {
    console.log(this.props)
    return (
      <Query
        fetchPolicy={"network-only"}
        query={getCustomerFormulareLiefershein}
        onCompleted={this.onCompleted}
        variables={{Intern: this.props.intern }}> 

        {({ loading, error, data }) => {
        if (error) return <div>Error</div>
        return ( 
          <Row style={{padding: "10px 0 0  15px"}}> 
            <Row style={{padding: "10px 0 0  0px"}}> 
              <Col lg={4}>
                <Query
                  fetchPolicy={"network-only"}
                  query={selectCustomerLiefersheinFacturaFormular}
                  onCompleted={this.onCompletedFormular}> 

                  {({ loading, error, data }) => {
                  if (error) return <div>Error</div>
                  return ( 
                    <SimpleDropdown 
                          text="Form" 
                          style={{zIndex: 9}} 
                          list={this.state.selectForm} 
                          row={"Formular"}
                          gruppeId={1} 
                          onBlur={this.updateDrop} 
                          nameDrop={"OrderReportID"}
                        />)}}
                  </Query>
              </Col>
              <Col lg={2} lgOffset={1}>
                <Input
                  width='80%'
                  text='Kopien'
                  value={this.state.MemoLieferschein2}
                  onBlur={this.updateCustomerFormulare}
                  name="MemoLieferschein2"
                  onChange={this.getValueOfInput}
                />
              </Col>
            </Row>

            <Row>
              <Col lg={4}>
               <Query
                  fetchPolicy={"network-only"}
                  query={selectCustomerLiefersheinFacturaGroup}
                  onCompleted={this.onCompletedGroup}> 

                  {({ loading, error, data }) => {
                  if (error) return <div>Error</div>
                  return ( 
                <SimpleDropdown 
                          text="Group delivety note" 
                          style={{zIndex: 9}} 
                          list={this.state.selectGroup} 
                          row={"ResName"}
                          gruppeId={1} 
                          onBlur={this.updateDrop} 
                          nameDrop={"LinkLSGruppe"}
                        />)}}
                </Query>
              </Col>
              <Col lg={8}>
              </Col>
            </Row>

            <Row>
              <Col lg={6}>
                <Textarea 
                  text=" Individual comments on the delivery" 
                  width='100%'
                  value={this.state.MemoLieferschein}
                  onBlur={this.updateCustomerFormulare}
                  name="MemoLieferschein"
                  onChange={this.getValueOfInput}
                  style={{margin: '60px 0px 10px 0px'}}
                />
              </Col>
              <Col lg={6}>
              </Col>
            </Row>
          </Row>
        )}}
      </Query>
    );
  }
}

const graph = compose(
  graphql(updateCustomerFormulare, {name:"updateCustomerFormulare"}),
)(Liefershein);

export default graph;
