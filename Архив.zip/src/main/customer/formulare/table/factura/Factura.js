import React, { Component } from 'react';
import { Col, Row } from 'react-bootstrap';

import SimpleDropdown from '../../../../../../../../@appElements/dropDown/SimpleDropdown'
import Input from '../../../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../../../@appElements/textarea/Textarea.js'

import { graphql, compose, Query } from 'react-apollo';

import getCustomerFormulareFactura from '../../../../../../../../functions/query/customer/getCustomerFormulareFactura.js'

import updateCustomerFormulareLiefershein from '../../../../../../../../functions/mutation/customer/updateCustomerFormulareLiefershein.js'
import {Mutations} from '../../../../../../../../@appElements/functions/Mutation.js';

import selectCustomerFormulareFacturaAdchnung from '../../../../../../../../functions/query/customer/selectCustomerFormulareFacturaAdchnung.js'
import selectCustomerFormulareFacturaDebitor from '../../../../../../../../functions/query/customer/selectCustomerFormulareFacturaDebitor.js'
import selectCustomerFormulareFacturaForm from '../../../../../../../../functions/query/customer/selectCustomerFormulareFacturaForm.js'
import selectCustomerFormulareFacturaInvoice from '../../../../../../../../functions/query/customer/selectCustomerFormulareFacturaInvoice.js'
import selectCustomerFormulareFacturaPayment from '../../../../../../../../functions/query/customer/selectCustomerFormulareFacturaPayment.js'





class Factura extends Component {
  constructor() {
    super();
    this.state = {
      InvoiceReportID:1,
      InvoiceSummaryReportID:1,
      InvoicePaymentSlipReportID:1,
      FakturaAbrechnung:1,
      DebitorStatus:1,
      InvoiceCopies: "",
      BemerkungFaktura:"",
      selectForm: ["", ""],
      selectCurrency: ["", ""],
      selectSummary: ["", ""],
      selectPaymant: ["", ""],
      selectAccounting: ["", ""],
      
    };
  }

  onCompleted=(props)=>{
    console.log(props)
    let data = props.getCustomerFormulareFactura[0];
    this.setState({
      InvoiceReportID:data.InvoiceReportID,
      InvoiceSummaryReportID:data.InvoiceSummaryReportID,
      InvoicePaymentSlipReportID:data.InvoicePaymentSlipReportID,
      FakturaAbrechnung:data.FakturaAbrechnung,
      InvoiceCopies:data.InvoiceCopies,
      DebitorStatus:data.DebitorStatus,
      BemerkungFaktura:data.BemerkungFaktura,
    })
  }

  onCompletedForm=(props)=>{
    console.log(props)
    let data = props.selectCustomerFormulareFacturaForm;
    this.setState({
      selectForm:data
    })
  }

  onCompletedCurrency=(props)=>{
    console.log(props)
    let data = props.selectCustomerFormulareFacturaDebitor;
    this.setState({
      selectCurrency:data
    })
  }

  onCompletedSummary=(props)=>{
    console.log(props)
    let data = props.selectCustomerFormulareFacturaInvoice;
    this.setState({
      selectSummary:data
    })
  }

  onCompletedPaymant=(props)=>{
    console.log(props)
    let data = props.selectCustomerFormulareFacturaPayment;
    this.setState({
      selectPaymant:data
    })
  }

  onCompletedAccounting=(props)=>{
    console.log(props)
    let data = props.selectCustomerFormulareFacturaAdchnung;
    this.setState({
      selectAccounting:data
    })
  }



  updateCustomerFormulareLiefershein=(e)=>{
    const key = e.target.name;
    const value = this.state[key];
    Mutations(
      {[key]: value},
      this.props.updateCustomerFormulareLiefershein, 
      "Intern",
      this.props.intern
      );
  }

  updateDrop=(newId, nameIdInState)=>{
    Mutations(
      {[nameIdInState]: newId? newId:this.state[nameIdInState]},
      this.props.updateCustomerFormulareLiefershein, 
      "Intern",
      this.props.intern
      );
    
  }

  getValueOfInput = (event) => {
    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})
  }


  render() {
    console.log(this.props)
    return (
       <Query
          fetchPolicy={"network-only"}
          query={getCustomerFormulareFactura}
          onCompleted={this.onCompleted}
          variables={{Intern: this.props.intern}}
        > 

          {({ loading, error, data }) => {

            if (error) return <div>Error</div>

            return ( 
              <Row  style={{padding:"15px 0 0 15px"}}>
                <Row>
                  <Col lg={4}>
                    <Query
                      fetchPolicy={"network-only"}
                      query={selectCustomerFormulareFacturaForm}
                      onCompleted={this.onCompletedForm}> 

                      {({ loading, error, data }) => {

                      if (error) return <div>Error</div>

                      return ( 
                        <SimpleDropdown 
                          text="Form" 
                          style={{zIndex: 9}} 
                          list={this.state.selectForm} 
                          row={"Formular"}
                          gruppeId={1} 
                          onBlur={this.updateDrop} 
                          nameDrop={"InvoiceReportID"}
                        />
                      )}}
                    </Query>
                  </Col>
                  <Col lg={1} lgOffset={1}>
                    <Input
                      width='100%'
                      text='Copies'
                      value={this.state.InvoiceCopies}
                      onBlur={this.updateCustomerFormulareLiefershein}
                      name="InvoiceCopies"
                      onChange={this.getValueOfInput}
                    />
                  </Col>
                  <Col lg={4} lgOffset={1}>
                    <Query
                      fetchPolicy={"network-only"}
                      query={selectCustomerFormulareFacturaDebitor}
                      onCompleted={this.onCompletedCurrency}> 

                      {({ loading, error, data }) => {

                      if (error) return <div>Error</div>

                      return ( 
                        <SimpleDropdown 
                          text="Invoice currency" 
                          style={{zIndex: 9}} 
                          list={this.state.selectCurrency} 
                          row={"DebitorStatusName"}
                          gruppeId={1} 
                          onBlur={this.updateDrop} 
                          nameDrop={"FakturaAbrechnung"}
                        />
                      )}}
                    </Query>
                  </Col>
                </Row>
                <Row>
                  <Col lg={4}>
                    <Query
                      fetchPolicy={"network-only"}
                      query={selectCustomerFormulareFacturaInvoice}
                      onCompleted={this.onCompletedSummary}> 

                      {({ loading, error, data }) => {

                      if (error) return <div>Error</div>

                      return ( 
                        <SimpleDropdown 
                          text=" Invoice summary form " 
                          style={{zIndex: 8}} 
                          list={this.state.selectSummary} 
                          row={"Formular"}
                          gruppeId={1} 
                          onBlur={this.updateDrop}  
                          nameDrop={"InvoiceSummaryReportID"}
                        />
                      )}}
                    </Query>
                  </Col>
                  <Col lg={4} lgOffset={3}>
                    <Query
                      fetchPolicy={"network-only"}
                      query={selectCustomerFormulareFacturaPayment}
                      onCompleted={this.onCompletedPaymant}> 

                      {({ loading, error, data }) => {

                      if (error) return <div>Error</div>

                      return ( 
                        <SimpleDropdown 
                          text="Paymant slip form" 
                          style={{zIndex: 7}} 
                          list={this.state.selectPaymant} 
                          row={"Formular"}
                          gruppeId={1} 
                          onBlur={this.updateDrop} 
                          nameDrop={"InvoicePaymentSlipReportID"}
                        />
                      )}}
                    </Query>
                  </Col>
                </Row>
                <Row>
                  <Col lg={4}>
                    <Query
                      fetchPolicy={"network-only"}
                      query={selectCustomerFormulareFacturaAdchnung}
                      onCompleted={this.onCompletedAccounting}> 

                      {({ loading, error, data }) => {

                      if (error) return <div>Error</div>

                      return ( 
                        <SimpleDropdown 
                          text="Accounting" 
                          style={{zIndex: 6}} 
                          list={this.state.selectAccounting} 
                          row={"InvoiceIntervalName"}
                          gruppeId={1} 
                          onBlur={this.updateDrop}  
                          nameDrop={"DebitorStatus"}
                        />
                      )}}
                    </Query>
                  </Col>
                </Row>
                <Row>
                  <Col lg={6}>
                    <Textarea 
                      text=" Individual comments on the invoice" 
                      width='100%'
                      value={this.state.BemerkungFaktura}
                      onBlur={this.updateCustomerFormulareLiefershein}
                      name="BemerkungFaktura"
                      onChange={this.getValueOfInput}
                      style={{margin: '50px 0px 10px 0px'}}
                    />
                  </Col>
                </Row>
              </Row>
          )}}
        </Query>
    );
  }
}

const graph = compose(
  graphql(updateCustomerFormulareLiefershein, {name:"updateCustomerFormulareLiefershein"}),
)(Factura);
export default graph;
