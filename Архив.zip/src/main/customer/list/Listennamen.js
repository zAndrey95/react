'use strict'; 
import React, { Component } from 'react';
import {Col} from 'react-bootstrap';
import Modal from 'react-modal';
import { graphql, compose } from 'react-apollo';
import {objectIntoDropdownArray} from '../../../../../storeFunctions.js'

import cancel_black from '../../../../../../img/cancel_black.svg';
import add_color from '../../../../../../img/add_color.svg';
import delete_color from '../../../../../../img/delete_color.svg';

import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';

import AllCustomer_Lists from '../../../../../../functions/query/customer/allCustomer_Lists.js'
import GetfkCustomerListsRelations from '../../../../../../functions/query/customer/getfkCustomerListsRelations.js'

import updateCustomerLists from '../../../../../../functions/mutation/customer/updateCustomerLists.js'
import addCustomerLists from '../../../../../../functions/mutation/customer/addCustomerLists.js'
import deleteCustomerLists from '../../../../../../functions/mutation/customer/deleteCustomerLists.js'
import addfkCustomerListsRelations from '../../../../../../functions/mutation/customer/addfkCustomerListsRelations.js'
import deletefkCustomerListsRelations from '../../../../../../functions/mutation/customer/deletefkCustomerListsRelations.js'

import updateCustomerListsSub from '../../../../../../functions/subscription/customer/updateCustomerListsSub.js'
import deleteCustomerListsSub from '../../../../../../functions/subscription/customer/deleteCustomerListsSub.js'
import addCustomerListsSub from '../../../../../../functions/subscription/customer/addCustomerListsSub.js'

class Listennamen extends Component {

  constructor() {
    super();
    this.state = {
      listName: '',
      modalIsOpen: false,
      listArray: [],
      listIndex: 0,
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.getValueOfInput = this.getValueOfInput.bind(this);
    this.updateCustomerLists = this.updateCustomerLists.bind(this);
    this.addCustomerLists = this.addCustomerLists.bind(this);
    this.deleteCustomerLists = this.deleteCustomerLists.bind(this);
  }

  openModal() {
    this.setState({modalIsOpen: true});
  }

  checkedValueInCheckbox(number){
    for(let key in this.props.GetfkCustomerListsRelations.getfkCustomerListsRelations){
      if(this.props.GetfkCustomerListsRelations.getfkCustomerListsRelations[key].LinkCustomerList == number){
        return true
      } 
    }
  }

  updateCustomerLists(){
    this.props.updateCustomerLists({
      variables: {
        CustomerListID:this.state.listIndex,
        CustomerListName: this.state.listName, 
      },
      options: {
        fetchPolicy: 'network-only'
      }
    })
  }

  addCustomerLists(){
    this.props.addCustomerLists({
      variables: {
        CustomerListName: '', 
      },
      options: {
        fetchPolicy: 'network-only'
      }
    })
  }

  deleteCustomerLists(){
    this.props.deleteCustomerLists({
      variables: {
        CustomerListID: this.state.listIndex, 
      },
      options: {
        fetchPolicy: 'network-only'
      }
    })

  }


  getValueOfInput(event){
    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})
  }

  addValueOfInput(event, index){
    this.setState({listName: event, listIndex: index})
  }

  closeModal() {
    this.setState({modalIsOpen: false});
  }

  componentDidMount(){
  }
  
  render() {
      return (
            <div className="modal_main">
                <Col lg={12} md={12} sm={12} xs={12} className="List_modal_header">
                <div className="List_modal_main text_modal">
                  <Col lg={11} md={11} sm={11} xs={11} className="text_header_List">
                    <Col lg={4} md={4} sm={4} xs={4} className='hr_modal_list'>
                      <span className='list_modal_Listennamen'>Listennamen</span>
                    </Col>
                     <Col lg={8} md={8} sm={8} xs={8}>
                     </Col>
                  </Col>
                  <Col lg={1} md={1} sm={1} xs={1}>
                    <div className="close_modal">
                      <img  className="img_modal" src={cancel_black} alt=""  onClick={this.props.closeModal}/>
                    </div>
                  </Col>
                  </div>
                </Col>

                <Col lg={12} md={12} sm={12} xs={12}>
                  <Col lg={5} md={5} sm={5} xs={5} className='listItems_list_modal'>
                    <Col lg={12} md={12} sm={12} xs={12} className='actionMenu_modal_list'>
                      <Col lg={1} md={1} sm={1} xs={1}>
                      </Col>
                      <Col lg={1} md={1} sm={1} xs={1} className='img_list_modal'>

                        <img src={add_color} onClick={this.addCustomerLists} />
                      </Col>
                      <Col lg={2} md={2} sm={2} xs={2}>
                      </Col>
                      <Col lg={1} md={1} sm={1} xs={1} className='img_list_modal'>
                        <img src={delete_color} onClick={this.deleteCustomerLists}/>
                      </Col>
                      <Col lg={7} md={7} sm={7} xs={7}>
                      </Col>
                    </Col>
                     <Col lg={12} md={12} sm={12} xs={12} className="list_modal_name">
                        <span>Name:</span>
                     </Col>
                     <Col lg={12} md={12} sm={12} xs={12} className='items_modal_list'>
                        {this.props.allCustomer_Lists.map((item, index) => {
                          return(<Col lg={12} md={12} sm={12} xs={12} key={index} onClick={this.props.addValueOfInput.bind(this,item.CustomerListName, item.CustomerListID)}>{item.CustomerListName}</Col>)
                        })}
                     </Col>
                  </Col>
                  <Col lg={7} md={7} sm={7} xs={7} className='rightContent_modal_lit_customer'> 
                    <Col lg={12} md={12} sm={12} xs={12}>
                      <Col lg={7} md={7} sm={7} xs={7} className='hr_modal_Dauerkunde_list_customer'> 
                        <span>{this.state.listName}</span>
                      </Col>
                      <Col lg={5} md={5} sm={5} xs={5}> 
                      
                      </Col>
                    </Col>
                    <Col lg={12} md={12} sm={12} xs={12}>
                      <Col lg={7} md={7} sm={7} xs={7} className='name_modal_list_customer'> 
                        <span>Name:</span>
                        <input value={this.props.listName} className='input_modal_list_customer' onChange={this.props.getValueOfInput} name='listName' onBlur={this.props.updateCustomerLists}/>
                      </Col>
                      <Col lg={5} md={5} sm={5} xs={5}> 
                      
                      </Col>
                    </Col>
                    <Col lg={12} md={12} sm={12} xs={12} className='button_modal_list_customer'>
                      <button onClick={this.props.closeModal}> <img src={cancel_black}/> <span>Speichern</span></button>
                    </Col>
                  </Col>
                </Col>

              </div> 
      );
    }
}



export default Listennamen;
