import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import Modal from 'react-modal';
import { graphql, compose } from 'react-apollo';
import styled from 'styled-components';
import {objectIntoDropdownArray} from '../../../../../storeFunctions.js'


import cancel_black from '../../../../../../img/cancel_black.svg';
import add_color from '../../../../../../img/add_color.svg';
import delete_color from '../../../../../../img/delete_color.svg';

import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';
import Button from '../../../../../../@appElements/button/Button.js';

import Listennamen from './Listennamen.js'

import AllCustomer_Lists from '../../../../../../functions/query/customer/allCustomer_Lists.js'
import GetfkCustomerListsRelations from '../../../../../../functions/query/customer/getfkCustomerListsRelations.js'

import updateCustomerLists from '../../../../../../functions/mutation/customer/updateCustomerLists.js'
import addCustomerLists from '../../../../../../functions/mutation/customer/addCustomerLists.js'
import deleteCustomerLists from '../../../../../../functions/mutation/customer/deleteCustomerLists.js'
import addfkCustomerListsRelations from '../../../../../../functions/mutation/customer/addfkCustomerListsRelations.js'
import deletefkCustomerListsRelations from '../../../../../../functions/mutation/customer/deletefkCustomerListsRelations.js'

import updateCustomerListsSub from '../../../../../../functions/subscription/customer/updateCustomerListsSub.js'
import deleteCustomerListsSub from '../../../../../../functions/subscription/customer/deleteCustomerListsSub.js'
import addCustomerListsSub from '../../../../../../functions/subscription/customer/addCustomerListsSub.js'

import './List.css';

const customStyles = {
      content : {
        top                   : '50%',
        left                  : '50%',
        right                 : 'auto',
        bottom                : 'auto',
        marginRight           : '-50%',
        transform             : 'translate(-50%, -50%)',
        width                 : "650px",
        height                : "550px",
        padding               : '-10px 0 0 0',

      }
    };


const Line = styled.div`
  border-bottom: solid 1px #979797;
`;



class List extends Component {

  constructor() {
    super();
    this.state = {
      listName: '',
      modalIsOpen: false,
      listArray: [],
      listIndex: 0,
    };

    this.closeModal = this.closeModal.bind(this);

    this.updateCustomerLists = this.updateCustomerLists.bind(this);
    this.addCustomerLists = this.addCustomerLists.bind(this);
    this.deleteCustomerLists = this.deleteCustomerLists.bind(this);
  }

  

  checkedValueInCheckbox(number){
    for(let key in this.props.GetfkCustomerListsRelations.getfkCustomerListsRelations){
      if(this.props.GetfkCustomerListsRelations.getfkCustomerListsRelations[key].LinkCustomerList == number){
        return true
      } 
    }
  }

  updateCustomerLists = () => {
    this.props.updateCustomerLists({
      variables: {
        CustomerListID:this.state.listIndex,
        CustomerListName: this.state.listName, 
      },
      options: {
        fetchPolicy: 'network-only'
      }
    })
  }

  addCustomerLists(){
    this.props.addCustomerLists({
      variables: {
        CustomerListName: '', 
      },
      options: {
        fetchPolicy: 'network-only'
      }
    })
  }

  deleteCustomerLists(){
    this.props.deleteCustomerLists({
      variables: {
        CustomerListID: this.state.listIndex, 
      },
      options: {
        fetchPolicy: 'network-only'
      }
    })

  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if(!nextProps.AllCustomer_Lists.loading){
      const  store = nextProps.AllCustomer_Lists.allCustomer_Lists;
      if(store !== prevState){
        return {
          listArray: store,
        }
      }
      return null
    }
    return null
  }

  getValueOfInput = (event) => {
    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})
  }

  addValueOfInput = (event, index) => {
    this.setState({listName: event, listIndex: index})
  }

  openModal = () => {
    this.setState({modalIsOpen: true});
  }
  closeModal= () => {
    this.setState({modalIsOpen: false});
  }

  componentDidMount(){
    this.props.subscribeToUpdCustomer();
    this.props.subscribeToDellCustomer();
    this.props.subscribeToAddProduct();
  }
  
  render() {
        if(this.props.GetfkCustomerListsRelations && this.props.AllCustomer_Lists.loading){ return null}
          else{
    const listArticel_Konditionen = this.props.AllCustomer_Lists.allCustomer_Lists.map((item, index) => {
      return (
          <Col lg={4}>
              <CheckBox value={item.CustomerListName} style={{margin:"20px 0 0 0"}} open={this.checkedValueInCheckbox(item.CustomerListID)}/>
          </Col>
        );
      });

      return (
        <Row style={{padding: "0 0 0 15px"}}>
           <Modal
           style={customStyles}
              isOpen={this.state.modalIsOpen}
              onAfterOpen={this.afterOpenModal}
              onRequestClose={this.closeModal}
              contentLabel="Example Modal"
            >
              <div className="modal_main">
                <Col lg={12} className="List_modal_header">
                <div className="List_modal_main text_modal">
                  <Col lg={11} className="text_header_List">
                    <Col lg={4} className='hr_modal_list'>
                      <span className='list_modal_Listennamen'>Listennamen</span>
                    </Col>
                     <Col lg={8}>
                     </Col>
                  </Col>
                  <Col lg={1}>
                    <div className="close_modal">
                      <img  className="img_modal" src={cancel_black} alt=""  onClick={this.closeModal}/>
                    </div>
                  </Col>
                  </div>
                </Col>

                <Col lg={12}>
                  <Col lg={5} className='listItems_list_modal'>
                    <Col lg={12} className='actionMenu_modal_list'>
                      <Col lg={1}>
                      </Col>
                      <Col lg={1} className='img_list_modal'>

                        <img src={add_color} onClick={this.addCustomerLists} />
                      </Col>
                      <Col lg={2}>
                      </Col>
                      <Col lg={1} className='img_list_modal'>
                        <img src={delete_color} onClick={this.deleteCustomerLists}/>
                      </Col>
                      <Col lg={7}>
                      </Col>
                    </Col>
                     <Col lg={12} className="list_modal_name">
                        <span>Name:</span>
                     </Col>
                     <Col lg={12} className='items_modal_list'>
                        {this.props.AllCustomer_Lists.allCustomer_Lists.map((item, index) => {
                          return(<Col lg={12} key={index} onClick={this.addValueOfInput.bind(this,item.CustomerListName, item.CustomerListID)}>{item.CustomerListName}</Col>)
                        })}
                     </Col>
                  </Col>
                  <Col lg={7} className='rightContent_modal_lit_customer'> 
                    <Col lg={12}>
                      <Col lg={7} className='hr_modal_Dauerkunde_list_customer'> 
                        <span>{this.state.listName}</span>
                      </Col>
                      <Col lg={5}> 
                      
                      </Col>
                    </Col>
                    <Col lg={12}>
                      <Col lg={7} className='name_modal_list_customer'> 
                        <span>Name:</span>
                        <input value={this.state.listName} className='input_modal_list_customer' onChange={this.getValueOfInput} name='listName' onBlur={this.updateCustomerLists}/>
                      </Col>
                      <Col lg={5}> 
                      
                      </Col>
                    </Col>
                    <Col lg={12} className='button_modal_list_customer'>
                      <button> <img src={cancel_black}/> <span>Speichern</span></button>
                    </Col>
                  </Col>
                </Col>

              </div> 

            </Modal>

          <Row>
            <Col lg={4} >
              <Button paddingTop="13px" text="Listennamen" top="32px" width="177px" color="#4a90e2" size="20px" height="42px" onClick={this.openModal}/>
              <Col lg={12} style={{"border-bottom": "solid 1px #979797", margin:"0 0 0 -15px", height:"20px"}}>
              </Col>
            </Col>
            <Col lg={8}>
            </Col>
          </Row>
          <Col lg={12}>
            {listArticel_Konditionen}
          </Col>
        </Row>
      );
    }
  }
}

const graph = compose(graphql(AllCustomer_Lists, {   name:"AllCustomer_ListsSub",

options: (props) => ({

            fetchPolicy: 'network-only',
            variables: {SearchValue: props.searchValue, From:0},


        }),

          props: (props) => ({

            subscribeToDellCustomer: params => {
                props.AllCustomer_ListsSub.subscribeToMore({
                    document: deleteCustomerListsSub,
                                        updateQuery: (prev, { subscriptionData: { data : { deleteCustomerListsSub}}  }) => ({
                        ...prev,
                        allCustomer_Lists:  [...prev.allCustomer_Lists.filter(item => item.CustomerListID !== deleteCustomerListsSub.CustomerListID)], __typename: 'Customer_Lists',
                    }),

                });
            },

            subscribeToAddProduct: params => {
                props.AllCustomer_ListsSub.subscribeToMore({
                    document: addCustomerListsSub,
                                        updateQuery: (prev, { subscriptionData: { data : { addCustomerListsSub}}  }) => ({
                        ...prev,
                        allCustomer_Lists:  [addCustomerListsSub, ...prev.allCustomer_Lists], __typename: 'Customer_Lists',
                    }),

                });
            },

            subscribeToUpdCustomer: params => {
                props.AllCustomer_ListsSub.subscribeToMore({
                    document: updateCustomerListsSub,
                      updateQuery: (prev, { subscriptionData: { data : { updateCustomerListsSub}}  }) => ({
                         ...prev,
                         allCustomer_Lists: [ ...prev.allCustomer_Lists.map(function(nameCustomer){
                            return List();
                            function List(){
                              if(nameCustomer.CustomerListID === updateCustomerListsSub.CustomerListID){return updateCustomerListsSub} 
                              else{return nameCustomer}
                          }
                        }
                          )] , __typename: 'Customer_Lists',
                    }),
                });
            },
        }
    )
})
,
    graphql(updateCustomerLists, {name: "updateCustomerLists"}),
    graphql(addCustomerLists, {name: "addCustomerLists"}),
    graphql(deleteCustomerLists, {name: "deleteCustomerLists"}),
    graphql(AllCustomer_Lists, {name: "AllCustomer_Lists"}),
    graphql(GetfkCustomerListsRelations, {
        options: (props) => ({
            fetchPolicy: 'network-only',
            variables: {
              LinkCustomer: props.intern,
            }
        }),
        name: "GetfkCustomerListsRelations",
}),
)(List);

export default graph;
