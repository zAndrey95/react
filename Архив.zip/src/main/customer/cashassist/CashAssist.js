import React, { Component } from 'react';
import {  Row, Col} from 'react-bootstrap';
import { graphql, compose } from 'react-apollo';

import {objectIntoDropdownArray} from '../../../../../storeFunctions.js'

import SimpleDropdown from '../../../../../../@appElements/dropDown/SimpleDropdown'
import Title from '../../../../../../@appElements/title/Title.js';
import Input from '../../../../../../@appElements/input/Input.js';
import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';


import {Mutations} from '../../../../../../@appElements/functions/Mutation.js';


import updateCustomer from '../../../../../../functions/mutation/customer/updateCustomer.js'

import AllCustomerInfo from '../../../../../../functions/query/customer/allCustomerInfo.js'
import View_fkReductionsAndPricesTakeFromKinds from '../../../../../../functions/query/customer/view_fkReductionsAndPricesTakeFromKinds.js'

class CashAssist extends Component {

  constructor() {
    super();
    this.state = {
      cashAssistPrice: 0,
      IsCashAssistKredit: false,
      allReductionsAndPricesTakeFromKinds: [],
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if(!nextProps.AllCustomerInfo.loading){
      const  store = nextProps.AllCustomerInfo.allCustomerInfo[0];
      if(store !== prevState){
        return {
          cashAssistPrice: store.cashAssistPrice,
          IsCashAssistKredit: store.IsCashAssistKredit,
          allReductionsAndPricesTakeFromKinds: nextProps.View_fkReductionsAndPricesTakeFromKinds.view_fkReductionsAndPricesTakeFromKinds
        }
      }
      return null
    }
    return null
  }

  updateCustomerCheckbox=(e)=>{
    Mutations(
      {IsCashAssistKredit: !this.state.IsCashAssistKredit},
      this.props.updateCustomer, 
      "id",
      this.props.intern
      );

    this.setState({IsCashAssistKredit: !this.state.IsCashAssistKredit})
  }

  updateDrop=(Id)=>{
    Mutations(
      {cashAssistPrice: Id},
      this.props.updateCustomer, 
      "id",
      this.props.intern
      );
  }


    
  render() {
    return (
      <Row style={{padding: "0 0 0 15px"}}>
        <Col lg={5}>
          <Title text="CashAssist"/>
          <SimpleDropdown 
            text="Take reductions and prices from…"
            row={"ReductionsAndPricesKindName"}
            style={{zIndex: 12}} 
            list={this.state.allReductionsAndPricesTakeFromKinds} 
            gruppeId={this.state.cashAssistPrice} 
            onBlur={this.updateDrop}/>
          <CheckBox 
            onClick={this.updateCustomerCheckbox}
            value={'Kreditkunde CashAssist'} 
            style={{'margin': '24px 0 0 0px'}} 
            open={this.state.IsCashAssistKredit} /> 
        </Col>
        <Col lg={7}>
        </Col>
      </Row>
    );
  }
}

const graph = compose(
  graphql(AllCustomerInfo, {
    options: (props) => ({
      fetchPolicy: 'network-only',
      variables: {
        id: props.intern,
      }
    }),
    name: "AllCustomerInfo",
  }
),
  graphql(View_fkReductionsAndPricesTakeFromKinds, {
    name: "View_fkReductionsAndPricesTakeFromKinds"
  }),
  graphql(updateCustomer, {name:"updateCustomer"}),
  )(CashAssist);

export default graph;
