import React, { Component } from 'react';
import {Col} from 'react-bootstrap';
import Modal from 'react-modal';
import { graphql, compose } from 'react-apollo';
import { NavLink} from 'react-router-dom';
import {Route, Switch} from 'react-router-dom';

import './Vorgadedestellung.css';

import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';
import ImgSevenVorgadedestellung from './ImgSevenVorgadedestellung.js';


import iconWochentage2 from '../../../../../../img/iconWochentage2.svg'
import cancel_black from '../../../../../../img/cancel_black.svg';
import cancel_grey from '../../../../../../img/cancel_grey.svg';
import ok_green from '../../../../../../img/ok_green.svg';
import calendar_celebration_2_grey from '../../../../../../img/calendar_celebration_2_grey.svg';
import calendar_celebration_grey from '../../../../../../img/calendar_celebration_grey.svg';
import add_color from '../../../../../../img/add_color.svg';
import edit from '../../../../../../img/edit.svg';
import delete_color from '../../../../../../img/delete_color.svg';

import icon_print from '../../../../../../img/print.svg' 
import icon_search from '../../../../../../img/icon_search.png' 
import icon_agenda from '../../../../../../img/icon_agenda.svg' 
import icon_settings_color from '../../../../../../img/icon_settings_color.svg' 

import icon_Sun from '../../../../../../img/icon_Sun.svg';
import icon_Fri from '../../../../../../img/icon_Fri.svg';
import icon_Mon from '../../../../../../img/icon_Mon.svg';
import icon_Sat from '../../../../../../img/icon_Sat.svg';
import icon_Wed from '../../../../../../img/icon_Wed.svg';
import icon_Thu from '../../../../../../img/icon_Thu.svg';
import icon_Tue from '../../../../../../img/icon_Tue.svg';
import icon_Sun2 from '../../../../../../img/icon_Sun2.svg';
import icon_Fri2 from '../../../../../../img/icon_Fri2.svg';
import icon_Mon2 from '../../../../../../img/icon_Mon2.svg';
import icon_Sat2 from '../../../../../../img/icon_Sat2.svg';
import icon_Wed2 from '../../../../../../img/icon_Wed2.svg';
import icon_Thu2 from '../../../../../../img/icon_Thu2.svg';
import icon_Tue2 from '../../../../../../img/icon_Tue2.svg';

import updateCustomerCalendar from '../../../../../../functions/mutation/customer/updateCustomerCalendar.js'

import AllCustomerInfoCalendar from '../../../../../../functions/query/customer/allCustomerInfoCalendar.js'




const customStyles = {
  content : {
    top                   : '50%',
    left                  : '50%',
    right                 : 'auto',
    bottom                : 'auto',
    marginRight           : '-50%',
    transform             : 'translate(-50%, -50%)',
    width                 : '717px',
    'min-height'               : '556px',
    padding               : '-10px 0 10px 0',

  }
};

// Make sure to bind modal to your appElement (http://reactcommunity.org/react-modal/accessibility/)
Modal.setAppElement('#root')

class ModalWochentage extends Component {
  constructor(props) {
    super(props);
    this.state = {
        modalIsOpen: false,
        textarea:[],
        active: {
          Monday: true,
          Tuesday: 0,
          Wednesday: 0,
          Thursday: 0,
          Friday: 0,
          Sunday: 0,
          Saturday: 0,
        },
    
    };
    this.addDaysInTextArea=this.addDaysInTextArea.bind(this);

  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if(!nextProps.AllCustomerInfoCalendar.loading){
      const  store = nextProps.AllCustomerInfoCalendar.allCustomerInfo[0];
        return {
          list: store,
          active: {
          Monday: store.isMonday,
          Tuesday: store.isTuesday,
          Wednesday: store.isWednesday,
          Thursday: store.isThursday,
          Friday: store.isFriday,
          Sunday: store.isSaturday,
          Saturday: store.isSunday,
        },
        }
      return null
    }

    return null
  }

showDaysInTextArea(){
 let textarea = [];
 for(let key in this.state.active){
  if(this.state.active[key]){
    let index = textarea.indexOf(key+", ");
    index===-1?textarea.push(key+", "):textarea.splice(index, 1);
    }
  }
  this.setState({textarea: textarea})
}


addDaysInTextArea(value){

  let index = this.state.textarea.indexOf(value+", ");
  index===-1?this.state.textarea.push(value+", "):this.state.textarea.splice(index, 1);
  
}

componentDidMount(){
    if(!this.props.AllCustomerInfoCalendar.loading){
          this.showDaysInTextArea();
    }
    return null


}



  render() {
        if(this.props.AllCustomerInfoCalendar.loading){return null}
          else{
    const listDay = this.state.textarea.map((item, index)=>{return(<React.Fragment key={index}>{item}</React.Fragment>)});
    return(
   <div>
                                <Col lg={12}  className="seven_Vorgadedestellung">
                                  <Col lg={1}>
                                  </Col>

                                  <Col lg={1} className='seven_Vorgadedestellung_img'>
                                    <ImgSevenVorgadedestellung src={icon_Mon} src2={icon_Mon2} value={"Monday"} addDaysInTextArea={this.addDaysInTextArea} active={this.state.active.Monday}/>
                                  </Col>

                                  <Col lg={3}>
                                    <Col lg={2}>
                                    </Col>

                                    <Col lg={4}>
                                      <ImgSevenVorgadedestellung src={icon_Tue} src2={icon_Tue2} value={'Tuesday'} addDaysInTextArea={this.addDaysInTextArea} active={this.state.active.Tuesday}/>
                                    </Col>

                                    <Col lg={2}>
                                    </Col>

                                    <Col lg={4}>
                                      <ImgSevenVorgadedestellung src={icon_Wed} src2={icon_Wed2} value={'Wednesday'} addDaysInTextArea={this.addDaysInTextArea} active={this.state.active.Wednesday}/>
                                    </Col>

                                  </Col>
                                  <Col lg={3}>
                                    <Col lg={2}>

                                    </Col>
                                    <Col lg={4}>
                                      <ImgSevenVorgadedestellung src={icon_Thu} src2={icon_Thu2} value={'Thursday'} addDaysInTextArea={this.addDaysInTextArea} active={this.state.active.Thursday}/>
                                    </Col>
                                    <Col lg={2}>

                                    </Col>
                                    <Col lg={4}>
                                      <ImgSevenVorgadedestellung src={icon_Fri} src2={icon_Fri2} value={'Friday'} addDaysInTextArea={this.addDaysInTextArea} active={this.state.active.Friday}/>
                                    </Col>

                                  </Col>
                                  <Col lg={3}>
                                    <Col lg={2}>

                                    </Col>
                                    <Col lg={4}>
                                      <ImgSevenVorgadedestellung src={icon_Sat} src2={icon_Sat2} value={'Saturday'} addDaysInTextArea={this.addDaysInTextArea} active={this.state.active.Saturday}/>
                                    </Col>
                                    <Col lg={2}>

                                    </Col>
                                    <Col lg={4}>
                                      <ImgSevenVorgadedestellung src={icon_Sun} src2={icon_Sun2} value={'Sunday'} addDaysInTextArea={this.addDaysInTextArea} active={this.state.active.Sunday}/>
                                    </Col>

                                  </Col>
                                  <Col lg={1}>
                                  </Col>

                                </Col>


                                  <div>
              <Col lg={12} className="text_Vorschau_Vorgadedestellung">
                  
              </Col>
            </div>

            <div>
              <Col lg={12} className="text_textarea_Vorgadedestellung">
                 <div>{listDay}</div>
              </Col>
            </div>

            <div>
              <Col lg={12} className="hr_Vorgadedestellung">

              </Col>
            </div>

                              </div>





);}
}
}

const graph = compose(
    graphql(AllCustomerInfoCalendar, {
      options: (props) => ({
        fetchPolicy: 'network-only',
          variables: {id: props.intern},
        }),
        name: "AllCustomerInfoCalendar"}),
    )(ModalWochentage);

export default graph;