import React, { Component } from 'react';
import {Col} from 'react-bootstrap';

import './ImgSevenVorgadedestellung.css';


class ImgSevenVorgadedestellung extends Component {
     constructor(props) {
      super(props);
      this.state={
        active: this.props.active,
        name: [this.props.value]
      }
      this.getActive = this.getActive.bind(this);
    }

getActive(){
  this.setState({active: !this.state.active});

}

  render() {
    return (<div className="ImgSevenVorgadedestellung_padding" onClick={this.getActive}>
              <Col lg={12} className="ImgSevenVorgadedestellung" onClick={this.props.addDaysInTextArea.bind(this, this.props.value)}>
                  <img src={this.state.active?this.props.src : this.props.src2} alt=""/>
              </Col>
            </div>
              )}}

export default ImgSevenVorgadedestellung;
