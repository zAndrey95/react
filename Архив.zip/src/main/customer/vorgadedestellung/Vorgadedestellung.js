import React, { Component } from 'react';
import {Col} from 'react-bootstrap';
import Modal from 'react-modal';
import { graphql, compose } from 'react-apollo';
import { NavLink} from 'react-router-dom';
import {Route, Switch} from 'react-router-dom';

import './Vorgadedestellung.css';

import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';
import Dropdown from '../../../../../../@appElements/dropDown/Dropdown'

import ImgSevenVorgadedestellung from './ImgSevenVorgadedestellung.js';
import ModalWochentage from './ModalWochentage.js'


import iconWochentage2 from '../../../../../../img/iconWochentage2.svg'
import cancel_black from '../../../../../../img/cancel_black.svg';
import cancel_grey from '../../../../../../img/cancel_grey.svg';
import ok_green from '../../../../../../img/ok_green.svg';
import calendar_celebration_2_grey from '../../../../../../img/calendar_celebration_2_grey.svg';
import calendar_celebration_grey from '../../../../../../img/calendar_celebration_grey.svg';
import add_color from '../../../../../../img/add_color.svg';
import edit from '../../../../../../img/edit.svg';
import delete_color from '../../../../../../img/delete_color.svg';

import icon_print from '../../../../../../img/print.svg' 
import icon_search from '../../../../../../img/icon_search.png' 
import icon_agenda from '../../../../../../img/icon_agenda.svg' 
import icon_settings_color from '../../../../../../img/icon_settings_color.svg' 

import icon_Sun from '../../../../../../img/icon_Sun.svg';
import icon_Fri from '../../../../../../img/icon_Fri.svg';
import icon_Mon from '../../../../../../img/icon_Mon.svg';
import icon_Sat from '../../../../../../img/icon_Sat.svg';
import icon_Wed from '../../../../../../img/icon_Wed.svg';
import icon_Thu from '../../../../../../img/icon_Thu.svg';
import icon_Tue from '../../../../../../img/icon_Tue.svg';
import icon_Sun2 from '../../../../../../img/icon_Sun2.svg';
import icon_Fri2 from '../../../../../../img/icon_Fri2.svg';
import icon_Mon2 from '../../../../../../img/icon_Mon2.svg';
import icon_Sat2 from '../../../../../../img/icon_Sat2.svg';
import icon_Wed2 from '../../../../../../img/icon_Wed2.svg';
import icon_Thu2 from '../../../../../../img/icon_Thu2.svg';
import icon_Tue2 from '../../../../../../img/icon_Tue2.svg';

import updateCustomerCalendar from '../../../../../../functions/mutation/customer/updateCustomerCalendar.js'

import AllCustomer_Vorgadedestellung from '../../../../../../functions/query/customer/allCustomer_Vorgadedestellung.js'
import AllCustomerInfoVorgadedestellung from '../../../../../../functions/query/customer/allCustomerInfoVorgadedestellung.js'
import View_fkCustomerDefaultOrderKinds from '../../../../../../functions/query/customer/view_fkCustomerDefaultOrderKinds.js'
import View_fkAllFormular from '../../../../../../functions/query/customer/view_fkAllFormular.js'
import TFN_WeeklyDefaultOrderForCustomer from '../../../../../../functions/query/customer/tfn_WeeklyDefaultOrderForCustomer.js'
import AllFakturaAssistKundeLieferperiode from '../../../../../../functions/query/customer/allFakturaAssistKundeLieferperiode.js'





const customStyles = {
  content : {
    top                   : '50%',
    left                  : '50%',
    right                 : 'auto',
    bottom                : 'auto',
    marginRight           : '-50%',
    transform             : 'translate(-50%, -50%)',
    width                 : '717px',
    'min-height'               : '556px',
    padding               : '-10px 0 10px 0',

  }
};

// Make sure to bind modal to your appElement (http://reactcommunity.org/react-modal/accessibility/)
Modal.setAppElement('#root')

class Vorgadedestellung extends Component {
  constructor() {
    super();
    this.state = {
        modalIsOpen: false,
        textarea:[],
   
        list: [],
        listUrland:[],
        firstDayOfWeek: '',
        view_fkAllFormular:[],
        view_fkCustomerDefaultOrderKinds:[],
        vorgabeAuto: false,
        flexibleOrders: false,
        enabledDeliverySplitting:false,
        vorgabeLieferschein: false,

    
    };
    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);


  }


  static getDerivedStateFromProps(nextProps, prevState) {
    
  }

getFormattedDate(d){
  let curr_date = d.getDate();
  let curr_month = d.getMonth() + 1;
  let curr_year = d.getFullYear();
  return (curr_year + "-" + curr_month + "-" + curr_date);
}

objectIntoDropdownArray(object,array,link){
  let newArray = [];
  for(let key in this.props[object][array]){
    newArray.push(this.props[object][array][key][link]);
  }
  return newArray;
}

openModal() {
    this.setState({modalIsOpen: true});
}

  closeModal() {
    this.setState({modalIsOpen: false});
}

checkVorgadedestellungInformation(index){
  if(!this.props.TFN_WeeklyDefaultOrderForCustomer.loading){
  if(!index || this.props.TFN_WeeklyDefaultOrderForCustomer.tfn_WeeklyDefaultOrderForCustomer===[]){return null}
  else{
    const store = this.props.TFN_WeeklyDefaultOrderForCustomer.tfn_WeeklyDefaultOrderForCustomer[index];
    if(store.IsGroupAvailable){return <span>Gruppe nicht verfügbar</span>}
}
}
}

componentDidMount(){
  if(!this.props.View_fkAllFormular.loading || !this.props.TFN_WeeklyDefaultOrderForCustomer.loading){
  let newView_fkAllFormular = this.objectIntoDropdownArray('View_fkAllFormular','view_fkAllFormular','form');
  let newView_fkCustomerDefaultOrderKinds = this.objectIntoDropdownArray('View_fkCustomerDefaultOrderKinds','view_fkCustomerDefaultOrderKinds','CustomerDefaultOrderKindName');
  let today = new Date(),
  afterSixDays = new Date();
  afterSixDays.setDate(today.getDate()+7);
  const formattedToday = this.getFormattedDate(today);
  const formattedAfterSixDays = this.getFormattedDate(afterSixDays);
  this.setState({
    today: formattedToday, 
    afterSixDays:formattedAfterSixDays, 
    view_fkAllFormular: newView_fkAllFormular, 
    view_fkCustomerDefaultOrderKinds:newView_fkCustomerDefaultOrderKinds
  });
}
}

  render() {
    if(this.props.AllCustomerInfoVorgadedestellung.loading ||
       this.props.AllFakturaAssistKundeLieferperiode.loading ||
       this.props.TFN_WeeklyDefaultOrderForCustomer.loading){ return <div> Loading...</div> }
      else{
    const listReseller_Konditionen1 = this.props.TFN_WeeklyDefaultOrderForCustomer.tfn_WeeklyDefaultOrderForCustomer.map((item, index) => {
          return (
            <Col lg={12} key={index}  className="listArticel_Konditionen">
              <Col lg={1}><span>{item.itemNr}</span></Col>
              <Col lg={2}><span>{item.description}</span></Col>
              <Col lg={1}><span>{item.qtyMo}</span></Col>
              <Col lg={1}><span>{item.qtyTu}</span></Col>
              <Col lg={1}><span>{item.qtyWe}</span></Col>
              <Col lg={1}><span>{item.qtyTh}</span></Col>
              <Col lg={1}><span>{item.qtyFr}</span></Col>
              <Col lg={1}><span>{item.qtySa}</span></Col>
              <Col lg={1}><span>{item.qtySu}</span></Col>
              <Col lg={2}><span>IS</span></Col>
              </Col>)});


   const listUrland = this.state.listUrland.map((item, index) => {
          return (
            <Col lg={12} key={index}  className="listArticel_Konditionen">
              <Col lg={2}><span>{item.fromDate}</span></Col>
              <Col lg={2}><span>{item.tillDate}</span></Col>
              <Col lg={2}><span>{item.comment}</span></Col>
              </Col>)});

    if(this.props.TFN_WeeklyDefaultOrderForCustomer.error){return <div> {this.props.TFN_WeeklyDefaultOrderForCustomer.error}</div>}
    else{

    const listDay = this.state.textarea.map((item, index)=>{return(<React.Fragment key={index}>{item}</React.Fragment>)});
    return (
      <Col lg={12} className="customer_vorgadedestellung">
      	<Col lg={12}  className="action_menu_Vorgadedestellung">
                 <Modal
            isOpen={this.state.modalIsOpen}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            style={customStyles}
            contentLabel="Example Modal"
          >
                    <div className="modal_main" z-index='0'>
            <Col lg={12} className="Vorgadedestellung_modal_header">
            <div className="Vorgadedestellung_modal_main text_modal">
              <Col lg={11} className="text_header_Vorgadedestellung">
                <span >Lieferperioden</span>
              </Col>
              <Col lg={1}>
                <div className="close_modal">
                  <img  className="img_modal" alt="" src={cancel_black} onClick={this.state.closeModal}/>
                </div>
              </Col>
              </div>
            </Col>

            <div>
              <Col lg={12}  className="Vorgadedestellung_modal_radius">
                <Col lg={4} >
                  <Col lg={2}>

                  </Col>
                 
                    <Col lg={8} className="radius_menu_Vorgadedestellung_modal">
                      <NavLink to={'/customers/' +this.props.intern + '/vorgadedestellung/wochentage'} activeClassName="radius_menu_Vorgadedestellung_modal_active">
                        <img src={iconWochentage2} alt="" />
                      </NavLink>
                    </Col>  
                  
                  
                  <Col lg={2}>

                  </Col>
                </Col>

                <Col lg={4} >
                  <Col lg={2}>

                  </Col>
                  
                    <Col lg={8} className="radius_menu_Vorgadedestellung_modal">
                      <NavLink to={'/customers/' +this.props.intern + '/vorgadedestellung/zeitaum'} activeClassName="radius_menu_Vorgadedestellung_modal_active">
                        <img src={calendar_celebration_2_grey} alt="" />
                      </NavLink>
                    </Col>
                  
                  <Col lg={2}>

                  </Col>
                </Col>

                <Col lg={4} >
                  <Col lg={2}>

                  </Col>
                  
                    <Col lg={8} className="radius_menu_Vorgadedestellung_modal">
                      <NavLink to={'/customers/' + this.props.intern+ '/vorgadedestellung/urlaud'} activeClassName="radius_menu_Vorgadedestellung_modal_active">
                        <img src={calendar_celebration_grey} alt="" />
                      </NavLink>
                    </Col>
                  
                  <Col lg={2}>

                  </Col>
                </Col>
              </Col>
            </div>


            <div>
              <Col lg={12}  className="Vorgadedestellung_modal_radius">
                <Col lg={4} >
                  <Col lg={11} className="radius_menu_text_Vorgadedestellung_modal">
                    <Col lg={11}>
                    <span>Wochentage</span>
                  </Col>
                  <Col lg={1}>

                  </Col>
                  </Col>
                  <Col lg={1}>

                  </Col>
                </Col>

                <Col lg={4} >
                  <Col lg={11} className="radius_menu_text_Vorgadedestellung_modal">
                    <Col lg={11}>
                    <span>Zeitaum</span>
                  </Col>
                  <Col lg={1}>

                  </Col>
                  </Col>
                  <Col lg={1}>

                  </Col>
                </Col>

                <Col lg={4} >
                  <Col lg={11} className="radius_menu_text_Vorgadedestellung_modal">
                    <Col lg={11}>
                    <span>Urlaud</span>
                  </Col>
                  <Col lg={1}>

                  </Col>
                  </Col>
                  <Col lg={1}>

                  </Col>
                </Col>
              </Col>
            </div>

            <div>
              <Col lg={12} className="hr_Vorgadedestellung">

              </Col>
            </div>

             <Switch>

                <Route path={'/customers/' +this.props.intern + '/vorgadedestellung/wochentage'} render={props =>
                             <ModalWochentage
                              intern={this.props.intern} 
                             />
                           
                             }
                />

                <Route path={'/customers/' +this.props.intern + '/vorgadedestellung/zeitaum'} render={props =>
              <div>
                  <Col lg={12} className="menu_Reseller">
              <Col lg={1} className="my_icon_menu_Reseller" onClick={this.openModal}><img className="icon_add" alt=""  src={add_color}/></Col>
              <Col lg={1} className="my_icon_menu_Reseller"><img className="icon_iconedit" alt=""  src={edit}/></Col>
              <Col lg={1} className="my_icon_menu_Reseller"><img className="icon_delete" alt=""  src={delete_color}/></Col>
              <Col lg={9}></Col>
            </Col>
            <Col lg={12} className="header_Reseller_list">
              <Col lg={1}><span>Artikle-Nr.</span></Col>
              <Col lg={1}></Col>
              <Col lg={1}><span>Bezeichnung</span></Col>
              <Col lg={3}></Col>
              <Col lg={1}><span>Pries</span></Col>
              <Col lg={1}></Col>
              <Col lg={1}><span>Bemerkung</span></Col>
              <Col lg={3}></Col>
            </Col>

            <Col lg={12} className="listReseller">
              
            </Col>
            </div>
                }
                />

                <Route path={'/customers/' +this.props.intern + '/vorgadedestellung/urland'} render={props =>
                  <div>
                  <Col lg={12} className="menu_Reseller">
              <Col lg={1} className="my_icon_menu_Reseller" onClick={this.openModal}><img className="icon_add" alt=""  src={add_color}/></Col>
              <Col lg={1} className="my_icon_menu_Reseller"><img className="icon_iconedit" alt=""  src={edit}/></Col>
              <Col lg={1} className="my_icon_menu_Reseller"><img className="icon_delete" alt=""  src={delete_color}/></Col>
              <Col lg={9}></Col>
            </Col>
            <Col lg={12} className="header_Reseller_list">
              <Col lg={2}><span>Von Datur</span></Col>
              <Col lg={2}><span>Bis Datum</span></Col>
              <Col lg={4}><span>Bemerkung</span></Col>
              <Col lg={2}><span>Wiedethole</span></Col>
              <Col lg={2}><span>IsRepaeat</span></Col>
            </Col>

            <Col lg={12} className="listReseller">
              {listUrland}
            </Col>
            </div>
                }

                />

            </Switch>

          


            <div>
            <Col lg={12}>
              <Col lg={1}>
              </Col>
              <Col lg={4} className="button_controled_ok" onClick={this.closeModal}>
                <button className="button_controled_1 button_controled"><img  className="img_modal" alt="" src={ok_green} /><span className="text_controled_modal" onClick={this.updateVorgadedestellungCalendar}>Speichern</span></button>
              </Col>
              <Col lg={2}>
              </Col>
              <Col lg={4} className="button_controled_close" onClick={this.closeModal}>
                <button className="button_controled_2 button_controled"><img  className="img_modal" alt="" src={cancel_grey} /><span className="text_controled_modal">Addrechen</span></button>
              </Col>
              <Col lg={1}>
              </Col>
              </Col>
            </div>

          </div> 
                    </Modal>
          <Col lg={2} className="customer_vorgadedestellung_input"> <input value={this.state.today}/></Col>
          <Col lg={2} className="customer_vorgadedestellung_input"> <input value={this.state.afterSixDays}/></Col>
          <Col lg={5} className="customer_vorgadedestellung_input_lieferung">
            <Dropdown style={{zIndex: 2}} list={this.state.view_fkAllFormular} gruppeid={1} linkName="Bakery" />
          </Col>
          <Col lg={1} className="customer_vorgadedestellung_icon"> <img src={icon_print} alt="" /></Col>
          <Col lg={1} className="customer_vorgadedestellung_icon"> <img src={icon_search} alt="" /></Col>
          <Col lg={1} className="customer_vorgadedestellung_icon"> <img src={icon_agenda} alt="" /></Col>
    
        </Col>
        <Col lg={12}  className="action_menu_vorgadedestellung_main_hr">
          <hr/>
        </Col>
        <Col lg={12}> 
          <Col lg={6}>
            <Col lg={8} className="customer_vorgadedestellung_head_text"> 
              <span> Lieferung aktive </span>
              <hr/>
            </Col>
            <Col lg={4}> 
            </Col>
          </Col>

          <Col lg={6}>
            <Col lg={8} className="customer_vorgadedestellung_head_text">
              <span> Sortiment </span>
              <hr/>
            </Col>
            <Col lg={4}> 
            </Col>
          </Col>
        </Col>

        <Col lg={12} className="customer_vorgadedestellung_text"> 
          <Col lg={6} >
            <span> Standard Lieferung </span>
          </Col>
          <Col lg={6}>
              <span> Sortimentsgruppen: </span>
          </Col>
        </Col>

        <Col lg={12} className="customer_vorgadedestellung_input_lieferung"> 
          <Col lg={6}>
            <Col lg={8}>
              <Dropdown style={{zIndex: 9}} list={this.state.view_fkCustomerDefaultOrderKinds} gruppeid={1} linkName="Bakery" />
            </Col>
            <Col lg={4} className="customer_vorgadedestellung_checkbox">
               <CheckBox value={"Fixdestellung"} margin_top={{'margin': '0px 0 0px 0'}} open={this.state.vorgabeAuto}/>
            </Col>
          </Col>

          <Col lg={6}>
            <Col lg={8} className="customer_vorgadedestellung_checkbox">
              <CheckBox value={"Gruppe"} margin_top={{'margin': '0px 0 0px 0'}}/>
            </Col>
            <Col lg={4}> 
            </Col>
          </Col>
        </Col>

        <Col lg={12}> 
          <Col lg={6}>
          </Col>
          <Col lg={6} className="customer_vorgadedestellung_checkbox">  
              <CheckBox value={"Kleinkunden"} margin_top={{'margin': '0px 0 0px 0'}}/>
            </Col>
        </Col>

        <Col lg={12}> 
          <Col lg={6}>
          </Col>
          <Col lg={6} className="customer_vorgadedestellung_checkbox_down">  
              <div><CheckBox value={"Grosskunden"} margin_top={{'margin': '0px 0 0px 0'}}/></div>
            </Col>
        </Col>

        <Col lg={12}> 
          <Col lg={6}>
            <Col lg={8} className="customer_vorgadedestellung_head_text">
            <span> Lieferperioden </span>
              <hr/>
              </Col>
              <Col lg={4}>
              </Col>

          </Col>
          <Col lg={6}>          
          </Col>
        </Col>

        <Col lg={12} > 
          <Col lg={6} className="customer_vorgadedestellung_text">
            <span> Jeden Montag, Dienstag, Donnerstag  </span>
          </Col>
          <Col lg={6}>          
          </Col>
        </Col>

        <Col lg={12}>
          <Col lg={6}>       
            <Col lg={3}>
              <div className="customer_konditionen_vorgadedestellung_button" onClick={this.openModal}>
                <img src={icon_settings_color} alt="" />
                <span> Change </span>
              </div>
            </Col>
          </Col>
          <Col lg={6}>          
          </Col>
      	</Col>

            <Col lg={12} className="menu_Vorgadedestellung">
              <Col lg={1} className="my_icon_menu_Reseller" onClick={this.openModal}><img className="icon_add" alt=""  src={add_color}/></Col>
              <Col lg={1} className="my_icon_menu_Reseller"><img className="icon_delete" alt=""  src={delete_color}/></Col>
              <Col lg={1} ></Col>
              <Col lg={3} >
                <CheckBox value={"Flex Bestellung"} margin_top={{'margin': '0px 0 0px 0'}} open={this.state.flexibleOrders}/>
              </Col>
              <Col lg={3} >
                <CheckBox value={"Splitten aktivieren"} margin_top={{'margin': '0px 0 0px 0'}} open={this.state.enabledDeliverySplitting}/>
              </Col>
              <Col lg={3} >
                <Dropdown style={{zIndex: 999}} list={this.state.view_fkAllFormular} gruppeid={1} linkName="Bakery" />
              </Col>

            </Col>
            <Col lg={12} className="header_Reseller_list">
              <Col lg={1}><span>Nummer</span></Col>
              <Col lg={2}><span>Bis Datum</span></Col>
              <Col lg={1}>Mo</Col>
              <Col lg={1}>Di</Col>
              <Col lg={1}>Mi</Col>
              <Col lg={1}>Do</Col>
              <Col lg={1}>Fr</Col>
              <Col lg={1}>Sa</Col>
              <Col lg={1}>So</Col>
              <Col lg={2}><span>Information</span></Col>
            </Col>

            <Col lg={12} className="listReseller">
              {listReseller_Konditionen1}
            </Col>  

      </Col> 
    );
}
}
}
}
const graph = compose(
    graphql(updateCustomerCalendar, {name:"updateCustomerCalendar"}),
    graphql(AllFakturaAssistKundeLieferperiode, {name:"AllFakturaAssistKundeLieferperiode"}),
    graphql(TFN_WeeklyDefaultOrderForCustomer, {
      options: (props) => ({
        fetchPolicy: 'cache-first',

          variables: {id: props.intern,
                      currentDate: "12-07-12"},
        }),
        name: "TFN_WeeklyDefaultOrderForCustomer"
    }), 
    graphql(View_fkCustomerDefaultOrderKinds, {name:"View_fkCustomerDefaultOrderKinds"}),
    graphql(View_fkAllFormular, {name:"View_fkAllFormular"}),
    graphql(AllCustomerInfoVorgadedestellung, {
      options: (props) => ({
        fetchPolicy: 'network-only',
          variables: {id: props.intern},
        }),
        name: "AllCustomerInfoVorgadedestellung"}), 


    )(Vorgadedestellung);

export default graph;