import React, { Component } from 'react';
import { Col, Row } from 'react-bootstrap';
import { graphql, compose } from 'react-apollo';
import {objectIntoDropdownArray} from '../../../../../../../storeFunctions.js'

import SimpleDropdown from '../../../../../../../../@appElements/dropDown/SimpleDropdown.js'
import Title from '../../../../../../../../@appElements/title/Title.js'
import Input from '../../../../../../../../@appElements/input/Input.js'

import {Mutations} from '../../../../../../../../@appElements/functions/Mutation.js';


import GetCustomerRabatt from '../../../../../../../../functions/query/customer/getCustomerRabatt.js'
import updateCustomerRabatt from '../../../../../../../../functions/mutation/customer/updateCustomerRabatt.js'
import View_fkDiscounts from '../../../../../../../../functions/query/customer/view_fkDiscounts.js'

class Rabbat extends Component {
  constructor() {
    super();
    this.state = {
      RabattCode: 0,
      list:[],
      listFakturaAssistMengenrabatt: [],
      LinkMengenrabatt: "",
      RabattInProzent1: "",
      RabattInProzent2: "",
      RabattInProzent3: "",
      RabattInProzent4: "",
      RabattInProzent5: "",
      RabattInProzent6: "",
      RabattInProzent7: "",
      RabattInProzent8: "",
      RabattInProzent9: "",
      RabattInProzent10: "",
      RabattInProzent11: "",
      RabattInProzent12: "",
      RabattInProzent13: "",
      RabattInProzent14: "",
      RabattInProzent15: "",
      RabattInProzent16: "",
      RabattInProzent17: "",
      RabattInProzent18: "",
      RabattInProzent19: "",
      RabattInProzent20 : ""
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if(!nextProps.GetCustomerRabatt.loading){
      const  store = nextProps.GetCustomerRabatt.getCustomerRabatt[0];
      return {
        LinkMengenrabatt: store.LinkMengenrabatt,
        listFakturaAssistMengenrabatt: store.CustomerRabattDropdown,
        list: nextProps.View_fkDiscounts.view_fkDiscounts,
        RabattCode: store.RabattCode,
        RabattInProzent1: store.RabattInProzent1,
        RabattInProzent2: store.RabattInProzent2,
        RabattInProzent3: store.RabattInProzent3,
        RabattInProzent4: store.RabattInProzent4,
        RabattInProzent5: store.RabattInProzent5,
        RabattInProzent6: store.RabattInProzent6,
        RabattInProzent7: store.RabattInProzent7,
        RabattInProzent8: store.RabattInProzent8,
        RabattInProzent9: store.RabattInProzent9,
        RabattInProzent10: store.RabattInProzent10,
        RabattInProzent11: store.RabattInProzent11,
        RabattInProzent12: store.RabattInProzent12,
        RabattInProzent13: store.RabattInProzent13,
        RabattInProzent14: store.RabattInProzent14,
        RabattInProzent15: store.RabattInProzent15,
        RabattInProzent16: store.RabattInProzent16,
        RabattInProzent17: store.RabattInProzent17,
        RabattInProzent18: store.RabattInProzent18,
        RabattInProzent19: store.RabattInProzent19,
        RabattInProzent20 : store.RabattInProzent20,
      }
      return null
    }
    return null
  }
  
  /*changeDropdown(index){
     console.log(index);
  }*/
  getDropdownIndex = (index) => {
   this.setState({RabattCode: index + 1});
  }

  getValueOfInput = (event) => {
    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})
  }

  updateRabattCode=(Id)=>{
    Mutations(
      {RabattCode: Id},
      this.props.updateCustomerRabatt, 
      "Intern",
      this.props.intern
      );
  }

  updateLinkMengenrabatt=(Id)=>{
    Mutations(
      {LinkMengenrabatt: Id},
      this.props.updateCustomerRabatt, 
      "Intern",
      this.props.intern
      );
  }

  updateCustomerRabatt=(e)=>{
    const key = e.target.name;
    const value = this.state[key];
    Mutations(
      {[key]: value},
      this.props.updateCustomerRabatt, 
      "Intern",
      this.props.intern
      );
  }



  render() {
    if(this.props.GetCustomerRabatt.loading || this.props.View_fkDiscounts.loading) {return null}


    else{
      return(
        <Row style={{padding: "20px 0 0 15px"}}>
          <SimpleDropdown style = {{zIndex: "99", width: "600px"}} onBlur={this.updateRabattCode} list = {this.state.list} select = {this.getDropdownIndex.bind(this)} gruppeId = {this.state.RabattCode} row = "DiscountName"/>
          {this.state.RabattCode == 1 ?
            <React.Fragment>
              <Col lg={4}>
                <Title text="Discounts are not available"/>
              </Col> 
              <Col lg={8}>
              </Col>  
            </React.Fragment> : null
          }

          {this.state.RabattCode == 2 ? 
              <Col lg={12}>
                <Col lg={4}>
                  <Title text='Discount for all articles'/>
                  <Col lg={12}>
                    <Col lg={4} >
                      <Input value={this.state.RabattInProzent1} onBlur={this.updateCustomerRabatt} text="Discount %"  name="RabattInProzent1" onChange={this.getValueOfInput}/>
                    </Col>
                  <Col lg={8}> 
                  </Col>
                </Col>
              </Col>
            </Col>
            : null
          }

          {this.state.RabattCode == 3?
            <Col lg={12}>
              <Row>
                <Col lg={5}>
                  <Title text="Discount on delivery Note"/>
                </Col>
                <Col lg={7}>
                </Col>
              </Row>
              <Row>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent1} onBlur={this.updateCustomerRabatt} text="Kleinbrote %" name="RabattInProzent1" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent6} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent6" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent11} onBlur={this.updateCustomerRabatt} text="Netto %" name="RabattInProzent11" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent16} onBlur={this.updateCustomerRabatt} text="Netto %" name="RabattInProzent16" onChange={this.getValueOfInput}/>
                </Col>
              </Row> 
              <Row>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent2} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent2" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent7} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent7" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent12} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent12" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent17} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent17" onChange={this.getValueOfInput}/>
                </Col>
              </Row>  
               <Row>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent3} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent3" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent8} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent8" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent13} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent13" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent18} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent18" onChange={this.getValueOfInput}/>
                </Col>
              </Row>  
               <Row>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent4} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent4" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent9} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent9" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent14} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent14" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent19} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent19" onChange={this.getValueOfInput}/>
                </Col>
              </Row>  
               <Row>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent5} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent5" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent10} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent10" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent15} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent15" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent20} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent20" onChange={this.getValueOfInput}/>
                </Col>
              </Row>  
            </Col>
            :null
          }

          {this.state.RabattCode == 4?
            <Col lg={12}>
              <Row>
                <Col lg={5}>
                  <Title text="Discount For article groups"/>
                </Col>
                <Col lg={7}>
                </Col>
              </Row>
              <Row>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent1} onBlur={this.updateCustomerRabatt} text="Kleinbrote %" name="RabattInProzent1" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent6} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent6" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent11} onBlur={this.updateCustomerRabatt} text="Netto %" name="RabattInProzent11" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent16} onBlur={this.updateCustomerRabatt} text="Netto %" name="RabattInProzent16" onChange={this.getValueOfInput}/>
                </Col>
              </Row> 
              <Row>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent2} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent2" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent7} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent7" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent12} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent12" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent17} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent17" onChange={this.getValueOfInput}/>
                </Col>
              </Row>  
               <Row>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent3} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent3" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent8} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent8" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent13} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent13" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent18} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent18" onChange={this.getValueOfInput}/>
                </Col>
              </Row>  
               <Row>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent4} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent4" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent9} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent9" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent14} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent14" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent19} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent19" onChange={this.getValueOfInput}/>
                </Col>
              </Row>  
               <Row>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent5} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent5" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent10} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent10" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent15} onBlur={this.updateCustomerRabatt} text="Konditorei %" name="RabattInProzent15" onChange={this.getValueOfInput}/>
                </Col>
                <Col lg={3} style={{padding: "0 50px 0 0"}}>
                  <Input value={this.state.RabattInProzent20} onBlur={this.updateCustomerRabatt} text="Backerei %" name="RabattInProzent20" onChange={this.getValueOfInput}/>
                </Col>
              </Row>  
            </Col>
            :null
          }


          {this.state.RabattCode == 5 || this.state.RabattCode == 6 ?
            <Col lg={12}>
              <Col lg={4}>
                <Title text="Quantitli discount on ordering amount"/>
                <SimpleDropdown onBlur={this.updateLinkMengenrabatt} style = {{zIndex: "9", width: "600px", marginTop: "20px"}} list = {this.state.listFakturaAssistMengenrabatt} gruppeId = {this.state.LinkMengenrabatt} row = {"Bezeichnung"}/>
              </Col>
            </Col>: null
          }
        </Row>
      )     
    }
  }
}

const graph = compose(
  graphql(GetCustomerRabatt, {
    options: (props) => ({
      fetchPolicy: 'network-only',
      variables: {Intern: props.intern},
    }),
    name: "GetCustomerRabatt"}),
  graphql(View_fkDiscounts, {name:"View_fkDiscounts"}),
  graphql(updateCustomerRabatt, {name:"updateCustomerRabatt"}),
)(Rabbat);

export default graph;
