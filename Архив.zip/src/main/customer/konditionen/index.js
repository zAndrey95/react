import React, { Component } from 'react';
import {Col} from 'react-bootstrap';
import {Route, Switch} from 'react-router-dom';

import Menu from './menu/Menu.js'
import Rabbat from './table/rabbat/Rabbat.js'
import Reseller from './table/reseller/Reseller.js'
import Artikel from './table/artikel/Artikel.js'
import Zahlung from './table/zahlung/Zahlung.js'
import Aktialisieren from './table/aktialisieren/Aktialisieren.js'

class Konditionen extends Component {

  constructor() {
    super();

    this.state = {
      list: [{'VonDatum': '14.02.2018', 'Bis Datum': '21.02.2018', 'Artikel-Nr.': '100.019', 'Bezeichnung': 'Grittibanzteig Weihnachten', 'Std. Preis': '0.00', 'Prises': '12.00', 'Rabatt': '22.33%', 'Ab Mange': '31'}, {'VonDatum': '14.02.2018', 'Bis Datum': '21.02.2018', 'Artikel-Nr.': '100.019', 'Bezeichnung': 'Grittibanzteig Weihnachten', 'Std. Preis': '0.00', 'Prises': '12.00', 'Rabatt': '22.33%', 'Ab Mange': '31'}, {'VonDatum': '14.02.2018', 'Bis Datum': '21.02.2018', 'Artikel-Nr.': '100.019', 'Bezeichnung': 'Grittibanzteig Weihnachten', 'Std. Preis': '0.00', 'Prises': '12.00', 'Rabatt': '22.33%', 'Ab Mange': '31'}]
    };
  }
  render() {
    return (
        <React.Fragment>
            <Col lg={12} >
              <Menu intern={this.props.intern}/>
            </Col>

            <Col lg={12}>
              <Switch>
                  <Route path={'/customers/' + this.props.intern + '/konditionen/rabbat'} render={props =>
                    <Rabbat 
                      customer = {this.props.customer}
                      getValueOfInput = {this.props.getValueOfInput}
                      intern={this.props.intern}
                    /> }
                  />

                  <Route path={'/customers/' + this.props.intern + '/konditionen/reseller_preise'} render={props =>
                    <Reseller list={this.state.list} intern={this.props.intern} /> }
                  />

                  <Route path={'/customers/' + this.props.intern + '/konditionen/artikel-preis'} render={props =>
                      <Artikel list={this.state.list}  intern={this.props.intern} /> }
                    />

                    <Route path={'/customers/' + this.props.intern + '/konditionen/zahlung'} render={props =>
                        <Zahlung 
                          customer = {this.props.customer}
                          getValueOfInput = {this.props.getValueOfInput}
                          intern={this.props.intern}
                        /> }
                      />
                    <Route path={'/customers/' + this.props.intern + '/konditionen/aktialisieren'} render={props =>
                        <Aktialisieren 
                        intern={this.props.intern}/> }
                      />
              </Switch>
            </Col>
        </React.Fragment>
    );
  }
}

export default Konditionen;
