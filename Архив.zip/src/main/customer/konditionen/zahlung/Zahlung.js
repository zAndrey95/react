import React, { Component } from 'react';
import { Col, Row} from 'react-bootstrap'
import { graphql, compose } from 'react-apollo';

import Title from '../../../../../../../../@appElements/title/Title.js'
import Input from '../../../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../../../@appElements/textarea/Textarea.js'
import SimpleDropdown from '../../../../../../../../@appElements/dropDown/SimpleDropdown.js'

import AllZahlung from '../../../../../../../../functions/query/customer/allZahlung.js'
import allZahlungLinkBank from '../../../../../../../../functions/query/customer/allZahlungLinkBank.js'
import allCustomer_Konditional_Zahlung_Rebett from '../../../../../../../../functions/query/customer/allCustomer_Konditional_Zahlung_Rebett.js'
import AllZahlungPost from '../../../../../../../../functions/query/customer/allZahlungPost.js'

import updateZahlung from '../../../../../../../../functions/mutation/customer/updateZahlung.js'
import {Mutations} from '../../../../../../../../@appElements/functions/Mutation.js';

class Zahlung extends Component {

  constructor(props) {
    super(props);
    this.state = {
      linkCustomer: '',
      zahlungsZiel: '',
      skontoInProzent: '',
      skontoTage: '',
      debitorKonto: '',
      sAPBetriebsNr: '',
      ertragKonto: '',
      kostenstelle: '',
      customPaymentText: '',
      linkCustomer: '',
      postSectorID: '',
      name: '',
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if(!nextProps.AllZahlung.loading && !nextProps.AllZahlungPost.loading){
      const  storeZahlung = nextProps.AllZahlung.allZahlung[0];
      const  storeZahlungPost = nextProps.AllZahlungPost.allZahlungPost[0];
      if(storeZahlung || storeZahlungPost !== prevState){
        return {
          LinkPostSector: storeZahlung.LinkPostSector,
          linkCustomerZahlung: storeZahlung.idCustomer,
          zahlungsZiel: storeZahlung.ZahlungsZiel,
          skontoInProzent: storeZahlung.SkontoInProzent,
          skontoTage: storeZahlung.SkontoTage,
          debitorKonto: storeZahlung.DebitorKonto,
          sAPBetriebsNr: storeZahlung.SAPBetriebsNr,
          ertragKonto: storeZahlung.ErtragKonto,
          kostenstelle: storeZahlung.Kostenstelle,
          customPaymentText: storeZahlung.CustomPaymentText,

        }
      }
      return null
    }
    return null
  }

  updateZahlung = (LinkGruppe) => {
    this.props.updateZahlung({
      variables: {
        Intern:this.props.intern,
        ZahlungsZiel: this.state.skontoInProzent, 
        SkontoInProzent: this.state.skontoInProzent, 
        SkontoTage: this.state.skontoTage, 
        DebitorKonto:this.state.debitorKonto, 
        SAPBetriebsNr: this.state.sAPBetriebsNr, 
        ErtragKonto: this.state.ertragKonto, 
        Kostenstelle: this.state.kostenstelle, 
        CustomPaymentText: this.state.customPaymentText
    },
      options: {
        fetchPolicy: 'cache-first'
      }
    })
  }
    
  getValueOfInput = (event) => {
    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})

  }

  updateLinkMengenrabatt=(Id)=>{
    Mutations(
      {LinkPostSector: Id? Id: this.state.LinkPostSector?this.state.LinkPostSector:0},
      this.props.updateZahlung, 
      "Intern",
      this.props.intern
      );
  }


 
  render() {
    if(this.props.AllZahlungPost.loading || this.props.AllZahlung.loading || this.props.allZahlungLinkBank.loading || this.props.allCustomer_Konditional_Zahlung_Rebett.loading){ return (<div>Loading...</div>)}
    if(this.props.AllZahlungPost.error || this.props.AllZahlungPost.error){ return <div> Error: {this.props.AllZahlungPost.error}</div>}
    else{
      return (
        <Row style={{padding: "0 15px 0 15px"}}>
          <Col lg={12}>
            <Col lg={3}>
              <Title text="Term of payment"/>
              <Input text="Term of payment in days" value={this.state.zahlungsZiel} name="zahlungsZiel" onChange={this.getValueOfInput} onBlur={this.updateZahlung}/>
              <Title text="Debtor account"/>
              <Input text='Debtor account' value={this.state.debitorKonto} name="debitorKonto" onChange={this.getValueOfInput} onBlur={this.updateZahlung}/>
              <Input text="Slip reference" value={this.state.sAPBetriebsNr} name="sAPBetriebsNr" onChange={this.getValueOfInput} onBlur={this.updateZahlung}/>
              <Title text=" Export Abacus"/>
              <Col lg={12}>
                <Col lg={5}>
                  <Input text="Ertragskonto" value={this.state.ertragKonto} name="ertragKonto" onChange={this.getValueOfInput} onBlur={this.updateZahlung}/>
                </Col>
                <Col lg={5} lgOffset={2}>
                  <Input text="Kostenstelle" value={this.state.kostenstelle} name="kostenstelle"/>
                </Col>
              </Col>
              <Title text="Individual payment cinditions"/> 
            </Col>
            <Col lg={3} lgOffset={3}>
              <Title text="Cash descount "/>
              <Col lg={12}>
                <Col lg={5}>
                  <Input text="Discount in %" value={this.state.skontoInProzent} name="skontoInProzent" onChange={this.getValueOfInput} onBlur={this.updateZahlung}/>
                </Col>
                <Col lg={5} lgOffset={2}>
                  <Input text="Days" value={this.state.skontoTage} name="skontoTage" onChange={this.getValueOfInput} onBlur={this.updateZahlung}/>
                </Col>
              </Col>
              <Col lg={12}>
                <Title text="BESR  payment slip"/>
              </Col>
              <Col lg={12}>
                <SimpleDropdown 
                  text="Bank name" 
                  list={this.props.allZahlungLinkBank.allZahlungLinkBank}
                  row={"bankName"}
                  style={{zIndex: 13}}/>
              </Col>
              <Col lg={12}>
                <Title text="Post"/>
              </Col>
              <Col lg={12}>
                <SimpleDropdown 
                  list={this.props.allCustomer_Konditional_Zahlung_Rebett.allCustomer_Konditional_Zahlung_Rebett} 
                  text="Rabett und Preise ubernehmen"
                  row={"Name"}
                  row1={false}
                  style={{zIndex: 12}} 
                  gruppeId={this.state.LinkPostSector} 
                  onBlur={this.updateLinkMengenrabatt}
                  />
              </Col>
            </Col>
            <Col lg={3}>   
            </Col> 
          </Col>
          <Col lg={12}>
            <Textarea text="Debitorenkonto" width="100%"  height="180px" value={this.state.customPaymentText} name="customPaymentText" type="text"  onChange={this.getValueOfInput} onBlur={this.updateZahlung}/> 
          </Col>
        </Row>
      );
    }
  }
}

const graph = compose(
  graphql(AllZahlung, {
    options: (props) => ({
      fetchPolicy: 'network-only',
      variables: {Intern: props.intern},
    }),
    name: "AllZahlung"
  }
),
  graphql(AllZahlungPost, {
    options: (props) => ({
      fetchPolicy: 'network-only',
      variables: {LinkCustomer: props.intern},
    }),
    name: "AllZahlungPost"
  }
),
  graphql(allZahlungLinkBank, {
    options: (props) => ({
      fetchPolicy: 'network-only',
      variables: {LinkCustomer: props.intern},
    }),
    name: "allZahlungLinkBank"
  }
),
  graphql(allCustomer_Konditional_Zahlung_Rebett, {
    options: (props) => ({
      fetchPolicy: 'network-only',
      variables: {LinkCustomer: props.intern},
    }),
    name: "allCustomer_Konditional_Zahlung_Rebett"
  }
),
  graphql(updateZahlung, {name:"updateZahlung"}),
)(Zahlung);

export default graph;
