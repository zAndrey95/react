import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo, compose } from 'react-apollo'
import { Col, Row } from 'react-bootstrap';
import styled from 'styled-components';

import SimpleDropdown from '../../../../../../../../@appElements/dropDown/SimpleDropdown.js';
import Calendar from '../../../../../../../../@appElements/calendar/Calendar.js';
import CheckBox from '../../../../../../../../@appElements/checkBox/CheckBox.js';
import Title from '../../../../../../../../@appElements/title/Title.js'
import Input from '../../../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../../../@appElements/textarea/Textarea.js'
import Button from '../../../../../../../../@appElements/button/Button.js'

import Cancel_black from '../../../../../../../../@appElements/item_Img/Cancel_black.js'
import Ok_green from '../../../../../../../../@appElements/item_Img/Ok_green.js'
import Cancel_red from '../../../../../../../../@appElements/item_Img/Cancel_red.js'


import AllListProducts from '../../../../../../../../functions/query/product/allListProducts.js'

import AllProduct_Artikel from '../../../../../../../../functions/query/product/allProduct_Artikel.js'


class Modal_Add extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchValue: this.props.searchValue,
      From: 100,
      LinkArticle: 0,
      LinkSpecialPriceType: 0,
    };
  }



  more = () => {
    //if(this.state.From==this.props.AllListCustomer.allListCustomers.length){
      //if(this.state.post){
        this.setState({
          post: true, 
          From:200 
        })
        this.props.AllListProducts.fetchMore({
          variables: {
            searchValue:this.state.searchValue, From: 200
          },
          updateQuery: (prev, { fetchMoreResult }) => {
            if (!fetchMoreResult) return prev;
            return Object.assign({}, prev, {
              allListProducts: [...prev.allListProducts, ...fetchMoreResult.allListProducts]
            });
          }
      })
    //}
  //}
  }


  getValueOfInput = (event) => {
    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})
  }


  onBlurLinkSpecialPriceType = (id) =>{
    this.setState({LinkSpecialPriceType: this.props.AllListProducts.allListProducts[id-1].id})
    this.props.onBlurDrop(this.props.AllListProducts.allListProducts[id-1].id);
  }



  render() {
    return (
      <div>
        <Row style={{padding: "10px 0 0 0"}}>
          <Col lg={5}>
            <Title 
              top={"0px"} 
              text="Kundenpreise"/>
          </Col>
          <Col lg={1} lgOffset={6}>
            <Cancel_black onClick={this.props.closeModal}/>
          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={12}>
            
          </Col>

          <Col lg={12}>
            <Col lg={4}>
                <Calendar 
                  getDate={this.props.getFromDateDate}
                  date={this.props.FromDate?new Date(this.props.FromDate.slice(0, 10).replace(/\-/g, ",")):new Date()}/>
            </Col>
            <Col lg={4} lgOffset={2}>
                <Calendar 
                  getDate={this.props.getToDateDate}
                  date={this.props.ToDate?new Date(this.props.ToDate.slice(0, 10).replace(/\-/g, ",")):new Date()}/>
            </Col>
            <Col lg={2}>
            </Col>
          </Col>

          <Col lg={12}>
            <SimpleDropdown 
              onBlur={this.onBlurLinkSpecialPriceType}
              searchValue={this.props.searchValue}
              search={this.props.getValueOfInput}
              style={{zIndex: 14}} 
              list={this.props.AllListProducts.allListProducts} 
              text="Article"
              row={"productNm"}
              row1={"nameProduct"}
              next={this.more}
              gruppeId={this.props.LinkArticle}
              value={this.props.AllProduct_Artikel.allProduct_Artikel?this.props.AllProduct_Artikel.allProduct_Artikel[0].itemsNm +" "+ this.props.AllProduct_Artikel.allProduct_Artikel[0].name: null}
            />
          </Col>

          <Col lg={12}>
            <Col lg={4}>
              <Input 
                text="Price" 
                value={this.props.Price} 
                name='Price' 
                onChange={this.props.getValueOfInput}/>
            </Col>
            <Col lg={4} lgOffset={2}>
              <Input
                text="Frome amount" 
                value={this.props.FromAmount} 
                name='FromAmount' 
                onChange={this.props.getValueOfInput}/>
            </Col>
            <Col lg={2}>
            </Col>
          </Col>

          <Col lg={12}>
            <Col lg={4}>
              <Input 
                text="Discount" 
                value={this.props.Discount} 
                name='Discount' 
                onChange={this.props.getValueOfInput}/>
            </Col>
            <Col lg={6} lgOffset={2} onClick={this.props.isDiscountsDisabled}>
              <CheckBox
                value={"Nettoartikel"} 
                style={{margin:"47px 0 0 0"}} 
                open={this.props.DiscountsDisabled}
              />
            </Col>
          </Col>

          <Col lg={12}>
            <Textarea 
              width="463px" 
              height="104px" 
              value={this.props.Description} 
              name='Description' 
              type="text" 
              text="Note"
              onChange={this.props.getValueOfInput}/>
          </Col>
        </Row>

        <Col lg={12} className="hr">
        </Col>

        <Col lg={12}>
          <Col lg={4} lgOffset={1}  onClick={this.props.closeModal}>
            <Button 
              top={"11px"}
              width={"145px"}
              size={"16px"} 
              height={"30px"} 
              color={"#7ed321"} 
              onClick={this.props.update.bind(this, this.state.LinkArticle, this.state.LinkSpecialPriceType)}
              text={
                <div style={{padding: "5px 0 0 0"}}> 
                  <Col lg={4}> <Ok_green/> </Col>
                  <Col lg={8} style={{padding: "3px 0 0 0"}}>Save</Col>
                </div>
            }/>
          </Col>
          <Col lg={4} lgOffset={2}  onClick={this.props.closeModal}>
            <Button 
              top={"11px"}
              width={"145px"}
              size={"16px"} 
              height={"30px"} 
              color={"#d0021b"} 
              text={
                <div style={{padding: "5px 0 0 0"}}> 
                  <Col lg={4}> <Cancel_red/> </Col>
                  <Col lg={8} style={{padding: "3px 0 0 0"}}>Cancel</Col>
                </div>
            }/>
          </Col>
          <Col lg={1}>
          </Col>
        </Col>
      </div> 
    )
  }
}
const graph = compose(

    graphql(AllProduct_Artikel, {
        options: (props) => ({
            fetchPolicy: 'network-only',
            variables: {
              id: props.LinkArticle,
            }
        }),
        name: "AllProduct_Artikel",
    }),
    graphql(AllListProducts, {
        options: (props) => ({
            fetchPolicy: 'cache-and-network',
            variables: {
              SearchValue: props.searchValue, From:0
            }
        }),
        name: "AllListProducts"}),
)(Modal_Add);

export default graph;