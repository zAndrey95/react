import React, { Component } from 'react';
import { Col, Row} from 'react-bootstrap';
import { graphql, compose, Mutation } from 'react-apollo';

import CheckBox from '../../../../../../../../@appElements/checkBox/CheckBox.js';
import SimpleDropdown from '../../../../../../../../@appElements/dropDown/SimpleDropdown.js'
import HeaderTable from '../../../../../../../../@appElements/table/HeaderTable.js'
import Table from '../../../../../../../../@appElements/table/Table.js'
import Plus_green from '../../../../../../../../@appElements/item_Img/Plus_green'
import Minus_red from '../../../../../../../../@appElements/item_Img/Minus_red.js'
import Edit_blue from '../../../../../../../../@appElements/item_Img/Edit_blue.js'
import Icon_medical_on from '../../../../../../../../@appElements/item_Img/Icon_medical_on.js'
import Modal from '../../../../../../../../@appElements/modal/Modal.js'
import Modal_Add from './Modal_Add.js'
import updateSpecialPrices from '../../../../../../../../functions/mutation/customer/updateSpecialPrices.js'
import addSpecialPrices from '../../../../../../../../functions/mutation/customer/addSpecialPrices.js'
import deleteSpecialPrices from '../../../../../../../../functions/mutation/customer/deleteSpecialPrices.js'

import AllSpecialPrices from '../../../../../../../../functions/query/customer/allSpecialPrices.js'
import AllPriceCategory from '../../../../../../../../functions/query/customer/allPriceCategory.js'



// Make sure to bind modal to your appElement (http://reactcommunity.org/react-modal/accessibility/)



class Artikel extends Component {

  constructor(props) {
    super(props);
    this.state = {
      searchValue: "",
      modalIsOpen: false,
      modalIsOpen1: false,
      textarea: [],
      artikelArray: [],
      LinkArticle: "",
      FromDate: '',
      ToDate: '',
      Price: '',
      FromAmount: '',
      Discount: '',
      DiscountsDisabled: false,
      Description: 0,
      LinkSpecialPriceType: 0,
      indexOnClickTable: 0
    };
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if(!nextProps.AllSpecialPrices.loading){
      const  store = nextProps.AllSpecialPrices.allSpecialPrices;
        return {
          artikelArray: store.length==0?[]:store,
        }
      
    }
    return null
  }

  openModal1 = () => {
    this.setState({modalIsOpen1: true, LinkArticle: "", FromDate: "", ToDate: "", Price: 0, FromAmount: 0, Discount: 0, DiscountsDisabled: false, Description: "", LinkSpecialPriceType: "",});
  } 

  closeModal1 = () => {
    this.setState({modalIsOpen1: false});
  }

  onBlurLinkArticle = (id) =>{
    this.setState({LinkArticle: id})
  }


  openModal = (index) => {
    this.setState({indexOnClickTable:index,modalIsOpen: true});

  } 

  closeModal = () => {
    this.setState({modalIsOpen: false});
  }

  getValueOfInput = (event) => {
    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})
  }

  indexOnClickTable = (index) => {
    this.setState({indexOnClickTable:index,
    LinkArticle: this.state.artikelArray[index].LinkArticle,
    FromDate: this.state.artikelArray[index].FromDate,
    ToDate: this.state.artikelArray[index].ToDate,
    Price: this.state.artikelArray[index].Price,
    FromAmount: this.state.artikelArray[index].FromAmount,
    Discount: this.state.artikelArray[index].Discount,
    DiscountsDisabled: this.state.artikelArray[index].DiscountsDisabled,
    Description: this.state.artikelArray[index].Description,
    LinkSpecialPriceType: this.state.artikelArray[index].LinkSpecialPriceType})
  }

  updateSpecialPrices=  (LinkArticle, LinkSpecialPriceType)=>{
     this.props.updateSpecialPrices({
      variables: {
        Intern:  this.state.artikelArray[this.state.indexOnClickTable].Intern,
        LinkArticle: LinkArticle ? LinkArticle : this.state.LinkArticle,
        FromDate: this.state.FromDate,
        ToDate: this.state.ToDate,
        Price: this.state.Price,
        FromAmount: this.state.FromAmount,
        Discount: this.state.Discount,
        DiscountsDisabled: this.state.DiscountsDisabled,
        Description: this.state.Description,
        LinkSpecialPriceType: 1,//LinkSpecialPriceType ? LinkSpecialPriceType : this.state.LinkSpecialPriceType,
      },
      options: {
        fetchPolicy: 'network-only'
      },


      refetchQueries: [ { query: AllSpecialPrices, variables: {LinkCustomer: this.props.intern} }]

    })

  }



  addSpecialPrices =  (LinkArticle, LinkSpecialPriceType) =>{
   this.props.addSpecialPrices({
      variables: {
        FromDate: this.state.FromDate,
        ToDate: this.state.ToDate,
        Price: this.state.Price,
        FromAmount: this.state.FromAmount,
        Discount: this.state.Discount,
        DiscountsDisabled: this.state.DiscountsDisabled,
        Description: this.state.Description,
        LinkSpecialPriceType: 1, //LinkSpecialPriceType ? LinkSpecialPriceType : this.state.LinkSpecialPriceType,
        LinkArticle: LinkArticle ? LinkArticle : this.state.LinkArticle,
        LinkCustomer: this.props.intern
      },
      options: {
        fetchPolicy: 'cache-and-network',

      },




      refetchQueries: [ { query: AllSpecialPrices, variables: {LinkCustomer: this.props.intern} }]

    }).then((data)=>console.log(data)).catch((err)=>console.log(err))





  }

  isDiscountsDisabled = () => {
    this.setState({DiscountsDisabled: !this.state.DiscountsDisabled});
  }

  deleteSpecialPrices = (index)=>{
   this.props.deleteSpecialPrices({
      variables: {
        Intern:  this.state.artikelArray[index].Intern,
      },
      options: {
        fetchPolicy: 'cache-and-network'
      },

      refetchQueries: [ { query: AllSpecialPrices, variables: {LinkCustomer: this.props.intern} }]

    })


  }

  getFromDateDate=(i)=>{
    this.setState({FromDate: i})
  }

  getToDateDate=(i)=>{
    this.setState({ToDate: i})
  }


  render() {
    if(this.props.AllSpecialPrices.error){
      return null
    }
    if(this.props.AllSpecialPrices.loading){
      return (<div>Loading...</div>)
    }
    else{
      const newArr=[];
      this.state.artikelArray.forEach((item)=>{
        let fromDate = item.FromDate===null?'':item.FromDate.substring(0,10);
        let toDate = item.ToDate===null?'':item.ToDate.substring(0,10);
        newArr.push([fromDate, toDate, item.LinkArticle,item.Description,item.CurrentPrice,item.Price,item.Discount,<CheckBox left="57px" top="-1px" open={item.DiscountsDisabled}/>,item.FromAmount])
        }
      )

      return (
        <Row>
          <Modal
            isOpen={this.state.modalIsOpen1}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal1}
            contentLabel="Example Modal"
            width={"481px"}
            height={"597px"}
            component={
              <Modal_Add 
                getFromDateDate={this.getFromDateDate}
                getToDateDate={this.getToDateDate}
                searchValue={this.state.searchValue}
                getValueOfInput = {this.getValueOfInput}
                closeModal = {this.closeModal1}
                LinkArticle = {this.state.LinkArticle}
                FromDate = {this.state.FromDate}
                ToDate = {this.state.ToDate}
                Price = {this.state.Price}
                FromAmount = {this.state.FromAmount}
                Discount = {this.state.Discount}
                DiscountsDisabled = {this.state.DiscountsDisabled}
                Description = {this.state.Description}
                LinkSpecialPriceType = {this.state.LinkSpecialPriceType}
                update = {this.addSpecialPrices}
                isDiscountsDisabled={this.isDiscountsDisabled}
                onBlurDrop = {this.onBlurLinkArticle}
              />}
          />

          <Modal
            isOpen={this.state.modalIsOpen}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            contentLabel="Example Modal"
            width={"481px"}
            height={"597px"}
            component={<Modal_Add 
              getFromDateDate={this.getFromDateDate}
              getToDateDate={this.getToDateDate}
              Intern =  {this.state.artikelArray[this.state.indexOnClickTable]?this.state.artikelArray[this.state.indexOnClickTable].Intern:""}
              searchValue={this.state.searchValue}
              getValueOfInput = {this.getValueOfInput}
              closeModal = {this.closeModal}
              LinkArticle = {this.state.LinkArticle}
              FromDate = {this.state.FromDate}
              ToDate = {this.state.ToDate}
              Price = {this.state.Price}
              FromAmount = {this.state.FromAmount}
              Discount = {this.state.Discount}
              DiscountsDisabled = {this.state.DiscountsDisabled}
              Description = {this.state.Description}
              LinkSpecialPriceType = {this.state.LinkSpecialPriceType}
              update = {this.updateSpecialPrices}
              isDiscountsDisabled={this.isDiscountsDisabled}
              onBlurDrop = {this.onBlurLinkArticle}
              />}
          />
           
          <HeaderTable 
            items={[
              <Plus_green
                onClick={this.openModal1}
                top="9px"
              />, 











              <Icon_medical_on
                top="2px"
              />,
              <Col lg={12} style={{
                    padding: "0 5px 0 5px",
                    "border-left": "1px solid #e0e0e0", 
                    "border-right": "1px solid #e0e0e0",
                    height: "34px"
              }}> 
                <Col lg={4}
                  style={{
                        margin:"7px 0 0 0"
                }}>
                  Preiskategorie:
                </Col>
                 <Col lg={8}>
                    <SimpleDropdown 
                      style={{
                        zIndex: 9,
                        margin:"2px 0 0 0"
                      }} 
                      list={["s","s"]}/>
                  </Col>
              </Col>, 
              <div></div>
            ]} 
            widths={["5%", "5%","40%","50%"]}/>  
          <Table 
            edit={this.openModal}
            delete={this.deleteSpecialPrices}
            onClick={this.indexOnClickTable} 
            names={["Von Datum", "Bis Datum", "Artikel", "Bezeichnung", "Std. Preis", "Prises", "Rabatt","Nettoartikel", "Ab Mange"]} 
            widths={['10%', '10%', '10%', '20%', '10%', '10%', '10%', '10%', '10%']} 
            arr={newArr}/>
        </Row>
      );
    }
  }
}


const graph = compose(
  graphql(AllSpecialPrices, {
    options: (props) => ({
      fetchPolicy: 'cache-and-network',
      variables: {LinkCustomer: props.intern},
    }),
    name: "AllSpecialPrices"}),
    graphql(AllPriceCategory, {name: "AllPriceCategory"}),

  graphql(updateSpecialPrices,{name:"updateSpecialPrices"}),
   graphql(addSpecialPrices, {name:"addSpecialPrices"}),
  graphql(deleteSpecialPrices, {name:"deleteSpecialPrices"}),
)(Artikel);

export default graph;
