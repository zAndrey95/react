import React, { Component } from 'react';
import { Col, Row} from 'react-bootstrap';
import { graphql, compose } from 'react-apollo';

import HeaderTable from '../../../../../../../../@appElements/table/HeaderTable.js'
import Table from '../../../../../../../../@appElements/table/Table.js'
import Plus_green from '../../../../../../../../@appElements/item_Img/Plus_green.js'
import Minus_red from '../../../../../../../../@appElements/item_Img/Minus_red.js'
import Edit_blue from '../../../../../../../../@appElements/item_Img/Edit_blue.js'
import Modal from '../../../../../../../../@appElements/modal/Modal.js'
import Modal_Add from './Modal_Add.js'

import AllResellerPreise from '../../../../../../../../functions/query/customer/allResellerPreise.js'
import updateResellerPreise from '../../../../../../../../functions/mutation/customer/updateResellerPreise.js'
import deleteResellerPreise from '../../../../../../../../functions/mutation/customer/deleteResellerPreise.js'
import addResellerPreise from '../../../../../../../../functions/mutation/customer/addResellerPreise.js'

const customStyles = {
  content : {
    top                   : '50%',
    left                  : '50%',
    right                 : 'auto',
    bottom                : 'auto',
    marginRight           : '-50%',
    transform             : 'translate(-50%, -50%)',
    width                 : '481px',
    height                : '415px',
    padding               : '-10px 0 10px 0',

  }
};

// Make sure to bind modal to your appElement (http://reactcommunity.org/react-modal/accessibility/)


class Reseller extends Component {

  constructor() {
    super();
    this.state = {
      searchValue: "",
      modalIsOpen1: false,
      modalIsOpen: false,
      resellerArray: [],
      indexOnClickTable: 0,
      Intern: "",
      LinkArticle: "",
      Price: 0, 
      Description: ""
    };
  }


  static getDerivedStateFromProps(nextProps, prevState) {
    if(!nextProps.AllResellerPreise.loading){
      const  store = nextProps.AllResellerPreise.allResellerPreise;
      if(store !== prevState.resellerArray){
        if(store){
        return {
          resellerArray: store
        }
        }
      }
      return null
    }
    return null
  }

  getValueOfInput = (event) => {
    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})
  }

  openModal1 = () => {
    this.setState({modalIsOpen1: true, LinkArticle: "",Price: 0, Description: ""});
  } 

  closeModal1 = () => {
    this.setState({modalIsOpen1: false});
  }


  openModal = () => {
    this.setState({modalIsOpen: true});
  } 

  closeModal = () => {
    this.setState({modalIsOpen: false});
  }

  indexOnClickTable = (index) => {
    this.setState({indexOnClickTable: index,
    Intern: this.state.resellerArray[index].Intern,
          LinkArticle: this.state.resellerArray[index].LinkArticle,
          Price: this.state.resellerArray[index].Price,
          Description: this.state.resellerArray[index].Description});

  }

  updateResellerPreise= async (LinkArticle)=>{
    await this.props.updateResellerPreise({
      variables: {
        Intern:  this.state.resellerArray[this.state.indexOnClickTable].Intern,
        LinkArticle: LinkArticle?LinkArticle:this.state.LinkArticle,
        Price: this.state.Price,
        Description: this.state.Description,
      },
      options: {
        fetchPolicy: 'network-only'
      },

      
      refetchQueries: [ { query: AllResellerPreise, variables: {LinkCustomer: this.props.intern} }]

    })
  }

  addResellerPreise = async (LinkArticle) =>{
  await this.props.addResellerPreise({
      variables: {
        LinkArticle: LinkArticle ? LinkArticle : 0,
        LinkCustomer: this.props.intern,
        Price: this.state.Price,
        Description: this.state.Description,
      },
      options: {
        fetchPolicy: 'cache-and-network',

      },

      refetchQueries: [ { query: AllResellerPreise, variables: {LinkCustomer: this.props.intern} }]

    })



this.props.AllResellerPreise.refetch()

  }

  deleteResellerPreise = async ()=>{
  await this.props.deleteResellerPreise({
      variables: {
        Intern:  this.state.resellerArray[this.state.indexOnClickTable].Intern,
      },
      options: {
        fetchPolicy: 'cache-and-network'
      },


      refetchQueries: [ { query: AllResellerPreise, variables: {LinkCustomer: this.props.intern} }]

    })

  }

  render() {
    if(this.props.AllResellerPreise.error){ return <div> Error...</div>}

    else{
    const newArr=[];
    this.state.resellerArray.forEach((item)=>{
      newArr.push([item.LinkArticle, item.Description, item.Price])
    })

    return (
      <Row>
        <Modal
            isOpen={this.state.modalIsOpen1}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal1}
            contentLabel="Example Modal"
            width={"481px"}
            height={"380px"}
            component={
              <Modal_Add 
                closeModal={this.closeModal1}
                getValueOfInput={this.getValueOfInput}
                searchValue={this.state.searchValue}
                LinkArticle={this.state.LinkArticle}
                update={this.addResellerPreise}
                Description={this.state.Description}
                Price={this.state.Price}
              />}
          />

          <Modal
            isOpen={this.state.modalIsOpen}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            contentLabel="Example Modal"
            width={"481px"}
            height={"380px"}
            component={
              <Modal_Add 
                closeModal={this.closeModal}
                getValueOfInput={this.getValueOfInput}
                searchValue={this.state.searchValue}
                LinkArticle={this.state.LinkArticle}
                update={this.updateResellerPreise}
                Description={this.state.Description}
                Price={this.state.Price}
              />}
          />


        <HeaderTable 
          items={[
            <Plus_green
              onClick={this.openModal1}
              top="9px"
            />, 
            <Edit_blue     
              onClick={this.openModal}
              top="5px"
            />,
            <Minus_red
            onClick={this.deleteResellerPreise}
              top="11px"
            
            />, 
            <div></div>
          ]} 
          widths={["7%", "7%","7%","79%"]}/>   

        <Table 
          onClick={this.indexOnClickTable} 
          names={["Srticlt No.", "Description ", "Price"]} 
          widths={['15%', '50%', '35%']} 
          arr={newArr}/>
      </Row>
    );
  }
}
}

const graph = compose(
  graphql(AllResellerPreise, {
    options: (props) => ({
      fetchPolicy: 'cache-and-network',
      variables: {LinkCustomer: props.intern},
    }),
    name: "AllResellerPreise"}),
  graphql(updateResellerPreise, {name:"updateResellerPreise"}),
  graphql(deleteResellerPreise, {name:"deleteResellerPreise"}),
  graphql(addResellerPreise, {name:"addResellerPreise"}),
)(Reseller);

export default graph;
