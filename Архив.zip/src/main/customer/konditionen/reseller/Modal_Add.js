import React, { Component } from 'react';
import { graphql, compose, withApollo } from 'react-apollo';
import { Col, Row } from 'react-bootstrap';
import styled from 'styled-components';

import SimpleDropdown from '../../../../../../../../@appElements/dropDown/SimpleDropdown.js';
import CheckBox from '../../../../../../../../@appElements/checkBox/CheckBox.js';
import Title from '../../../../../../../../@appElements/title/Title.js'
import Input from '../../../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../../../@appElements/textarea/Textarea.js'
import Button from '../../../../../../../../@appElements/button/Button.js'

import AllListProducts from '../../../../../../../../functions/query/product/allListProducts.js'

import AllProduct_Artikel from '../../../../../../../../functions/query/product/allProduct_Artikel.js'

import Cancel_black from '../../../../../../../../@appElements/item_Img/Cancel_black.js'
import Ok_green from '../../../../../../../../@appElements/item_Img/Ok_green.js'
import Cancel_red from '../../../../../../../../@appElements/item_Img/Cancel_red.js'



class Modal_Add extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchValue: this.props.searchValue,
      From: 100,
      resellerArray: [],
      id:0    };
    this.getValueOfInput = this.getValueOfInput.bind(this);
  }


  more = () => {
    //if(this.state.From==this.props.AllListCustomer.allListCustomers.length){
      //if(this.state.post){
        this.setState({
          post: true, 
          From:200 
        })
        this.props.AllListProducts.fetchMore({
          variables: {
            searchValue:this.state.searchValue, From: 200
          },
          updateQuery: (prev, { fetchMoreResult }) => {
            if (!fetchMoreResult) return prev;
            return Object.assign({}, prev, {
              allListProducts: [...prev.allListProducts, ...fetchMoreResult.allListProducts]
            });
          }
      })
    //}
  //}
  }


  getValueOfInput = (event) => {
    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})
  }


  onBlur = (id) =>{
    this.setState({id: this.props.AllListProducts.allListProducts[id-1].id})
  }

  render() {
    return (
      <div>
        <Row style={{padding: "10px 0 0 0"}}>
          <Col lg={5}>
            <Title 
              top={"0px"} 
              text="Reseller Prise "/>
          </Col>
          <Col lg={1} lgOffset={6}>
            <Cancel_black onClick={this.props.closeModal}/>
          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={12}  >
            <SimpleDropdown
              onBlur={this.onBlur}
              searchValue={this.props.searchValue}
              search={this.props.getValueOfInput}
              style={{zIndex: 14}} 
              list={this.props.AllListProducts.allListProducts} 
              text="Article"
              row={"productNm"}
              row1={"nameProduct"}
              next={this.more}
              gruppeId={this.props.LinkArticle}
              value={this.props.AllProduct_Artikel.allProduct_Artikel?this.props.AllProduct_Artikel.allProduct_Artikel[0].itemsNm +" "+ this.props.AllProduct_Artikel.allProduct_Artikel[0].name: undefined}
            />
          </Col>

          <Col lg={12} >
            <Col lg={6}>
              <Input 
                type="Number"
                text="Price" 
                value={this.props.Price} 
                name='Price' 
                onChange={this.props.getValueOfInput}/>
            </Col>
            <Col lg={6}>
            </Col>
          </Col>

          <Col lg={12}>
            <Textarea 
              width="463px" 
              height="104px" 
              value={this.props.Description} 
              name='Description' 
              type="text" 
              text="Note"
              onChange={this.props.getValueOfInput}/>
          </Col>
        </Row>

        <Col lg={12} className="hr">
        </Col>

        <Col lg={12}>
          <Col lg={4} lgOffset={1}  onClick={this.props.closeModal}>
            <Button 
              top={"11px"}
              width={"145px"}
              size={"16px"} 
              height={"30px"} 
              color={"#7ed321"} 
              onClick={this.props.update.bind(this, this.state.id)}
              text={
                <div style={{padding: "5px 0 0 0"}}> 
                  <Col lg={4}> <Ok_green/> </Col>
                  <Col lg={8} style={{padding: "3px 0 0 0"}}>Save</Col>
                </div>
            }/>
          </Col>
          <Col lg={4} lgOffset={2}  onClick={this.props.closeModal}>
            <Button 
              top={"11px"}
              width={"145px"}
              size={"16px"} 
              height={"30px"} 
              color={"#d0021b"} 
              text={
                <div style={{padding: "5px 0 0 0"}}> 
                  <Col lg={4}> <Cancel_red/> </Col>
                  <Col lg={8} style={{padding: "3px 0 0 0"}}>Cancel</Col>
                </div>
            }/>
          </Col>
          <Col lg={1}>
          </Col>
        </Col>
      </div> 
    )
  }
}


  const graph = compose(

    graphql(AllProduct_Artikel, {
        options: (props) => ({
            fetchPolicy: 'network-only',
            variables: {
              id: props.LinkArticle,
            }
        }),
        name: "AllProduct_Artikel",
    }),
    graphql(AllListProducts, {
        options: (props) => ({
            fetchPolicy: 'cache-and-network',
            variables: {
              SearchValue: props.searchValue, From:0
            }
        }),
        name: "AllListProducts"}),
)(Modal_Add);

export default graph;