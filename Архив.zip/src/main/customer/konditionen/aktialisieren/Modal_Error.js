import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import { Col, Row } from 'react-bootstrap';
import styled from 'styled-components';

import Dropdown from '../../../../../../../../@appElements/dropDown/Dropdown.js';
import Text from '../../../../../../../../@appElements/text/Text.js';
import SimpleDropdown from '../../../../../../../../@appElements/dropDown/SimpleDropdown.js';
import CheckBox from '../../../../../../../../@appElements/checkBox/CheckBox.js';
import Title from '../../../../../../../../@appElements/title/Title.js'
import Input from '../../../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../../../@appElements/textarea/Textarea.js'
import Button from '../../../../../../../../@appElements/button/Button.js'
import Calendar from '../../../../../../../../@appElements/calendar/Calendar.js'

import Cancel_black from '../../../../../../../../@appElements/item_Img/Cancel_black.js'
import Ok_green from '../../../../../../../../@appElements/item_Img/Ok_green.js'
import Cancel_red from '../../../../../../../../@appElements/item_Img/Cancel_red.js'

import buttonImg from '../../../../../../../../img/updete.svg'
import cancel_black from '../../../../../../../../img/cancel_black.svg';
import cancel_grey from '../../../../../../../../img/cancel_grey.svg';
import ok_green from '../../../../../../../../img/ok_green.svg';


class Modal_Error extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }








  render() { 
    return (
      <Row>
        <Row>
          <Col lg={5}>
            <Title 
              text="Error"/>
          </Col>
          <Col lg={1} lgOffset={6}>
            <Cancel_black onClick={this.props.closeModal}/>
          </Col>
        </Row>
        <Row style={{padding: "0 10px 0 10px"}}>
          <Row>
            <Col lg={12} className="hr_grey">
            </Col>
          </Row>
          <Row style={{padding: "50px 10px 0 10px"}}>
            <Text color="red" size="20px" text={this.props.text}/>
          </Row>
          <Row style={{padding: "45px 0 0 0 "}}>
            <Col lg={4} lgOffset={4}  onClick={this.props.closeModal}>
              <Button 
                border="1px solid #d0021b"
                top={"23px"}
                width={"145px"}
                size={"16px"} 
                height={"30px"} 
                color={"#d0021b"} 
                text={
                  <div style={{padding: "-1px 0 0 0"}}> 
                    <Col lg={4}> <Cancel_red/> </Col>
                    <Col lg={8} style={{padding: "0px 0 0 0"}}>Cancel</Col>
                  </div>
              }/>
            </Col>
            <Col lg={4}>
            </Col>
          </Row>
        </Row>
      </Row> 
    )
  }
}

export default Modal_Error;