import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import { Col, Row } from 'react-bootstrap';
import styled from 'styled-components';

import Text from '../../../../../../../../@appElements/text/Text.js';
import SimpleDropdown from '../../../../../../../../@appElements/dropDown/SimpleDropdown.js';
import CheckBox from '../../../../../../../../@appElements/checkBox/CheckBox.js';
import Title from '../../../../../../../../@appElements/title/Title.js'
import Button from '../../../../../../../../@appElements/button/Button.js'
import Calendar from '../../../../../../../../@appElements/calendar/Calendar.js'

import Cancel_black from '../../../../../../../../@appElements/item_Img/Cancel_black.js'
import Ok_green from '../../../../../../../../@appElements/item_Img/Ok_green.js'
import Cancel_red from '../../../../../../../../@appElements/item_Img/Cancel_red.js'

import buttonImg from '../../../../../../../../img/updete.svg'

class Modal_Add extends Component {
  constructor(props) {
    super(props);
    this.state = {
      period:false,
      nowDate: new Date,
      vonDatum: "",
      bisDatum: "",
      year: new Date().getFullYear(),
      indexYear: 5,
      month: '',
      lastMonth: '',
      lastDay: '',
      January: true,
      February: false,
      March: false,
      April: false,
      May: false,
      June: false,
      July: false,
      August: false,
      September: false,
      October: false,
      November: false,
      December: false,
      list:[
      {i:2014},
      {i:2015},
      {i:2016},
      {i:2017},
      {i:2018},
      {i:2019},
      {i:2020},
      {i:2021},
      {i:2022},
      {i:2023},
      {i:2024},
      {i:2025},
      {i:2026}]
    };
  }




  closeModal = async () => {
    await this.props.closeModal(this.state.vonDatum, this.state.bisDatum)

    await  this.setState({
      vonDatum: "",
      bisDatum: "",
    });
  }

  getLastDayOfMonth = () => {
    var date = new Date(this.state.year, this.state.month, 0);
    this.setState({lastDay: date.getDate()})
  }

  validationChackBox = async (month, numberMonth) => {
    let menu = this.state;
    for (var key in menu) {
     menu[key]===true? this.setState({[key]: false,period:true}): null
    };
    await this.setState({
      [month]:true, 
      month: numberMonth,
      lastMonth: numberMonth
    });
    await this.getLastDayOfMonth();

    await  this.setState({
      vonDatum: this.state.year+"-"+this.state.month+"-"+"01",
      bisDatum: this.state.year+"-"+this.state.lastMonth+"-"+this.state.lastDay,
    });
  }

  firstHfYear = () =>{
    this.setState({
      vonDatum: this.state.year+"-01-01",
      bisDatum: this.state.year+"-06-30",
      period: true
    });
  }

  secondHfYear = () =>{
    this.setState({
      vonDatum: this.state.year+"-07-01",
      bisDatum: this.state.year+"-12-31",
      period: true
    });
  }

  firstQuarternYear = () =>{
    this.setState({
      vonDatum: this.state.year+"-01-01",
      bisDatum: this.state.year+"-03-31",
      period: true
    });
  }

  secondQuarternYear = () =>{
    this.setState({
      vonDatum: this.state.year+"-04-01",
      bisDatum: this.state.year+"-06-30",
      period: true
    });
  }

  thirdQuarternYear = () =>{
    this.setState({
      vonDatum: this.state.year+"-07-01",
      bisDatum: this.state.year+"-09-30",
      period: true
    });
  }

  fourthQuarternYear = () =>{
    this.setState({
      vonDatum: this.state.year+"-10-01",
      bisDatum: this.state.year+"-12-31",
      period: true
    });
  }

  selectIndexDropDown = (index) => {
    let vonDatum = this.state.vonDatum.substring(4)
    let bisDatum = this.state.bisDatum.substring(4)
    this.setState({
      year: new Date().getFullYear()+index,
      indexYear: index+1,
    });

    this.state.vonDatum?
     this.setState({
      vonDatum: new Date().getFullYear()+index+vonDatum,
      bisDatum: new Date().getFullYear()+index+bisDatum
     }):null


  }

    getVonDatumDate=(i)=>{
    this.setState({vonDatum: i})
  }

  getBisDatumDate=(i)=>{
    this.setState({bisDatum: i})
  }




  render() { 
    {    /*            getBisDatumDate={this.getBisDatumDate}
                vonDatum={this.state.vonDatum?this.state.vonDatum:String(new Date().getFullYear()).replace(/^(.)$/, "0$1") + 
      '-'+ String(new Date().getMonth()+1).replace(/^(.)$/, "0$1") +
      '-' + new Date().getDate()}
                bisDatum={this.state.bisDatum?this.state.bisDatum:String(new Date().getFullYear()).replace(/^(.)$/, "0$1") + 
      '-'+ String(new Date().getMonth()+1).replace(/^(.)$/, "0$1") +
      '-' + new Date().getDate()}*/}
    return (
      <div>
        <Row style={{padding: "10px 0 0 0"}} 
              onClick={this.validationChackBox}>
          <Col lg={5}>
            <Title 
              top={"0px"} 
              text="Reseller Prise "/>
          </Col>
          <Col lg={1} lgOffset={6}>
            <Cancel_black onClick={this.props.closeModal}/>
          </Col>
        </Row>
        <Row style={{padding: "10px 10px 10px 10px", "border-bottom": "1px solid #e0e0e0"}} >
          <Text text="Tag"/>
          {this.state.period?
          <React.Fragment>
          <Col lg={4}>
             <Calendar 
                  getDate={this.getVonDatumDate}
                  date={this.state.vonDatum?new Date(this.state.vonDatum.slice(0, 10).replace(/\-/g, ",")):new Date()}/>
          </Col>
          <Col lg={4}>
             <Calendar 
                  getDate={this.getBisDatumDate}
                  date={this.state.bisDatum?new Date(this.state.bisDatum.slice(0, 10).replace(/\-/g, ",")):new Date()}/>
          </Col>
          </React.Fragment>:
          <React.Fragment>
          <Col lg={4}>
             <Calendar 
                  getDate={this.getVonDatumDate}
                  date={this.state.vonDatum?new Date(this.state.vonDatum.slice(0, 10).replace(/\-/g, ",")):new Date()}/>
          </Col>
        <Col lg={4}>
        </Col>
        </React.Fragment>}
          <Col lg={4}>
            <Col lg={1}>
            </Col>
            <Col lg={10} style={{'margin-top': "-2px"}}>
              <SimpleDropdown  select={this.selectIndexDropDown} gruppeId={this.state.indexYear} row="i" list={this.state.list}/>
            </Col>
            <Col lg={1}>
            </Col>
          </Col>
        </Row>
            <Row style={{padding: "10px 10px 0px 10px"}} >
              <Col lg={6}>
                <Col lg={4}></Col>
                <Col lg={7}><Button onFocusBackground="#4a90e2" onFocusColor="white" background = "white"  onClick={this.firstHfYear} paddingTop = "5px" color = "black"  width = "135px" height = "30px"  text="1 Jahreshalfte" border = "1px solid #4a90e2"/></Col>
                <Col lg={1}></Col>
              </Col>

              <Col lg={6}>
                <Col lg={1}></Col>
                <Col lg={7}><Button onFocusBackground="#4a90e2" onFocusColor="white" background = "white" onClick={this.secondHfYear}  color = "black" width = "135px" height = "30px"  text="1 Jahreshalfte" border = "1px solid #4a90e2" text="2 Jahreshalfte"/></Col>
                <Col lg={4}></Col>
              </Col>
            </Row>

            <Row style={{padding: "10px 10px 10px 10px", "border-bottom": "1px solid #e0e0e0"}}>
              <Col lg={3}>
                <Col lg={1}></Col>
                <Col lg={10}><Button onFocusBackground="#4a90e2" onFocusColor="white" background = "white" onClick={this.firstQuarternYear} color = "black" width = "106px" height = "30px"  text="1 Jahreshalfte" border = "1px solid #4a90e2" text="1 Quartal"/></Col>
                <Col lg={1}></Col>
              </Col>

              <Col lg={3}>
                <Col lg={1}></Col>
                <Col lg={10}><Button onFocusBackground="#4a90e2" onFocusColor="white" background = "white" onClick={this.secondQuarternYear} color = "black" width = "106px" height = "30px"  text="1 Jahreshalfte" border = "1px solid #4a90e2" text="2 Quartal"/></Col>
                <Col lg={1}></Col>
              </Col>

              <Col lg={3}>
                <Col lg={1}></Col>
                <Col lg={10}><Button onFocusBackground="#4a90e2" onFocusColor="white" background = "white" onClick={this.thirdQuarternYear} color = "black" width = "106px" height = "30px"  text="1 Jahreshalfte" border = "1px solid #4a90e2" text="3 Quartal"/></Col>
                <Col lg={1}></Col>
              </Col>

              <Col lg={3}>
                <Col lg={1}></Col>
                <Col lg={10}><Button onFocusBackground="#4a90e2" onFocusColor="white" background = "white"   onClick={this.fourthQuarternYear} color = "black" width = "106px" height = "30px"  text="1 Jahreshalfte" border = "1px solid #4a90e2" text="4 Quartal"/></Col>
                <Col lg={1}></Col>
              </Col>
            </Row>
            <Row style={{padding: "0 0 0 15px"}}>
              <Row>
                <Col lg={3}>
                  <Col lg={8}> <CheckBox open={this.state.January} onClick={this.validationChackBox.bind(this, "January", "01")} value={'January'} margin_top={{'margin': '4px 0 0 0px'}}/> </Col>
                  <Col lg={4}></Col>
                </Col>

                <Col lg={3}>
                  <Col lg={8}> <CheckBox open={this.state.February} onClick={this.validationChackBox.bind(this, "February", "02")} value={'February'} margin_top={{'margin': '4px 0 0 0px'}}/> </Col>
                  <Col lg={4}></Col>
                </Col>

                <Col lg={3}>
                  <Col lg={8}> <CheckBox open={this.state.March} onClick={this.validationChackBox.bind(this, "March", "03")} value={'March'} margin_top={{'margin': '4px 0 0 0px'}}/> </Col>
                  <Col lg={4}></Col>
                </Col>

                <Col lg={3}>
                  <Col lg={8}> <CheckBox open={this.state.April} onClick={this.validationChackBox.bind(this, "April", "04")} value={'April'} margin_top={{'margin': '4px 0 0 0px'}}/> </Col>
                  <Col lg={4}></Col>
                </Col>
              </Row>

              <Row>
                <Col lg={3}>
                  <Col lg={8}> <CheckBox open={this.state.May} onClick={this.validationChackBox.bind(this, "May", "05")} value={'May'} margin_top={{'margin': '4px 0 0 0px'}}/> </Col>
                  <Col lg={4}></Col>
                </Col>

                <Col lg={3}>
                  <Col lg={8}> <CheckBox open={this.state.June} onClick={this.validationChackBox.bind(this, "June", "06")} value={'June'} margin_top={{'margin': '4px 0 0 0px'}}/> </Col>
                  <Col lg={4}></Col>
                </Col>

                <Col lg={3}>
                  <Col lg={8}> <CheckBox open={this.state.July} onClick={this.validationChackBox.bind(this, "July", "07")} value={'July'} margin_top={{'margin': '4px 0 0 0px'}}/> </Col>
                  <Col lg={4}></Col>
                </Col>

                <Col lg={3}>
                  <Col lg={8}> <CheckBox open={this.state.August} onClick={this.validationChackBox.bind(this, "August", "08")} value={'August'} margin_top={{'margin': '4px 0 0 0px'}}/> </Col>
                  <Col lg={4}></Col>
                </Col>
              </Row>

              <Row>
                <Col lg={3}>
                  <Col lg={8}> <CheckBox open={this.state.September} onClick={this.validationChackBox.bind(this, "September", "09")} value={'September'} margin_top={{'margin': '4px 0 0 0px'}}/> </Col>
                  <Col lg={4}></Col>
                </Col>

                <Col lg={3}>
                  <Col lg={8}> <CheckBox open={this.state.October} onClick={this.validationChackBox.bind(this, "October", "10")} value={'October'} margin_top={{'margin': '4px 0 0 0px'}}/> </Col>
                  <Col lg={4}></Col>
                </Col>

                <Col lg={3}>
                  <Col lg={8}> <CheckBox open={this.state.November} onClick={this.validationChackBox.bind(this, "November", "11")} value={'November'} margin_top={{'margin': '4px 0 0 0px'}}/> </Col>
                  <Col lg={4}></Col>
                </Col>

                <Col lg={3}>
                  <Col lg={8}> <CheckBox open={this.state.December} onClick={this.validationChackBox.bind(this, "December", "12")} value={'December'} margin_top={{'margin': '4px 0 0 0px'}}/> </Col>
                  <Col lg={4}></Col>
                </Col>
              </Row>
            </Row>

            <div>
              <Col lg={12} className="hr_grey">
              </Col>
            </div>

            <Col lg={12}>
              <Col lg={4} lgOffset={1}  onClick={this.closeModal}>
                <Button 
                  top={"11px"}
                  width={"145px"}
                  size={"16px"} 
                  height={"30px"} 
                  color={"#7ed321"} 
                  text={
                    <div style={{padding: "5px 0 0 0"}}> 
                      <Col lg={4}> <Ok_green/> </Col>
                      <Col lg={8} style={{padding: "3px 0 0 0"}}>Save</Col>
                    </div>
                }/>
              </Col>
              <Col lg={4} lgOffset={2}  onClick={this.props.closeModal}>
                <Button 
                  top={"11px"}
                  width={"145px"}
                  size={"16px"} 
                  height={"30px"} 
                  color={"#d0021b"} 
                  text={
                    <div style={{padding: "5px 0 0 0"}}> 
                      <Col lg={4}> <Cancel_red/> </Col>
                      <Col lg={8} style={{padding: "3px 0 0 0"}}>Cancel</Col>
                    </div>
                }/>
              </Col>
              <Col lg={1}>
              </Col>
            </Col>

          </div> 
    )
  }
}

export default Modal_Add;