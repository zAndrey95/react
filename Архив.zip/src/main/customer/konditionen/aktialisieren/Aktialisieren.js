import React, { Component } from 'react';
import { Col, Row} from 'react-bootstrap';


import { graphql, compose } from 'react-apollo';

import CheckBox from '../../../../../../../../@appElements/checkBox/CheckBox.js';
import Modal from '../../../../../../../../@appElements/modal/Modal.js'
import Modal_Add from './Modal_Add.js'
import Modal_Error from './Modal_Error.js'
import Refresh from '../../../../../../../../@appElements/item_Img/Refresh.js'
import Calendar from '../../../../../../../../@appElements/calendar/Calendar.js';
import Button from '../../../../../../../../@appElements/button/Button.js';
import Input from '../../../../../../../../@appElements/input/Input.js'

import Period_calendar_modal from '../../../../../../../../@appElements/period_calendar_modal/Period_calendar_modal.js'

import getPR_ReCalculateOrders from '../../../../../../../../functions/mutation/customer/getPR_ReCalculateOrders.js'

class Aktialisieren extends Component {
  constructor() {
    super();

    this.state = {
      fromDate: "",
      toDate: "",
      modalIsOpen: false,
      bit3: false,
      bit1: false,
      bit2: false,
      modalErrorOpen: false
    };
  }

  openModal = () => {
    this.setState({modalIsOpen: true});
  }


  closeModal = (fromDate, toDate) => {
    toDate?
      this.setState({modalIsOpen: false,
        fromDate: fromDate,
        toDate: toDate
      })
    :this.setState({modalIsOpen: false,fromDate: fromDate,
        toDate: fromDate})
  }

  getPR_ReCalculateOrders = () =>{
    this.props.getPR_ReCalculateOrders({
    variables:{
      fromDate: this.state.fromDate, 
      toDate: this.state.toDate, 
      id: this.props.intern, 
      bit3: this.state.bit3, 
      bit1: this.state.bit1, 
      bit2: this.state.bit2
    },

    options: {
      fetchPolicy: 'network-only'
    },
  })
  }

  changeBit1 = () =>{
    this.setState({bit1: !this.state.bit1})
  }

  changeBit2 = () =>{
    this.setState({bit2: !this.state.bit2})
  }

  changeBit3 = () =>{
    this.setState({bit3: !this.state.bit3})
  }

  openErrorModal = () => {
    this.setState({modalErrorOpen: true})
  }

  closeErrorModal = () => {
    this.setState({modalErrorOpen: false})
  }



  

  
  render() {
    return (

      <Row style={{padding: "20px 0 0 15px"}}>
       <Modal

            isOpen={this.state.modalIsOpen}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            contentLabel="Example Modal"
            width={"481px"}
            height={"365px"}
            size={"16px"}
            component={
              <Period_calendar_modal
                 closeModal={this.closeModal}/>}
          />

          <Modal

            isOpen={this.state.modalErrorOpen}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeErrorModal}
            contentLabel="Example Modal"
            width={"481px"}
            height={"365px"}
            size={"16px"}
            component={
              <Modal_Error
                text="You have not chosen a period!"
                 closeModal={this.closeErrorModal}/>}
          />

        <Row>
          <Col lg={6}>  
            <span> Wenn Sie an den Kundenkonditionen an den Artikelpreises Anderungen vorgenommen Haben, 
             konnen Sie mit dieses Funktion bestehenen unfakturierte Lieferscheine automatisch ruckwirkend anpassen lassen.</span>
          </Col> 
          <Col lg={6}>  
          </Col> 
        </Row>
        <Row style={{margin: "10px 0 0 0px"}}>
          <Col lg={3} onClick={this.openModal}>
            <Input width="80%" value={this.state.fromDate}/>
          </Col> 
          <Col lg={9}> </Col>
        </Row>
        <Col lg={12}>
          <CheckBox onClick={this.changeBit1} value={'Preise anpassen'} style={{'margin': '24px 0 0 0px'}}  open={this.state.bit1}/> 
        </Col>
        <Col lg={12}>
          <CheckBox onClick={this.changeBit2} value={'Konditionen anpassen'} style={{'margin': '19px 0 0 0px'}} open={this.state.bit2}/> 
        </Col>
        <Col lg={12}>
          <CheckBox onClick={this.changeBit3} value={'nur Cash Assist Belege anpassen'} style={{'margin': '19px 0 0 0px'}} open={this.state.bit3}/> 
        </Col>
        <Row>
          <Col lg={2}>
            <Button 
              border = "1px solid black"
              color="#4a90e2" 
              top="50px" 
              paddingTop="10px" 
              height="42px" 
              width="205px" 
              size="16px" 
              text={
                <Row onClick={this.state.toDate?this.getPR_ReCalculateOrders:this.openErrorModal}>
                  <Col lg={3}>
                    <Refresh top="-5px"/>
                    </Col>
                  <Col lg={9}>Aktualisieren Kunde</Col>
                </Row>}/>
          </Col> 
        </Row>
      </Row>
    );
  }
}


const graph = compose(
  graphql(getPR_ReCalculateOrders, {name:"getPR_ReCalculateOrders"}),
)(Aktialisieren);

export default graph;
