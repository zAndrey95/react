import React, { Component } from 'react';
import {Col} from 'react-bootstrap';
import { graphql, compose } from 'react-apollo';

import './Tour.css';

import edit from '../../../../../../img/edit.svg';

import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';

import AllCustomers_Tour from '../../../../../../functions/query/customer/allCustomers_Tour.js'

class Input extends Component {
  	constructor(props) {
    super(props);
    this.state = {
        

    };
  }
render() {
    return (
      		
	      	  	<input style={this.props.style} value={this.props.value === null ? "" : this.props.value} name={this.props.name} onChange={this.props.onChange} onBlur={this.props.onBlur} className={this.props.className}/>
			
  );
   }
}

export default Input;



