import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { graphql, compose } from 'react-apollo';
import styled from 'styled-components';

import edit from '../../../../../../img/edit.svg';

import {Mutations} from '../../../../../../@appElements/functions/Mutation.js';

import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';
import Input from '../../../../../../@appElements/input/Input.js'
import SimpleDropdown from '../../../../../../@appElements/dropDown/SimpleDropdown.js'

import allCUSTOMER_TOUR_StandardTour from '../../../../../../functions/query/customer/allCUSTOMER_TOUR_StandardTour.js'
import AllCustomers_Tour from '../../../../../../functions/query/customer/allCustomers_Tour.js'
import updateCustomers_Tour from '../../../../../../functions/mutation/customer/updateCustomers_Tour.js'

const StyledCol = styled(Col)`
  margin-top:44px;
`;
const NameTextArea = styled.div`
  font-family: HelveticaNeue;
  font-size: 16px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #000000;
  margin-top:44px;
`;

const TextArea = styled.textarea`
  width: 635px;
  min-height: 111px;
  border-radius: 8px;
  border: solid 1px #d2d2d2;
`;

class Tour extends Component {
  state = {
        Ruestplatz: 0,
        RuestplatzSa:  0,
        RuestplatzSo: 0,
        TourenplanImmer: 0,
        TourenplanBemerkung: 0,
        LinkTourenplan: 0,
        LinkTourenplanSa: 0,
        LinkTourenplanSo: 0,
        TourenplanReihenfolge: 0,
        TourenplanReihenfolgeSa: 0,
        TourenplanReihenfolgeSo: 0,
        TourenplanZeit: 0,
        TourenplanZeitSa: 0,
        TourenplanZeitSo: 0,
        map: [1,2,3]
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if(!nextProps.AllCustomers_Tour.loading){
      const  store = nextProps.AllCustomers_Tour.allCustomers_Tour[0];
        return {
        Ruestplatz: store.Ruestplatz,
        RuestplatzSa: store.RuestplatzSa,
        RuestplatzSo: store.RuestplatzSo,
        TourenplanImmer: store.TourenplanImmer,
        TourenplanBemerkung: store.TourenplanBemerkung,
        LinkTourenplan: store.LinkTourenplan,
        LinkTourenplanSa: store.LinkTourenplanSa,
        LinkTourenplanSo: store.LinkTourenplanSo,
        TourenplanReihenfolge: store.TourenplanReihenfolge,
        TourenplanReihenfolgeSa: store.TourenplanReihenfolgeSa,
        TourenplanReihenfolgeSo: store.TourenplanReihenfolgeSo,
        TourenplanZeit: store.TourenplanZeit,
        TourenplanZeitSa: store.TourenplanZeitSa,
        TourenplanZeitSo: store.TourenplanZeitSo,
        }
      
    return null
   }
  }

  updateTourCheckBox = () => {
    this.setState({TourenplanImmer: !this.state.TourenplanImmer})
    this.props.updateCustomers_Tour({
      variables: {
        Intern:this.props.intern,
        TourenplanImmer: !this.state.TourenplanImmer, 
      },
      options: {
        fetchPolicy: 'network-only'
      }
    })
  }

  getValueOfInput = (event) => {
    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})
  }


  updateTour=(e)=>{
    const key = e.target.name;
    const value = this.state[key];
    Mutations(
      {[key]: value},
      this.props.updateCustomers_Tour, 
      "Intern",
      this.props.intern
    );
  }

  updeteDropDown1=(id)=>{
    this.props.updateCustomers_Tour({
      variables: {
        Intern:this.props.intern,
        LinkTourenplan: id, 
      },
      options: {
        fetchPolicy: 'network-only'
      }
    })
  }

  updeteDropDown2 = (id) => {
    this.props.updateCustomers_Tour({
      variables: {
        Intern:this.props.intern,
        LinkTourenplanSa: id, 
      },
      options: {
        fetchPolicy: 'network-only'
      }
    })
  }

  updeteDropDown3 = (id) => {
    this.props.updateCustomers_Tour({
      variables: {
        Intern:this.props.intern,
        LinkTourenplanSo: id, 
      },
      options: {
        fetchPolicy: 'network-only'
      }
    })
  }

  render() {
    if(this.props.AllCustomers_Tour.loading||this.props.allCUSTOMER_TOUR_StandardTour.loading ){return (<div>Loading...</div>)}
    else{
      return (
          <Row style={{padding: '0 0 0 15px'}}>
            <Col lg={3} >
              <Input
                type="number"
                width='80%'
                text='Set-up station'
                value={this.state.Ruestplatz}
                onBlur={this.updateTour}
                name="Ruestplatz"
                onChange={this.getValueOfInput}/>
              <Input
                type="number"
                width='80%'
                text='Set-up station'
                value={this.state.RuestplatzSa}
                onBlur={this.updateTour}
                name="RuestplatzSa"
                onChange={this.getValueOfInput}/>
              <Input
                type="number"
                width='80%'
                text='Set-up station'
                value={this.state.RuestplatzSo}
                onBlur={this.updateTour}
                name="RuestplatzSo"
                onChange={this.getValueOfInput}/>
            </Col>
            <Col lg={3} style={{marginTop: "-6px"}}>
              <SimpleDropdown
                style={{width:'80%', zIndex: 11}}
                row={"Bezeichnung"}
                list={this.props.allCUSTOMER_TOUR_StandardTour.allCUSTOMER_TOUR_StandardTour}
                text='Standard Tour'
                gruppeId={this.state.LinkTourenplan}
                onBlur={this.updeteDropDown1}
              />
              <SimpleDropdown
                style={{width:'80%', zIndex: 10}}
                row={"Bezeichnung"}
                list={this.props.allCUSTOMER_TOUR_StandardTour.allCUSTOMER_TOUR_StandardTour}
                text='Standard Tour'
                gruppeId={this.state.LinkTourenplanSa}
                onBlur={this.updeteDropDown2}
              />
              <SimpleDropdown
                style={{width:'80%', zIndex: 9}}
                row={"Bezeichnung"}
                list={this.props.allCUSTOMER_TOUR_StandardTour.allCUSTOMER_TOUR_StandardTour}
                text='Standard Tour'
                gruppeId={this.state.LinkTourenplanSo}
                onBlur={this.updeteDropDown3}
              />
            </Col>
            <Col lg={3}>
              <Input
                type="number"
                width='80%'
                text='Driving pos.'
                value={this.state.TourenplanReihenfolge}
                onBlur={this.updateTour}
                name="TourenplanReihenfolge"
                onChange={this.getValueOfInput}/>
              <Input
                type="number"
                width='80%'
                text='Driving pos.'
                value={this.state.TourenplanReihenfolgeSa}
                onBlur={this.updateTour}
                name="TourenplanReihenfolgeSa"
                onChange={this.getValueOfInput}/>
              <Input
                type="number"
                width='80%'
                text='Driving pos.'
                value={this.state.TourenplanReihenfolgeSo}
                onBlur={this.updateTour}
                name="TourenplanReihenfolgeSo"
                onChange={this.getValueOfInput}/>
            </Col>
            <Col lg={3}>
              <Input
                type="number"
                width='80%'
                text='Delivery time'
                value={this.state.TourenplanZeit}
                onBlur={this.updateTour}
                name="TourenplanZeit"
                onChange={this.getValueOfInput}/>
              <Input
                type="number"
                width='80%'
                text='Delivery time'
                value={this.state.TourenplanZeitSa}
                onBlur={this.updateTour}
                name="TourenplanZeitSa"
                onChange={this.getValueOfInput}/>
              <Input
                type="number"
                width='80%'
                text='Delivery time'
                value={this.state.TourenplanZeitSo}
                onBlur={this.updateTour}
                name="TourenplanZeitSo"
                onChange={this.getValueOfInput}/>
            </Col>

            <StyledCol lg={12}>
        			<CheckBox value={'Wenn keine Lieferung auffuhren'} onClick={this.updateTourCheckBox} open={this.state.TourenplanImmer}/>
              <NameTextArea>Tour Bemerkung</NameTextArea>
        			<TextArea onChange={this.getValueOfInput} onBlur={this.updateTour} name="TourenplanBemerkung" value={this.state.TourenplanBemerkung }/>
        		</StyledCol>
          </Row>
      );
    }
  }
}

const graph = compose(
  graphql(AllCustomers_Tour, {
    options: (props) => ({
      fetchPolicy: 'network-only',
      variables: {Intern: props.intern},
    }),
    name: "AllCustomers_Tour"}),
  graphql(allCUSTOMER_TOUR_StandardTour, {name:"allCUSTOMER_TOUR_StandardTour"}),
  graphql(updateCustomers_Tour, {name:"updateCustomers_Tour"}),
)(Tour);

export default graph;
