import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import { Col, Row } from 'react-bootstrap';
import styled from 'styled-components';

import Dropdown from '../../../../../../@appElements/dropDown/Dropdown.js';
import SimpleDropdown from '../../../../../../@appElements/dropDown/SimpleDropdown.js';
import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';
import Title from '../../../../../../@appElements/title/Title.js'
import Input from '../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../@appElements/textarea/Textarea.js'
import Button from '../../../../../../@appElements/button/Button.js'

import Cancel_black from '../../../../../../@appElements/item_Img/Cancel_black.js'
import Ok_green from '../../../../../../@appElements/item_Img/Ok_green.js'
import Cancel_red from '../../../../../../@appElements/item_Img/Cancel_red.js'

import buttonImg from '../../../../../../img/updete.svg'
import cancel_black from '../../../../../../img/cancel_black.svg';
import cancel_grey from '../../../../../../img/cancel_grey.svg';
import ok_green from '../../../../../../img/ok_green.svg';


class Modal_Add extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Note: "",
    };
  }



  addModalInputsInArray(){
    //let ar = this.state.artikelArray;
    //Object.preventExtensions(ar);
    //ar.push(1);
  }




  onChangeCalClose = (date) => {
    this.setState({date, openCalendar: false})
  };

  onChangeCalOpen = () => this.setState({openCalendar: true });


  render() { 
    return (
      <Row>
        <Row>
          <Col lg={5}>
            <Title 
              text="CRM"/>
          </Col>
          <Col lg={1} lgOffset={6}>
            <Cancel_black onClick={this.props.closeModal}/>
          </Col>
        </Row>
        <Row style={{padding: "0 10px 0 10px"}}>
          <Row>
            <Textarea width="100%" height="104px" onChange={this.props.onChange.bind(this)} onBlur={this.props.updateNote} name="Note" value={this.props.Note} text="Note"/>
          </Row>


          <Row>
            <Col lg={12} className="hr_grey">
            </Col>
          </Row>

          <Row>
            <Col lg={4} lgOffset={1}  onClick={this.props.closeModal}>
              <Button 
                top={"11px"}
                width={"145px"}
                size={"16px"} 
                height={"30px"} 
                color={"#7ed321"} 
                text={
                  <div style={{padding: "5px 0 0 0"}}> 
                    <Col lg={4} onClick={this.props.update}> <Ok_green/> </Col>
                    <Col lg={8} style={{padding: "3px 0 0 0"}}>Save</Col>
                  </div>
              }/>
            </Col>
            <Col lg={4} lgOffset={2}  onClick={this.props.closeModal}>
              <Button 
                top={"11px"}
                width={"145px"}
                size={"16px"} 
                height={"30px"} 
                color={"#d0021b"} 
                text={
                  <div style={{padding: "5px 0 0 0"}}> 
                    <Col lg={4}> <Cancel_red/> </Col>
                    <Col lg={8} style={{padding: "3px 0 0 0"}}>Cancel</Col>
                  </div>
              }/>
            </Col>
            <Col lg={1}>
            </Col>
          </Row>
        </Row>
      </Row> 
    )
  }
}

export default Modal_Add;