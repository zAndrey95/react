import React, { Component } from 'react';
import {  Row, Col} from 'react-bootstrap';
import { withRouter } from 'react-router'
import { graphql, compose } from 'react-apollo';

import AllCustomerCRMNotes from '../../../../../../functions/query/customer/allCustomerCRMNotes'
import updateCustomerCRMNotes from '../../../../../../functions/mutation/customer/updateCustomerCRMNotes.js'
import addCustomerCRMNotes from '../../../../../../functions/mutation/customer/addCustomerCRMNotes.js'
import deleteCustomerCRMNotes from '../../../../../../functions/mutation/customer/DeleteCustomerCRMNotes.js'

import HeaderTable from '../../../../../../@appElements/table/HeaderTable.js'
import Table from '../../../../../../@appElements/table/Table.js'
import Plus_green from '../../../../../../@appElements/item_Img/Plus_green.js'
import Minus_red from '../../../../../../@appElements/item_Img/Minus_red.js'
import Edit_blue from '../../../../../../@appElements/item_Img/Edit_blue.js'
import Modal from '../../../../../../@appElements/modal/Modal.js'
import Modal_Add from './Modal_Add.js'


class Crm extends Component {

  constructor() {
    super();

    this.state = {
      modalIsOpen: false,
      modalIsOpen1: false,
      list: [],
      Note: "",
      indexOnClickTable:0,
      RecordID: 0,
      list2: []
    };
  }

  

   static getDerivedStateFromProps(nextProps, prevState) {
    if(!nextProps.AllCustomerCRMNotes.allCustomerCRMNotes){
      return null
    }
    if(!nextProps.AllCustomerCRMNotes.loading){
        return {
          list: nextProps.AllCustomerCRMNotes.allCustomerCRMNotes,
          
        }
    }
      
    return null
   
    
  }

  openModal1 = () => {
    this.setState({modalIsOpen1: true, Note: ""});
  } 

  closeModal1 = () => {
    this.setState({modalIsOpen1: false});
  }


  openModal = () => {
    this.setState({modalIsOpen: true});
  } 

  closeModal = () => {
    this.setState({modalIsOpen: false});
  }

  indexOnClickTable = (index) => {
    this.setState({
    indexOnClickTable:index,
    Note: this.state.list[index].Note,
    RecordID: this.state.list[index].RecordID});
  }

  getValueOfInput = (event) => {
    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})
  }

  updateNote= async ()=>{
  await  this.props.updateCustomerCRMNotes({
      variables: {
        RecordID: this.state.RecordID,
        AddedOn: new Date(),
        Note: this.state.Note,
      },
      options: {
        fetchPolicy: 'network-only'
      },

      refetchQueries: [ { query: AllCustomerCRMNotes, variables: {LinkCustomer: this.props.intern} }]

    })

  }

  addNote= async ()=>{
  await  this.props.addCustomerCRMNotes({
      variables: {
        LinkCustomer: this.props.intern,
        AddedOn: new Date(),
        Note: this.state.Note
      },
      options: {
        fetchPolicy: 'network-only'
      },

      refetchQueries: [ { query: AllCustomerCRMNotes, variables: {LinkCustomer: this.props.intern} }]

    })

  }

  deleteCustomerCRMNotes = async () =>{
  await  this.props.deleteCustomerCRMNotes({
      variables: {
        RecordID: this.state.RecordID
      },
      options: {
        fetchPolicy: 'network-only'
      },

      refetchQueries: [ { query: AllCustomerCRMNotes, variables: {LinkCustomer: this.props.intern} }]

    })

  }

  render() {
    if(this.props.AllCustomerCRMNotes.loading){return null}
    else{
    const newArr=[];
    this.state.list.forEach((item)=>{
      newArr.push([ item.AddedOn, item.VonDatum, item.Note])
    })

      return (
        <Row>
          <Modal
              isOpen={this.state.modalIsOpen}
              onAfterOpen={this.afterOpenModal}
              onRequestClose={this.closeModal}
              contentLabel="Example Modal"
              width={"481px"}
              height={"275px"}
              component={<Modal_Add  
              closeModal={this.closeModal}
              updateNote={this.updateNote}
              Note={this.state.Note}
              onChange={this.getValueOfInput}/>}
            />

           <Modal
              isOpen={this.state.modalIsOpen1}
              onAfterOpen={this.afterOpenModal}
              onRequestClose={this.closeModal1}
              contentLabel="Example Modal"
              width={"481px"}
              height={"275px"}
              component={<Modal_Add  
              closeModal={this.closeModal1}
              updateNote={this.addNote}
              Note={this.state.Note}
              onChange={this.getValueOfInput}/>}
            />


          <HeaderTable 
            items={[
              <Plus_green
                onClick={this.openModal1}
                top="9px"
              />, 
              <Edit_blue
                onClick={this.openModal}
                top="5px"
              />,
              <Minus_red
                onClick={this.deleteCustomerCRMNotes}
                top="11px"
              />, 
              <div></div>
            ]} 
            widths={["6%", "6%","6%","82%"]}/>   

          <Table 
            onClick={this.indexOnClickTable} 
            names={["Date/time", "User name", "Note"]} 
            widths={['20%', '20%', '60%']} 
            arr={newArr}/>
        </Row>

      );
    }
  }
}

const graph = compose(
graphql(AllCustomerCRMNotes, {
        options: (props) => ({
            fetchPolicy: 'cache-and-network',
            variables: {
              LinkCustomer: props.intern,
            }
        }),
        name: "AllCustomerCRMNotes",
}),
  graphql(updateCustomerCRMNotes, {name:"updateCustomerCRMNotes"}),
  graphql(addCustomerCRMNotes, {name:"addCustomerCRMNotes"}),
  graphql(deleteCustomerCRMNotes, {name:"deleteCustomerCRMNotes"}),
)(Crm);
export default withRouter(graph);
