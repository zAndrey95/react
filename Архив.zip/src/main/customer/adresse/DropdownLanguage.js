import React, { Component } from 'react';
import { Row, Col} from 'react-bootstrap';

import edit from '../../../../../../img/edit.svg';
import add_color from '../../../../../../img/add_color.svg';
import delete_color from '../../../../../../img/delete_color.svg';
import dropdown_Open from '../../../../../../img/dropdown_Open.png';


class Dropdown extends Component {
     constructor(props) {
      super(props);
      this.state={
        
        open: false,
        values:"",
        idChange: "",
        background: "#67adff",
  
      }
      this.onBlurDropDown = this.onBlurDropDown.bind(this);
    }

getOpen(){
  this.setState({open: !this.state.open});
  

}

onSelect(index, e){
  this.setState({values: this.props.values[index].LanguageName});
  e.target.style.background = "#67adff";
  this.state.idChange ? this.setState({idChange: this.state.idChange.style.background=""}) : null;
  this.setState({ idChange: e.target});
}

onBlurDropDown(){
  this.setState({values: ""});
  this.setState({open: false});

}

  render() {
    const dropDown = this.props.list.map((item, index) => {
          return (<div key={index} onClick={this.onSelect.bind(this,index)}>{item.LanguageName}</div>)});

    return (
            <Row style={{padding:"0 0 25px 0"}}>
              <Col lg={12} tabIndex="99" onBlur={this.onBlurDropDown} >
                <div className="dropDown" style={this.props.style}>
                    <div  className="inputForDropDown" onClick={this.getOpen.bind(this)}>{this.state.values?this.state.values:this.props.values[0].LanguageName}<img alt="" style={this.state.open?{'transform':'rotateX(180deg)'}:null}  className="relay" src={dropdown_Open}></img></div>
                    <div className={this.state.open ? "open" : "close"}>
                      <div className="color">
                      {dropDown}
                      </div>
                      <div className="mainMenu">
                        <div className="menu_dropdawn"><img src={add_color} alt="" className="firstNameImgDropdown"/><img src={edit} alt=""/><img src={delete_color} alt=""/></div>
                      </div>
                    </div>
                </div>
              </Col>
            </Row>)}}

export default Dropdown;
