import React, { Component } from 'react';
import { Row, Col} from 'react-bootstrap'
import { graphql, compose, Mutation, Comment, Query } from 'react-apollo';
import {objectIntoDropdownArray} from '../../../../../storeFunctions.js'

import CustomerCRMNotes from '../../../../../../functions/query/customer/allCustomerCRMNotes.js'
import KundenGruppe from '../../../../../../functions/query/customer/allKundenGruppe.js'
import Languages from '../../../../../../functions/query/customer/allLanguages.js'
import CustomerAddressKinds from '../../../../../../functions/query/customer/allCustomerAddressKinds.js'
import AllCustomerInfo from '../../../../../../functions/query/customer/allCustomerInfo.js'

import updateCustomer from '../../../../../../functions/mutation/customer/updateCustomer.js'



import Text from '../../../../../../components/simple/Text'
import Inputttt from '../../../../../../components/simple/Input'


import Dropdown from '../../../../../../@appElements/dropDown/Dropdown'
import SimpleDropdown from '../../../../../../@appElements/dropDown/SimpleDropdown'
import DropdownLanguage from './DropdownLanguage'
import Title from '../../../../../../@appElements/title/Title.js';
import Input from '../../../../../../@appElements/input/Input.js';
import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';

import {Mutations} from '../../../../../../@appElements/functions/Mutation.js';

import deleteKundenGruppe from '../../../../../../functions/mutation/customer/deleteDropDownKundenGruppe.js'
import addDropDownKundenGruppe from '../../../../../../functions/mutation/customer/addDropDownKundenGruppe.js'
import updeteDropDownKundenGruppe from '../../../../../../functions/mutation/customer/updeteDropDownKundenGruppe.js'

class Adresse extends React.Component {
    state = {
      salutationCustomer: '',
      nameCustomer: '',
      additiveCustomer: '',
      roadCustomer: '',
      zipCode: '',
      place: '',
      email: '',
      postOfficeBox: '',
      changeNm: 0,
      telefonG2: '',
      telefonG: '',
      telefonP: '',
      fax: '',
      internet: '',
      contactPerson: '',
      isActivated: false,
      customerIntern: '',
      LinkGruppe: 0,
      allKundenGruppeDropdown:[],
      OtherEMailAddresses:'',
      UseAnotherLngDescriptions: false,
      Natel: "",
      list: []


    }
  
    
  getValueOfInput = (event) => {

    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})
  }





  deleteDropDownKundenGruppe = async (index) => {
  await  this.props.deleteKundenGruppe({
      variables: { Intern: this.props.KundenGruppe.allKundenGruppe[index].Intern},
      refetchQueries: [ { query: KundenGruppe, variables: {LinkCustomer: this.props.intern} }]
    })
  }

  updeteDropDownKundenGruppe = async (Gruppe, index) => {
  await  this.props.updeteDropDownKundenGruppe({
      variables: {
        Intern: this.props.KundenGruppe.allKundenGruppe[index].Intern,
        Gruppe: Gruppe
      },
      refetchQueries: [ { query: KundenGruppe, variables: {LinkCustomer: this.props.intern} }]
    })
  }

  addDropDownKundenGruppe = async (Gruppe) => {

  await  this.props.addDropDownKundenGruppe({
      variables: { Gruppe: Gruppe},
      refetchQueries: [ { query: KundenGruppe, variables: {LinkCustomer: this.props.intern} }]
    })

    
  }

   updateCustomer=(e)=>{
    const key = e.target.name;
    const value = this.state[key];
    Mutations(
      {[key]: value},
      this.props.updateCustomer, 
      "id",
      this.props.intern
      );
  }
   updateCustomerCheckbox=(e)=>{
    Mutations(
      {isActivated: !this.state.isActivated},
      this.props.updateCustomer, 
      "id",
      this.props.intern
      );
    this.setState({isActivated: !this.state.isActivated})
  }

  updateCustomerCheckbox1=(e)=>{
    Mutations(
      {UseAnotherLngDescriptions: !this.state.UseAnotherLngDescriptions},
      this.props.updateCustomer, 
      "id",
      this.props.intern
      );
    
    this.setState({UseAnotherLngDescriptions: !this.state.UseAnotherLngDescriptions})
  }

  updateDropGruppe=(LinkGruppe)=>{
    Mutations(
      {LinkGruppe: LinkGruppe? LinkGruppe:this.state.LinkGruppe},
      this.props.updateCustomer, 
      "id",
      this.props.intern
      );
    
  }

  onCompleted = (props)=>{
    console.log(props)
    let data=props.allCustomerInfo[0];
    this.setState({
      customerIntern: data.id,
      changeNm: data.changeNm,
      salutationCustomer: data.salutationCustomer,
      nameCustomer: data.nameCustomer,
      additiveCustomer: data.additiveCustomer,
      roadCustomer: data.roadCustomer,
      zipCode: data.zipCode,
      place: data.place,
      email: data.email,
      postOfficeBox: data.postOfficeBox,
      isActivated: data.isActivated,
      fax: data.fax,
      internet: data.internet,
      contactPerson: data.contactPerson,
      telefonG: data.telefonG,
      telefonG2: data.telefonG2,
      telefonP: data.telefonP,
      LinkGruppe: data.LinkGruppe,
      OtherEMailAddresses: data.OtherEMailAddresses,
      UseAnotherLngDescriptions: data.UseAnotherLngDescriptions,
      Natel: data.Natel,
      list: data
    })
  }






  render() {
      return (
      <Query 
        fetchPolicy={"network-only"}
        query={AllCustomerInfo}
        onCompleted={this.onCompleted}
        variables={{id: this.props.intern }}> 
          {({ loading, error, data }) => {
            if (error) return <div>Error</div>

       return (
      	<Row style={{padding: "0 15px 0 15px"}}>
          <Col lg={12} onClick={ ()=>{console.log(data)}}> <Title  text={this.state.nameCustomer}/> 
          </Col>
          <Col lg={4}>
            <Row onClick={this.a}>
                <Input 
                  text={'Customer No.'}  
                  value={this.state.changeNm} 
                  type="number" 
                  name="changeNm" 
                  onBlur={this.updateCustomer.bind(this)} 
                  onChange={this.getValueOfInput}/>
            </Row>
            <Row>

      <Query 
        query={KundenGruppe}> 
          {({ loading, error, data }) => {
            if (loading) return <div>Fetching</div>
            if (error) return <div>Error</div>
              return(
                <Dropdown
                  row = {"Gruppe"}
                  text = "Group" 
                  style = {{zIndex: 12}} 
                  list = {data.allKundenGruppe} 
                  onBlur = {this.updateDropGruppe}
                  gruppeId = {this.state.LinkGruppe} 
                  deleteDropDown = {this.deleteDropDownKundenGruppe} 
                  addDropDown = {this.addDropDownKundenGruppe} 
                  updeteDrop = {this.updeteDropDownKundenGruppe.bind(this)}/>)}}
                </Query>
            </Row>
            <Row>
                <Title text="Address"/>
            </Row>
            <Row>

               <Text text="value" color="red" fontSize ="20px" fontWeight ={200}/>
               <Inputttt value/>
            </Row>
             <Row>
                <Input 
                  text="Title"
                  type="text"
                  value={this.state.salutationCustomer}
                  onBlur={this.updateCustomer}  
                  name="salutationCustomer"
                  onChange={this.getValueOfInput}/>
            </Row>
            <Row>
                <Input 
                  text="Name"
                  type="text" 
                  value={this.state.nameCustomer} 
                  name="nameCustomer" 
                  onBlur={this.a} 
                  onChange={this.getValueOfInput}/>
            </Row>
            <Row>
                <Input
                  text="Addition " type="text" 
                  value={this.state.additiveCustomer} 
                  name="additiveCustomer" 
                  onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
            </Row>
            <Row>
                <Input 
                  text="Street" 
                  type="text" 
                  value={this.state.roadCustomer} 
                  name="roadCustomer" 
                  onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
            </Row>
            <Row>
                <Input 
                  text="Post office box" 
                  type="text" 
                  value={this.state.postOfficeBox} 
                  name="postOfficeBox" 
                  onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
            </Row>
            <Row>
              <Col lg={5}>
                <Input 
                  text="Zip code/Town" 
                  type="text" 
                  value={this.state.zipCode} 
                  name="zipCode" 
                  onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
              </Col>
              <Col lg={5} lgOffset={2}>
                <Input 
                  text="Land" 
                  type="text" 
                  value={this.state.place} 
                  name="place"  
                  onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
              </Col>
            </Row>
            <Row>
                <Input 
                  text="Internal Name" 
                  type="text" 
                  value={this.state.nameCustomer} 
                  name="nameCustomer" 
                  onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
            </Row>
          </Col>
          <Col lgOffset={2} lg={4}>
            <Row>
              <Col lg={12} style={{margin: "38px 0px 5px 12px"}}>
                <Col lg={6}  onClick={this.updateCustomerCheckbox}>
                  <div> 
                    <CheckBox 
                    top="0px"
                      open={this.state.isActivated}
                      value="Customer is aktive"/>  
                  </div> 
                </Col>
                <Col lg={6} onClick={this.updateCustomerCheckbox1}>
                  <div> 
                    <CheckBox
                    top="0px"
                      value={'Weitere Sprache Fur'} 
                      open={this.state.UseAnotherLngDescriptions}/>  
                  </div> 
                </Col>
              </Col>
            </Row>
            <Row>
              {/*<Col lg={12}>
                              <p>Correspondence language</p>
                               <DropdownLanguage 
                                style={{zIndex: 8}} 
                                gruppeId={this.state.gruppeid} 
                                values={this.props.Languages.allLanguages} 
                                list={this.props.Languages.allLanguages}/>
                            </Col>*/}
            </Row>
            <Row>
                <Title text="Phone"/>
            </Row>
            <Row>
                <Input 
                  text="Phone business" 
                  type="text" 
                  value={this.state.telefonG} 
                  name="telefonG" 
                  onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
            </Row>
            <Row>
                <Input 
                  text="Phone business II" 
                  type="text" 
                  value={this.state.telefonG2} 
                  name="telefonG2" 
                  onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
            </Row>
            <Row>
                <Input 
                  text="Phone Private" 
                  type="text" 
                  value={this.state.telefonP} 
                  name="telefonG2" 
                  onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
            </Row>
            <Row>
                <Input 
                  text="Fax" 
                  type="text" 
                  value={this.state.fax} 
                  name="fax" onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
            </Row>
            <Row>
                <Input
                  text="Mobile" 
                  type="text" 
                  value={this.state.Natel} 
                  name="Natel" 
                  onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
            </Row>
            <Row>
                <Input 
                  text="E-mail" 
                  type="text" 
                  value={this.state.email} 
                  name="adresseMail" 
                  onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
            </Row>
            <Row>
                <Input 
                  text="Other E-mail Addresses"  
                  type="text" 
                  value={this.state.OtherEMailAddresses} 
                  name="OtherEMailAddresses" 
                  onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
            </Row>
            <Row>
                <Input 
                  text="Internet" 
                  type="text" 
                  value={this.state.internet} 
                  name="internet" 
                  onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
            </Row>
            <Row>
                <Input 
                  text="Contact person" 
                  type="text" 
                  value={this.state.contactPerson} 
                  name="contactPerson" 
                  onBlur={this.updateCustomer} 
                  onChange={this.getValueOfInput}/>
            </Row>
          </Col>
          <Col lg="2">
          </Col>
        </Row>
        )
      }}
      </Query>
      );
  }
}

const graph = compose(
  graphql(CustomerCRMNotes, {name: "CustomerCRMNotes"}),
  graphql(deleteKundenGruppe, {name:"deleteKundenGruppe"}),
  graphql(addDropDownKundenGruppe, {name:"addDropDownKundenGruppe"}),
  graphql(updeteDropDownKundenGruppe, {name:"updeteDropDownKundenGruppe"}),
  graphql(KundenGruppe, {
    options: (props) => ({
      fetchPolicy: 'network-only'
    }),
    name: "KundenGruppe" }),
  graphql(Languages, { name: "Languages" }),
  graphql(CustomerAddressKinds, {name: "CustomerAddressKinds"}),
  graphql(updateCustomer, {name:"updateCustomer"}),
)(Adresse);

export default graph;
