import React, { Component } from 'react';
import {  Row, Col, Grid} from 'react-bootstrap';
import './Barery2bcom.css';

import Dropdown from '../../../../../../@appElements/dropDown/Dropdown'

class Barery2bcom extends Component {
  render() {
    return (  
      	<Row>
	        <Col lg={5} className='customer_bakery2bcom'>
            <span> Bakery2b.com Kontent </span>
            <Dropdown style={{zIndex: 9}} values={[1,2,3]} list={[1,2,3]} gruppeid={1} linkName="Bakery" className="customer_bakery2bcom_dropdown"/>
            <button> Einladungen senden</button> 
          </Col>

          <Col lg={7}>
          </Col>
      	</Row>     
    );
  }
}

export default Barery2bcom;
