import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';
import styled from 'styled-components'
import { Query, Mutation } from 'react-apollo';

import Input from '../../../components/joint/Input'

import Data from '../../../functions/query/product/CashAssist'
import Dropdown from '../../../components/simple/dropdown/Dropdown'

const countryOptions = [
	{ key: '1', value: '1', flag: '1', text: 'Current month' },
	{ key: '2', value: '2', flag: '2', text: 'Date tange' },
	{ key: '3', value: '3', flag: '3', text: 'Invoice numbers range' },
	{ key: '4', value: '4', flag: '4', text: 'Customer' }
]

class CashAssist extends Component {
  state = {
      keys: ['id', 'concatenatedField'],
  }

  handleChange = (e, { value }) => this.setState({value});

  onCompleted = (data) => {
    try {
      let schablone = data.getProductCashAssistShablone[0].concatenatedField;
      let salesGroup = data.getProductCashAssistSalesGroup[0].concatenatedField;
      let visibility = data.getProductCashAssistVisibility[0].concatenatedField;
      this.setState({
        schablone,
        salesGroup,
        visibility
      });
    } catch(err) {
      console.log(err);
    }

    try {
      let listSchablone = data.listProductCashAssistShablone;
      let listSalesGroup = data.listProductCashAssistSalesGroup;
      let listVisibility = data.listProductCashAssistVisibility;
      this.setState({
        listSchablone,
        listSalesGroup,
        listVisibility
      })
    } catch(err) {
      console.log(err);
    }
    console.log(this.state);
  };

  activeId = (id) => console.log(id);

  render() {
    const { schablone, salesGroup, visibility, listSchablone, listSalesGroup, listVisibility, keys} = this.state;
    console.log(this.state);
    return (
      <Query
        query = {Data}
        variables = {{
            idSc: 27,
            idSG: 27,
            idV: 1
        }}
        fetchPolicy = 'network-only'
        onCompleted = {this.onCompleted}
        errorPolicy = "all"
        onError = {() => console.log('ups..error in product/CashAssist')}
        displayName = {"CashAssist"}>
        {({error, data, networkStatus, refetch}) => {
        if (networkStatus === 4) return "Refetching";
        if (error) return (
            <div>Error: <button onClick={() => window.location.reload()}>Please Refetch</button></div>
        )
            return(
            <Body>
              <Block>
                <Dropdown
                    list={listSchablone}
                    defaultValue={schablone}
                    activeId={this.activeId}
                    title='Schablone'
                    nameKey={keys}
                    id={'1'}/>
                  <Dropdown
                      list={listSalesGroup}
                      defaultValue={salesGroup}
                      activeId={this.activeId}
                      title='Schablone'
                      nameKey={keys}
                      id={'1'}/>
                  <Dropdown
                      list={listVisibility}
                      defaultValue={visibility}
                      activeId={this.activeId}
                      title='Schablone'
                      nameKey={keys}
                      id={'1'}/>
                </Block>
            </Body>
          )
        }}
      </Query>
    )
  }
}

export default CashAssist;

const Block = styled.div`
  width: 300px;
`;
//
// const StyleDropdown = styled(Dropdown)`
// 	margin-top: 40px;
// `;

const Body = styled.div`
  padding: 40px 0 0 20px;
  min-width: 1090px;
  min-height: 840px;
  background-color: #f5f5f5;
  box-shadow: 0 6px 4px -4px rgba(90, 90, 90, .2);
`;
