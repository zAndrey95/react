import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';
import PropTypes from 'prop-types'
import styled from 'styled-components'
import { Query, Mutation } from 'react-apollo';

import Input from '../../../components/joint/Input'
import Checkbox from '../../../components/simple/Checkbox'

import Data from '../../../functions/query/product/Fracture'

class Fracture extends Component {
  state = {}

  onCompleted = (data) => {
    console.log(data);
    try {
      let fracture = data.getProductFracture[0].concatenatedField;
      let useParts = data.ProductAddInfo[0].breakUsedParts;
      let isBreakTitle = data.ProductAddInfo[0].isBreakTitle;
      this.setState({
        fracture,
        useParts,
        isBreakTitle
      })
		}
		catch(error){
			console.log(error);
		}
	}
  render() {
    const { fracture, useParts, isBreakTitle } = this.state;
    console.log(this.state);
    return (
      <Query
        query = {Data}
        variables = {{id:this.props.id}}
        fetchPolicy = 'network-only'
        onCompleted = {this.onCompleted}
        errorPolicy = "all"
        pollInterval = {30000}
        onError = {() => console.log('ups..error in product/sprache')}
        displayName = {"Sprache"}>
        {({loading, error, networkStatus, data}) => {
        if (networkStatus === 4) return "Refetching...";
        if (error) return `ErrorQuery: ${error}`;
        if (loading) return "loading";
        return (
            <Body>
              <Input text="Fracture" value={fracture} width="300px" />
              <Input text="Verwendete Teile des Bruchs Fur Dliesen Artikle" value={useParts} width="300px" />
              <Checkbox value="Bruch-Artikel" open={isBreakTitle} marginBottom={"17px"}/>
            </Body>
          )
        }}
      </Query>
    )
  }
}

export default Fracture;

const Body = styled.div`
  padding: 20px;
  min-width: 1090px;
  min-height: 840px;
  background-color: #f5f5f5;
  box-shadow: 0 6px 4px -4px rgba(90, 90, 90, .2);
`;
