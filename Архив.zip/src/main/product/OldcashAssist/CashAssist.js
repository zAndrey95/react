import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { graphql, compose, Query, Mutation } from 'react-apollo';

import Items from '../components/index.js'
import {DataCashAssist, MutationCashAssist} from './Query.js'

class CashAssist extends Component {
	constructor() {
    super();
    this.state = {
			listItems: [],
			isOpenModal: false,
			idActiveModal: 0,
			listShablon: {id: '', values: ''},
			listSichtbarkeit: {id: '', values: ''},
			listUmsatzgruppe: {id: '', values: ''},
    }
  }

	onCompleted = (data) => {
		let list = data;
		let intern = data.allProduct_Artikel[0];
		let listShablon = data.allArtikleCashAssistSchablonList;
		let listSichtbarkeit = data.allArtikleCashAssistSichtbarkeitList;
		let listUmsatzgruppe = data.allArtikleCashAssistUnssatzgruppeList;
		this.setState({
			idSich: intern.CAVisibilityStatusID,
			idUn: intern.Umsatzgruppe,
			idSch: intern.LinkCashAssistSchablone,
		})

		try {
			this.setState({
				listShablon: {id: 1, values: listShablon},
				listSichtbarkeit: {id: 2, values: listSichtbarkeit},
				listUmsatzgruppe: {id: 3, values: listUmsatzgruppe}
			})
		} catch (e) {
			this.setState({
				listShablon: {id: 1, values: []},
				listSichtbarkeit: {id: 2, values: []},
				listUmsatzgruppe: {id: 3, values: []}
			})
		}

		try {
			let sichtbarkeit = data.allArtikleCashAssistActiveSichtbarkeitElement[0].ConcatenatedField;
			this.setState({valueSichtbarkeit: sichtbarkeit})
		} catch (e) {
			this.setState({valueSichtbarkeit: ''})
		}

		try {
			let shablon = data.allArtikleCashAssistActiveSchablonElement[0].ConcatenatedField;
			this.setState({valueShablon: shablon})
		} catch (e) {
			this.setState({valueShablon: ''})
		}

		try {
			let umsatzgruppe = data.allArtikleCashAssistActiveUnssatzgruppeElement[0].ConcatenatedField;
			this.setState({valueUmsatzgruppe: umsatzgruppe})
		} catch (e) {
			this.setState({valueUmsatzgruppe: ''})
		}
	}

	openModal = (id) => {
		this.setState({
			isOpenModal: !this.state.isOpenModal,
			idActiveModal: id
		})
	}

	changeActiveName = (methode, name, stateName, idActive, nameActive) => {
		let nameUpdate = name;
		let stateNameUpdate = stateName;
		console.log(stateNameUpdate);
		console.log(nameUpdate);
    this.setState({
			[stateNameUpdate]: nameActive
    })
		methode({
			variables: {
				id: this.props.intern,
				[nameUpdate]: idActive
			}
		})
	}

	render() {
		return (
			<Query
				query = {DataCashAssist}
				variables = {{
					id: this.props.intern,
					idSich: this.state.idSich,
					idUn: this.state.idUn,
					idSch: this.state.idSch
				}}
				fetchPolicy = 'network-only'
	      onCompleted = {this.onCompleted}
	      errorPolicy = "all"
	      onError = {() => console.log('ups..error in product/CashAssist')}
	      displayName = {"CashAssist"}>
				{({error, data, networkStatus, refetch}) => {
					if (networkStatus === 4) return "Refetching";
					if (error) return (
						<div>Error: <button onClick={() => window.location.reload()}>Please Refetch</button></div>
					)
					return(
						<Mutation mutation={MutationCashAssist}>
							{update => (
								<Row style={{padding: "10px 15px 0 15px"}}>
									<Row>
							          <Col lg={4}>
													<Items
														isOpen={this.state.isOpenModal}
														onClickCLoseModal={() => this.openModal(1)}
														onClickOpenModal = {() => this.openModal(1)}
														onRequestClose={() => this.openModal(1)}
														titleName={"Shablon"}
														idActiveModal={this.state.idActiveModal}
														idOpen={this.state.listShablon.id}
														listItems={this.state.listShablon.values}
														activeValue={this.state.valueShablon}
														changeActiveName={this.changeActiveName.bind(this, update, 'LinkCashAssistSchablone', 'valueShablon')}
														/>
							            </Col>
							        </Row>
							        <Row>
							        	<Col lg={4}>
													<Items
														isOpen={this.state.isOpenModal}
														onClickCLoseModal={() => this.openModal(2)}
														onClickOpenModal = {() => this.openModal(2)}
														onRequestClose={() => this.openModal(2)}
														titleName={"Sichtbarkeit"}
														idActiveModal={this.state.idActiveModal}
														idOpen={this.state.listSichtbarkeit.id}
														listItems={this.state.listSichtbarkeit.values}
														activeValue={this.state.valueSichtbarkeit}
														changeActiveName={this.changeActiveName.bind(this, update, 'CAVisibilityStatusID', 'valueSichtbarkeit')}
														/>
							          	</Col>
							        </Row>
							        <Row>
							        	<Col lg={4}>
													<Items
														isOpen={this.state.isOpenModal}
														onClickCLoseModal={() => this.openModal(3)}
														onClickOpenModal = {() => this.openModal(3)}
														onRequestClose={() => this.openModal(3)}
														titleName={"Umsatzgruppe"}
														idActiveModal={this.state.idActiveModal}
														idOpen={this.state.listUmsatzgruppe.id}
														listItems={this.state.listUmsatzgruppe.values}
														activeValue={this.state.valueUmsatzgruppe}
														changeActiveName={this.changeActiveName.bind(this, update, 'Umsatzgruppe', 'valueUmsatzgruppe')}
														/>
							          </Col>
							        </Row>
					        	</Row>
							)}
						</Mutation>

					)
				}}
			</Query>

			)
		}
	}

export default CashAssist;
