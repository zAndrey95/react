import gql from 'graphql-tag';

export const DataCashAssist = gql`
  query allData($id: Int, $idSich: Int, $idUn: Int, $idSch: Int){

    allProduct_Artikel(id: $id){
      id
      LinkCashAssistSchablone
      Umsatzgruppe
      CAVisibilityStatusID
    }

    allArtikleCashAssistSichtbarkeitList {
      Intern
      ConcatenatedField
    }

    allArtikleCashAssistActiveSichtbarkeitElement(Intern: $idSich) {
      Intern
      ConcatenatedField
    }

    allArtikleCashAssistUnssatzgruppeList {
      Intern
      ConcatenatedField
    }

    allArtikleCashAssistActiveUnssatzgruppeElement(Intern: $idUn) {
      Intern
      ConcatenatedField
    }

    allArtikleCashAssistSchablonList {
      Intern
      ConcatenatedField
    }

    allArtikleCashAssistActiveSchablonElement(Intern: $idSch) {
      Intern
      ConcatenatedField
    }
  }
`;

export const MutationCashAssist = gql`
  mutation updateProduct_Artikel(
    $id: Int!,
    $LinkCashAssistSchablone: Int,
    $Umsatzgruppe: Int,
    $CAVisibilityStatusID: Int
  )
  {
    updateProduct_Artikel(
      id: $id,
      LinkCashAssistSchablone: $LinkCashAssistSchablone,
      Umsatzgruppe: $Umsatzgruppe,
      CAVisibilityStatusID: $CAVisibilityStatusID
    )
    {
      id
      LinkCashAssistSchablone
      Umsatzgruppe
      CAVisibilityStatusID
    }
  }
`;
