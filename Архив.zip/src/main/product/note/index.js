import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';
import PropTypes from 'prop-types'
import styled from 'styled-components'
import ReactQuill from 'react-quill';
import { Query, Mutation } from 'react-apollo';

import 'react-quill/dist/quill.snow.css';
import './style.css';


import Data from '../../../functions/query/product/Note'

const CustomToolbar = () => (
  <div id="toolbar">
    <select className="ql-header" defaultValue={""} onChange={e => e.persist()}>
      <option value="1" />
      <option value="2" />
      <option selected />
    </select>
    <button className="ql-bold" />
    <button className="ql-italic" />
    <select className="ql-color">
      <option value="red" />
      <option value="green" />
      <option value="blue" />
      <option value="orange" />
      <option value="violet" />
      <option value="#d0d1d2" />
      <option selected />
    </select>
  </div>
);

class Note extends Component {
  state = {}

  onCompleted = (data) => {
    console.log(data);
    try {
      let note = data.ProductAddInfo[0].note;
      this.setState({
        note
      })
		}
		catch(error){
			console.log(error);
		}
	}

  render() {
    const { note } = this.state;
    return (
      <Query
        query = {Data}
        variables = {{id:this.props.id}}
        fetchPolicy = 'network-only'
        onCompleted = {this.onCompleted}
        errorPolicy = "all"
        pollInterval = {30000}
        onError = {() => console.log('ups..error in product/sprache')}
        displayName = {"Sprache"}>
        {({loading, error, networkStatus, data}) => {
        if (networkStatus === 4) return "Refetching...";
        if (error) return `ErrorQuery: ${error}`;
        if (loading) return "loading";
        return (
            <Body>
              <BlockEditor
                theme={this.state.theme}
                onChange={this.handleChange}
                value={note}
                modules={Note.modules}
                formats={Note.formats}
                bounds={'.app'}
                placeholder={this.props.placeholder}
               />
            </Body>
          )
        }}
      </Query>
    )
  }
}

export default Note;

const Body = styled.div`
  min-width: 1090px;
  min-height: 840px;
  background-color: #f5f5f5;
  box-shadow: 0 6px 4px -4px rgba(90, 90, 90, .2);
  padding-left: 20px;
padding-top: 60px;
`;

const BlockEditor = styled(ReactQuill)`
  height: 375px;
  width: 800px;
  background-color: white;
`;
