import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { graphql, compose } from 'react-apollo';

import Textarea from '../../../../../../@appElements/textarea/Textarea.js';

import AllProductBemerkung from '../../../../../../functions/query/product/allProductBemerkung.js'
import updateProductBemerkung from '../../../../../../functions/mutation/product/updateProductBemerkung.js'

class Bemerkng extends Component {
	constructor() {
	    super();
	    this.state = {
			Intern: '',
			Memo: '',
	    }
  	}

	static getDerivedStateFromProps(nextProps, prevState) {
		if(!nextProps.AllProductBemerkung.loading){
			const  store = nextProps.AllProductBemerkung.allProductBemerkung[0];
			return {
				Intern: store.Intern,
				Memo: store.memo,
			}
		return null
	 	}
	return null
	}

	updateProductBemerkung = () => {
		this.props.updateProductBemerkung({
			variables: {
				Intern: this.props.idProduct,
				memo: this.state.Memo,
			},
			options: {
				fetchPolicy: 'network-only'
			}
		})
	}

	getValueOfInput = (event) => {
		let eventname= event.target.name;
	    this.setState({[eventname]: event.target.value})
	}

	render() {
		return (
			<Row style={{padding: "10px 15px 0 15px"}}>
				<Col lg={6}> 
					<Textarea 
            			text="Note" 
            			width='80%'
            			value={this.state.Memo}
            			onBlur={this.updateProductBemerkung}
            			name="Memo"
            			onChange={this.getValueOfInput}
            			style={{margin: '30px 0px 0px 0px'}}
          			/>
				</Col>
			</Row>
		)
	}
}

const graph = compose(
  graphql(AllProductBemerkung, {
        options: (props) => ({
            fetchPolicy: 'network-only',
            variables: {
              id: props.idProduct,
            }
        }),
        name: "AllProductBemerkung",
	}),
	graphql(updateProductBemerkung, {name: "updateProductBemerkung"}),
	)(Bemerkng);

export default graph;
