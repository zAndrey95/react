import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';
import PropTypes from 'prop-types'
import styled from 'styled-components'

import Checkbox from '../../../components/simple/Checkbox'
import Text from '../../../components/simple/Text'
import Button from '../../../components/simple/Button'
import Line from '../../../components/simple/Line'

class List extends Component {
  render() {
    return (
      <Body>
        <Text text="Assortement" color="#2e3941" fontSize="24px" fontWeight="700" marginBottom='15px'/>
        <Line />
        <Text text="Assortement groups" color="#2e3941" fontSize="18px" fontWeight="700" marginBottom='20px'/>
        <RowStyle>
          <Col lg={3}>
            <Checkbox value="All" open={true}/>
            <Checkbox value="Gruppe" open={false}/>
          </Col>
          <Col lg={3}>
            <Checkbox value="GrossKunde" open={true}/>
            <Checkbox value="BBS" open={false}/>
          </Col>
          <Col lg={3}>
            <Checkbox value="002.Engros Kunde" open={true}/>
            <Checkbox value="BBS" open={false}/>
          </Col>
        </RowStyle>
        <Text text="Availability" color="#2e3941" fontSize="24px" fontWeight="700" marginBottom='15px'/>
        <Line />
        <Text text="Jeden Montag, Dienstag, Donnerstag " color="#2e3941" fontSize="16px" fontWeight="700" marginBottom='20px' />
        <BtnStyle value={"LISTENNAME"} width={"250px"} />
      </Body>
    )
  }
}

export default List;

const Body = styled.div`
  padding: 20px;
  min-width: 1090px;
  min-height: 840px;
  background-color: #f5f5f5;
  box-shadow: 0 6px 4px -4px rgba(90, 90, 90, .2);
  margin-top: 40px;
`;

const RowStyle = styled(Row)`
  margin-bottom: 20px;
`;

const BtnStyle = styled(Button)`
  margin-top: 20px;
`;
