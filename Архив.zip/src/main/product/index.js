import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';
import { Query } from 'react-apollo'
import { Route, Switch } from 'react-router-dom';
import PropTypes from 'prop-types'
import styled from 'styled-components'

import Routes from '../Routes'
import Items from '../../components/container/items/Items'
import Menu from '../../components/container/Menu'

import Article from './article/index'
import Note from './note/index'
import List from './list/index'
import Availability from './availability/index'
import Production from './production/index'
import Sprache from './sprache/index'
import CashAssist from './cashAssist/index'
import Fracture from './fracture/index'
import Post from './post/index'
import Label from './label/index'

import {ListItem} from '../../functions/query/product/Article'

class Description extends Component {
  state = {
  };

  onCompleted = (data) => {
    let info = data.listProduct;
    console.log(info);
    this.setState({info})
  };

  changeSearch = () => {
  };

  changeLimit = () => {
    const add = this.state.limit + 10;
    this.setState({limit: add});
  };

  onChangeItem = (id) => {
    this.setState({
      id: this.state.info[id].id
    });
  };

  getRouterLink = () =>{
    let pathnameArray = [];
    let correct = [];
    let router = '';
    pathnameArray = this.props.location.pathname.toString().split('/');
    correct = pathnameArray.splice(1,2);
    router = pathnameArray.join('/');
    return router;
  };

  render() {
    const {id} = this.state;
    console.log(id);
    const menuObj = [
      {
        name: 'Article',
        link: '/products/article',
        col: '1'
      },
      {
        name: 'Description',
        link: '/products/description',
        col: '2'
      },
      {
        name: 'List',
        link: '/products/list',
        col: '1'
      },
      {
        name: 'Availability',
        link: '/products/availability',
        col: '2'
      },
      {
        name: 'Production',
        link: '/products/production',
        col: '1'
      },
      {
        name: 'CashAssist',
        link: '/products/cashAssist',
        col: '1'
      },
      {
        name: 'Label',
        link: '/products/label',
        col: '1'
      },
      {
        name: 'Sprache',
        link: '/products/sprache',
        col: '1'
      },
      {
        name: 'Post',
        link: '/products/post',
        col: '1'
      },
      {
        name: 'Fracture',
        link: '/products/fracture',
        col: '1'
      },
    ];

    return (
      <div>
        <Row>
          <Col lg={3}>
            <Query
                query={ListItem}
                fetchPolicy='cache-and-network'
                onCompleted={this.onCompleted}
                errorPolicy='all'
                onError={() => console.log('ups')}>
            {({loading, error, networkStatus, data}) => {
              if (networkStatus === 4) return "Refetching...";
              if (error) return `ErrorQuery: ${error}`;
              if (loading) return "loading";
              let info = [];
              data.listProduct.forEach((i) => {
                info.push([i.productId, i.name])
              });
              return (
                <Items
                  name="Article"
                  names={['Id', 'Name']}
                  widths = {['25%', '75%']}
                  float= {["left", "left"]}
                  align="left"
                  arr={info}
                  getSearchValue={this.changeSearch}
                  searchValue=''
                  filterBtn = {true}
                  isfilterButton = {true}
                  firstBtnName = "ADD CUSTOMER"
                  secondBtnName = "DELETE CUSTOMER"
                  onClick = {this.onChangeItem}
                  />
                )
              }}
            </Query>
          </Col>
          <Col lg={9}>
            <Body>
              <Menu menuObj={menuObj} text='001 Article' isAddition={false}/>
              <Switch>
                <Route path={'/products/article'}>
                  <Article id={id}/>
                </Route>
                <Route path={"/products/description"}>
                  <Note id={id}/>
                </Route>
                <Route path={"/products/list"}>
                  <List id={id}/>
                </Route>
                <Route path={"/products/availability"}>
                  <Availability id={id}/>
                </Route>
                <Route path={"/products/production"}>
                  <Production id={id}/>
                </Route>
                <Route path={"/products/sprache"}>
                  <Sprache id={id}/>
                </Route>
                <Route path={"/products/cashAssist"}>
                  <CashAssist id={id}/>
                </Route>
                <Route path={"/products/fracture"}>
                  <Fracture id={id}/>
                </Route>
                <Route path={"/products/post"}>
                  <Post id={id}/>
                </Route>
                <Route path={"/products/label"}>
                  <Label id={id}/>
                </Route>
              </Switch>
            </Body>
          </Col>
        </Row>
      </div>
    )
  }
}

export default Description;

const Body = styled.div`
  margin-left: 20px;
`;
