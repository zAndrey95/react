import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import {  Col } from 'react-bootstrap';
import styled from 'styled-components';
import ItemModal from './ItemModal.js'

class Index extends Component {
  constructor(props) {
     super(props);
     this.state = {
       name: props.activeValue,
       id: '',
       search: ''
     }
   }

    changeElement = (changeName, changeId) =>{
      this.setState({
        name: changeName,
        id: changeId
      })
    }


  render() {
    return (
          <Col lg={12}>
            {
            this.props.idOpen === this.props.idActiveModal?
            <ItemModal
              isOpen={this.props.isOpen}
              onAfterOpen={this.props.afterOpenModal}
              onRequestClose={this.props.onRequestClose}
              onClickCLoseModal={this.props.onClickCLoseModal}
              changeElement={this.changeElement}
              listItems={this.props.listItems}
              activeValue={this.state.name}
              onClickSave={this.props.changeActiveName.bind(this, this.state.id, this.state.name)}
              isSearch = {this.props.completedSearch}

              onClickAdd={this.props.onClickAdd}
              onClickDel={this.props.onClickDel}
              onChange={this.props.onChange}
              onBlur={this.props.onBlur}
              listName={this.props.listName}
              /> :
              ''
            }
            <h4>{this.props.titleName}</h4>
            <ChangeModal onClick={this.props.onClickOpenModal}>{this.props.activeValue}<Icon>&rsaquo;</Icon></ChangeModal>
          </Col>
      )
  }
}

export default Index;

const Icon = styled.div`
  float: right;
  font-weight: bold;
  font-size: 180%;
  margin-top: -5px;
  transform: rotate(90deg);
`;

const ChangeModal = styled.button`
  width: 100%;
  height: 30px;
  border-radius: 6px;
  background-color: #ffffff;
  border: 1px solid #ffffff;
  float: right;
  box-shadow: 0 2px 2px 0 rgba(0,0,0,0.1);
`;

const TestDelete = styled.span`
  width: 15px;
  height: 15px;
  background-color: #ffffff;
  float: right;
  &:hover{
    cursor: pointer;
  }
`;
