'use strict';
import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import Modal from 'react-modal';
import styled from 'styled-components';

import cancel_black from '../../../../../../img/cancel_black.svg';
import add_color from '../../../../../../img/add_color.svg';
import delete_color from '../../../../../../img/delete_color.svg';

import Input from'../../../../../../@appElements/input/Input.js'
import Title from'../../../../../../@appElements/title/Title.js'
import Button from'../../../../../../@appElements/button/Button.js'

import {ModalWindow, ModalBody, ModalHead, HeadTitle, IconCancel, ModalButton, ModalText} from '../articel/component/tables/ModalInfoPreiskategorienNew.js'

import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';

const customStyles = {
  content : {
    top                   : '50%',
    left                  : '50%',
    right                 : 'auto',
    bottom                : 'auto',
    marginRight           : '-50%',
    transform             : 'translate(-50%, -50%)',
    width                 : '549px',
    padding               : '0',
    overflow              : 'hidden',
    background            : '#f5f5f5'

  }
};

// Make sure to bind modal to your appElement (http://reactcommunity.org/react-modal/accessibility/)
Modal.setAppElement('#root')

class ItemModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      listItems: ''
    }
  }

  componentWillReceiveProps(nextProps){
   this.setState({listItems: nextProps.listItems});
  }

  componentDidMount(){
    this.setState({listItems: this.props.listItems});
  }
  render() {
    const array = this.props.listItems || [];
    const listArray = array.map((item, index) => {
      return (
        <StyledColItem key={item.Intern} onClick={this.props.changeElement.bind(this, item.ConcatenatedField, item.Intern)}>
            <Item>{item.ConcatenatedField}</Item>
        </StyledColItem>
      );
    });
      return (
        <StyledCol>
           <Modal
             isOpen={this.props.isOpen}
             onAfterOpen={this.props.onAfterOpen}
             onRequestClose={this.props.onRequestClose}
             style={customStyles}
             contentLabel="Example Modal">

             <ModalWindow>

               <ModalHead>
                 <HeadTitle>
                   Listennamen
                 </HeadTitle>
                 <IconCancel onClick={this.props.onClickCLoseModal} src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACsSURBVEhL7ZVRDoMwDEO7O+5SILRx4m6xZKNqsJKUfPIkVNVtnvtHuQlRa33aN3MbBrNwcLvHDqePYeuLkRvMcLb/wOaiuyQ8ExkIy4VncFgueoLLcnEkSpOLVpguFxKDdDn4KXgzzkFyrJCnlrRyRsi2ElsejOMcycXlkp4cQDpcciYXkDYlK/Y8+o9XLiCl/LzELsy86JILSJuShfEeOxz+4bBkgYPRjYdSvtX7jKmE+SdnAAAAAElFTkSuQmCC"/>
               </ModalHead>

               <ModalBody>
                 <StyledRow lg={12}>
                 <StyledCol lg={6}>

                   <BodyList>
                     <ListName><Text>Name</Text></ListName>
                     <ListSearch>
                       <InputSearch type="text" placeholder="Search" onChange={this.props.isSearch}/>
                     </ListSearch>
                     <ItemsTable>{listArray}</ItemsTable>
                    </BodyList>
                 </StyledCol>
                 

                 <StyledCol lg={6}>
                   <ListName style={{'margin-left': '50px', width: '200px'}}><Text>Active</Text></ListName>
                     <InputName
                       value={this.props.activeValue}
                       onChange={this.props.onChange}
                       name='listName'
                       onBlur={this.props.onBlur}/>

                   </StyledCol>
                 </StyledRow>
                 <StyledRow lg={12}>
                 <ModalButton marginTop="9px" width="250px" marginLeft="0px" onClick={this.props.onClickSave}>Save</ModalButton>
                  <ModalButton marginTop="9px" width="200px" marginLeft="15px" backgroundButton="#2e3941" onClick={this.props.onClickCLoseModal}>Close</ModalButton>
                </StyledRow>
               </ModalBody>

             </ModalWindow>


          </Modal>

        </StyledCol>
      );
    }
  }

export default ItemModal;
//new styled


const Item = styled.div`
  min-height: 36px;
  font-family: HelveticaNeue;
  font-size: 18px;
  font-weight: 300;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #3c445a;
  padding-left: 14px !important;
  padding-top: 8px;
  background-color: #ffffff;
  box-shadow: 0 1px 0 0 rgba(76, 76, 76, 0.08);
`;

const rando = btoa(Math.random())
const StyledColItem = styled(Col)`
  padding-left: 12px !important;
  background-color: #cdcdcd;
  box-shadow: 0 1px 0 0 rgba(76, 76, 76, 0.08);
  &:hover {
    background-color: #99d5d7 !important;
  }
  &:focus {
    background-color: #99d5d7 !important;
  }
  &:visited {
    background-color: #99d5d7 !important;
  }
  &:active {
    background-color: #99d5d7 !important;
  }
  &:focus-within {
    background-color: #99d5d7 !important;
  }
`;

const Text = styled.span`
  width: 55px;
  height: 16px;
  font-family: Roboto;
  font-size: 14px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #ffffff;
`;

const BodyList = styled.div`
  width: 290px;
`;

const ListName = styled.div`
  width: 250px;
  height: 36px;
  border-radius: 3px;
  background-color: #99d5d7;
  padding: 10px 0 10px 10px;
`;

const ListSearch = styled.div`
  width: 250px;
  height: 41px;
  background-color: #efefef;
`;

const InputSearch = styled.input`
  font-family: Roboto;
  font-size: 14px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #afafaf;
  width: 100%;
  height: 30px;
  margin-top: 2px;
  border: none;
  background-color: #efefef;
  &:focus{
    color: #3c4671;
    font-size: 18px;
  }
`;

//style
const StyledCol = styled(Col)`
`;
const StyledRow = styled(Row)`
`;
const StyledRowTable = styled(Row)`
  border: solid 1px #d2d2d2;
  border-radius:  6px 6px 0 0;
  padding: 5px 0px 5px 0px;
`;
const StyledRowTableBody = styled(Row)`
  border: solid 1px #d2d2d2;
  padding: 5px 0px 0px 5px !important;
  height: 410px;
`;
const TitleModal = styled.span`
  font-family: HelveticaNeue;
  font-size: 18px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #000000;
  border-bottom: 1px solid #d2d2d2;
  margin-left: 20px;
`;
const Name = styled(TitleModal)`
  font-size: 14px;
  border-bottom: none;
`;
const NameTable = styled.div`
  font-family: HelveticaNeue;
  font-size: 18px;
  font-weight: 400px;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #818181;
`;
const ItemsTable = styled.div`
  height: 380px;
  width: 250px;
  overflow-y: scroll;
`;
const Hr = styled.div`
  border-bottom: solid 1px #d2d2d2;
  padding-bottom: 4px;
  margin-bottom: 6px;
`;
const Img = styled.img`
  height: 18px;
  width: 18px;
  margin-left: 30px;
`;
const ImgBtn = styled(Img)`
  margin-left: -8px;
  margin-top: -9px;
  width: 26px;
  height: 19px;
`;
const InputName = styled.input`
  height: 26px;
  border-radius: 4px;
  border: 1px solid #d2d2d2;
  font-size: 18px;
  font-weight: 300;
  color: #4a4a4a;
  margin-top: 10px;
  margin-left: 50px;
`;
const ButtonCancle = styled.div`
  padding-top: 330px;
  text-align: center;
  font-family: HelveticaNeue;
  font-size: 16px;
  font-weight: 300;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #7ed321;
`;
const BtnClick = styled.button`
  padding-top: 6px;
  width: 145px;
  height: 30px;
  border-radius: 6px;
  border: solid 1px #7ed321;
`;
