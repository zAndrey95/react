import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';
import PropTypes from 'prop-types'
import styled from 'styled-components'

import Checkbox from '../../../components/simple/Checkbox'
import Text from '../../../components/simple/Text'
import Button from '../../../components/simple/Button'

class List extends Component {
  render() {
    return (
      <Body>
        <Text text="Listenname" color="#2e3941" fontSize="18px" fontWeight="700" marginBottom='20px'/>
        <Row>
          <Col lg={3}>
            <Checkbox value="002.Engros Kunde" open={true}/>
            <Checkbox value="BBS" open={false}/>
          </Col>
          <Col lg={3}>
            <Checkbox value="002.Engros Kunde" open={true}/>
            <Checkbox value="BBS" open={false}/>
          </Col>
          <Col lg={3}>
            <Checkbox value="002.Engros Kunde" open={true}/>
            <Checkbox value="BBS" open={false}/>
          </Col>
        </Row>
        <BtnStyle value={"LISTENNAME"} width={"250px"} />
      </Body>
    )
  }
}

export default List;

const Body = styled.div`
  padding: 20px;
  min-width: 1090px;
  min-height: 840px;
  background-color: #f5f5f5;
  box-shadow: 0 6px 4px -4px rgba(90, 90, 90, .2);
  margin-top: 40px;
`;

const BtnStyle = styled(Button)`
  margin-top: 20px;
`;
