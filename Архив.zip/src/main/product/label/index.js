import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';
import PropTypes from 'prop-types'
import styled from 'styled-components'
import { Route, Switch } from 'react-router-dom';
import { Query, Mutation } from 'react-apollo';

import Input from '../../../components/joint/Input'
import Text from '../../../components/simple/Text'
import Line from '../../../components/simple/Line'
import Checkbox from '../../../components/simple/Checkbox'
import Button from '../../../components/simple/Button'
import Images from '../../../components/container/image/Image'
import Textarea from '../../../components/simple/Textarea'

import keks from '../article/Keks.jpg'

import Data from '../../../functions/query/product/Label'

class Label extends Component {
  state = {}

  onCompleted = (data) => {
    console.log(data);
    try {
      let info = data.getProductLabel[0];
      this.setState({
        label: info.label,
        EANNo: info.EANNo,
        isEANmanagedByCA: info.isEANmanagedByCA,
        linkLabelRecipe: info.linkLabelRecipe,
        declaration: info.declaration,
        forSaleDays: info. forSaleDays,
        salesWeight: info.salesWeight,
        toConsumeDays: info.toConsumeDays,
        shelfLifeDayes: info.shelfLifeDayes,
        mustBeKeptCool: info.mustBeKeptCool,
        storage: info.storage,
        storageCustomerText: info.storageCustomerText
      })
    } catch(err) {

    }
  }
  render() {
    const {
      label,
      EANNo,
      isEANmanagedByCA,
      linkLabelRecipe,
      declaration,
      forSaleDays,
      salesWeight,
      toConsumeDays,
      shelfLifeDayes,
      mustBeKeptCool,
      storage,
      storageCustomerText
    } = this.state;
    return (
      <Query
        query = {Data}
        variables = {{id:this.props.id}}
        fetchPolicy = 'network-only'
        onCompleted = {this.onCompleted}
        errorPolicy = "all"
        pollInterval = {30000}
        onError = {() => console.log('ups..error in product/label')}
        displayName = {"Label"}>
        {({loading, error, networkStatus, data}) => {
        if (networkStatus === 4) return "Refetching...";
        if (error) return `ErrorQuery: ${error}`;
        if (loading) return "loading";
          return (
            <Body>
              <Row>
                <Col>
                  <Text text="Etikettierung" color="#2e3941" fontSize="18px" fontWeight="500" marginBottom='15px' marginTop='30px'/>
                  <Input text="Alternative Bezeichnung auf Etikett" value={label} width="300px" />
                </Col>
              </Row>
              <Line/>
              <Row>
                <Col lg={4}>
                  <Text text="Ean" color="#2e3941" fontSize="18px" fontWeight="500" marginBottom='15px'/>
                  <Input text="EAN-Code" value={EANNo} width="300px" />
                  <Checkbox value="EAN-cod wird im CashAssist verwaltet" open={isEANmanagedByCA} marginBottom={"17px"}/>
                  <BtnStyle value={'CREATE'} width={'180px'} />
                </Col>
                <Col lg={4}>
                  <Images value="Images" srcImage={keks}/>
                </Col>
              </Row>
              <Line/>
              <Text text="Deklararon" color="#2e3941" fontSize="18px" fontWeight="500" marginBottom='15px' />
              <Row>
                <Col lg={4}>
                  <Input text="Verknupfung mit Rezapt Assist" value={linkLabelRecipe} width="300px" />
                  <Col lg={6}><Input text="Zu verkaife bis" value={forSaleDays} width="140px" /></Col>
                  <Col lg={6}><Input text="Verkaufsgewicht" value="read-only" width="140px" /></Col>
                </Col>
                <Col lg={4}>
                  <Input text="Deklaration" value={declaration} width="300px" />
                  <Col lg={6}><Input text="Alternatives (g)" value={salesWeight} width="140px" /></Col>
                  <Col lg={6}><Input text="Haltbarkeit" value="" width="140px" /></Col>
                </Col>
                <Col lg={4}>
                  <Input text="Lagerung" value={storage} width="300px" />
                </Col>
              </Row>
              <Line/>
              <Row>
                <Col lg={6}>
                  <Text text="Which of articles are use this article" color="#2e3941" fontSize="18px" fontWeight="500" marginBottom='15px'/>
                  <div><Textarea /></div>
                </Col>
                <Col lg={6}>
                  <Text text="Which of articles are use this article" color="#2e3941" fontSize="18px" fontWeight="500" marginBottom='15px'/>
                  <div><Textarea /></div>
                </Col>
              </Row>
            </Body>
          )
        }}
      </Query>
    )
  }
}

export default Label;

const Body = styled.div`
  margin-top: 30px;
  padding: 20px;
  min-width: 1090px;
  min-height: 840px;
  background-color: #f5f5f5;
  box-shadow: 0 6px 4px -4px rgba(90, 90, 90, .2);
`;

const BtnStyle = styled(Button)`
  margin-top: 170px;
`;
