import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';
import PropTypes from 'prop-types'
import styled from 'styled-components'

import Table from '../../../components/container/table/Table'
import Button from '../../../components/simple/Button'
import ModalPriceCategories from './ModalPriceCategories'

class BlockTable extends Component {
  render() {
    const {
      arr,
      widths,
      names,
      getSearchValue,
      align,
      value,
      width
    } = this.props;
    return (
      <div>
        <Table arr={arr} widths={widths} names={names} getSearchValue={getSearchValue} align={align}/>
        <BtnStyle value={value} width={width} />
        <ModalPriceCategories />
      </div>
    )
  }
}

BlockTable.propTypes = {
  arr: PropTypes.array,
  widths: PropTypes.array,
  names: PropTypes.array,
  getSearchValue: PropTypes.bool,
  align: PropTypes.string,
  value: PropTypes.string,
  width: PropTypes.string
}

export default BlockTable;

const BtnStyle = styled(Button)`
  margin-top: 100px;
`;
