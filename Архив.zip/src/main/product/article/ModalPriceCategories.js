import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';
import PropTypes from 'prop-types'
import styled from 'styled-components'

import Table from '../../../components/container/table/Table'
import Button from '../../../components/simple/Button'

class ModalPriceCategories extends Component {
  state = {
    open: true
  }
  render() {
    const {
      arr,
      widths,
      names,
      getSearchValue,
      align,
      value,
      width
    } = this.props;
    return (
      <Modal open={this.state.open}>
        text
      </Modal>
    )
  }
}

ModalPriceCategories.propTypes = {
  arr: PropTypes.array,
  widths: PropTypes.array,
  names: PropTypes.array,
  getSearchValue: PropTypes.bool,
  align: PropTypes.string,
  value: PropTypes.string,
  width: PropTypes.string
}

export default ModalPriceCategories;

const Modal = styled.div`
  display: ${props => props.open ? 'block' : 'none'};
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  background-color: #ffffff;
  opacity: 0.6;
  text-align: center;
`;
