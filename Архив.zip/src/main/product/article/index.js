import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';
import { Query } from 'react-apollo'
import { Route, Switch } from 'react-router-dom';
import PropTypes from 'prop-types';
import styled from 'styled-components';
import { withRouter } from 'react-router'

import Input from '../../../components/joint/Input';
import Images from '../../../components/container/image/Image';
import Line from '../../../components/simple/Line';
import Checkbox from '../../../components/simple/Checkbox';
import Menu from '../../../components/container/Menu';
import BlockTable from './BlockTable';
import Loader from '../../../components/simple/loader/Loader';
import Dropdown from '../../../components/simple/dropdown/Dropdown'

import {Data, Group} from '../../../functions/query/product/Article'

import Keks from './Keks.jpg';

const menuObj = [
  {
    name: 'Price categories',
    link: '/products/article/categoriesPrice',
    col: '4'
  },
  {
    name: 'Customer price',
    link: '/products/article/customerPrice',
    col: '4'
  },
  {
    name: 'Resseler price',
    link: '/products/article/resselerPrice',
    col: '4'
  }
];

const arrCategories = [
  {
    Von: '10.05.2018',
    Bis: '11.05.2018',
    Checkbox: 'true',
    Tage: 'Mn',
    Decription: 'Text'
  },
  {
    Von: '11.02.2019',
    Bis: '12.02.2019',
    Checkbox: 'false',
    Tage: 'Fr',
    Decription: 'Second text'
  }
]

const arrNamesCategories = ['Von', 'Bis', 'Checked', 'Tage', 'Description'];

const arrWidthsCategories = ['15%', '15%', '12%', '18%', '40%'];

const arrReseller = [
  {
    KundenNm: '001',
    Name: 'Name Vasya',
    Preis: '21p',
    Bemerkung: 'bemerkung'
  },
  {
    KundenNm: '001',
    Name: 'Name Vasya',
    Preis: '21p',
    Bemerkung: 'bemerkung'
  }
];

const arrNamesResseler = ['Kunden-Nr', 'Name', 'Preis', 'Bemerkung'];

const arrWidthsResseler = ['15%', '50%', '15%', '20%'];

const arrCustomer = [
  {
    Von: '10.02.1999',
    Bis: '12.08.2100',
    KundenNm: '2900',
    Name: 'Petr',
    Preis: '2000',
    AdMenge: '0',
    Rabbat: '0',
    Netto: '201',
    Bemerkung: '21sdaadasd21',
  },
  {
    Von: '10.02.1999',
    Bis: '12.08.2100',
    KundenNm: '2900',
    Name: 'Petr',
    Preis: '2000',
    AdMenge: '0',
    Rabbat: '0',
    Netto: '201',
    Bemerkung: '21sdaadasd21',
  },
];

const arrNamesCustomer = ['Von', 'Bis', 'Kunden-Nr', 'Name', 'Preis', 'AdMenge', 'Rabbat', 'Netto', 'Bemerkung'];

const arrWidthsCustomer = ['11%', '11%', '11%', '13%', '8%', '10%', '10%', '10%', '16%']

class Article extends Component {
  static propTypes = {
    location: PropTypes.object.isRequired,
  };
  state = {
    active: false,
    keys: ['id', 'designation']
  };

  onCompleted = (data) => {
    console.log(data);
    try {
      let info = data.getProductArticle[0];
      this.setState({
        ...info
      });
      console.log(info);
    } catch (e) {
      console.log(e);
    }

    try {
      let activeName = data.getProductArticleGroupActive[0].designation;
      let activeName2 = data.getProductArticleGroupActive[0].designation;
      let activeName3 = data.getProductArticleGroupActive[0].designation;

      {this.state.linkGroup === null ? this.setState({activeName:''}) : this.setState({activeName});}
      {this.state.linkGroup2 === null ? this.setState({activeName2:''}) : this.setState({activeName2});}
      {this.state.linkGroup3 === null ? this.setState({activeName3:''}) : this.setState({activeName3});}
      console.log(activeName);
      console.log(data.getProductArticleGroup2Active);
      console.log(data.getProductArticleGroup3Active);
    } catch (e) {
      console.log(e);
    }
  };

  activeId = (id) => console.log(id);

  render() {

    const {
      articleNo,
      designation,
      isNet,
      isActivated,
      isTitle,
      linkGroup,
      linkGroup2,
      linkGroup3,
      amount1,
      amount2,
      amount3,
      amount4,
      amount5,
      keys,
      activeName,
      activeName2,
      activeName3
    } = this.state;
    const newArrCategories=[];
    arrCategories.forEach((item) => { newArrCategories.push([item.Von, item.Bis, item.Checkbox, item.Tage, item.Decription])});

    const newArrResseler = [];
    arrReseller.forEach((item) => { newArrResseler.push([item.KundenNm, item.Name, item.Preis, item.Bemerkung])});

    const newArrCustomer = [];
    arrCustomer.forEach((item) => { newArrCustomer.push([item.Von, item.Bis, item.KundenNm, item.Name, item.Preis, item.AdMenge, item.Rabbat, item.Netto, item.Bemerkung])})
    return (
      <Body>
      <Query
          query={Data}
          variables={{
            id: this.props.id,
            idActive: linkGroup || 0,
            idActive2: linkGroup2 || 0,
            idActive3: linkGroup3 || 0}}
          fetchPolicy='network-only'
          onCompleted={this.onCompleted}
          errorPolicy='all'
          onError={() => console.log('ups...error in query product/article')}
          displayName={'Product/Article'}>
        {({error, data, loading, networkStatus}) => {
        if (networkStatus === 4) return "Refetching";
        if (error) return (
            <div>Error: <button onClick={() => window.location.reload()}>Please click for refetching</button></div>
        );
        return (
            <Main>
              {loading && <Loader/>}
              <Row>
                <Col lg={4} >
                  <Input text="Article-Nm." value={articleNo} width="140px" />
                  <Input text="Description" value={designation} width="300px" />
                  <Row>
                    <Col lg={6}>
                      <Checkbox value="Article as title" open={isTitle}/>
                    </Col>
                    <Col lg={6}>
                      <Checkbox value="net Article" open={isNet}/>
                    </Col>
                    <Col lg={6}>
                      <Checkbox value="Article as active" open={isActivated}/>
                    </Col>
                  </Row>
                </Col>
                <Col lg={4}>
                  <Images value="Images" srcImage={Keks}/>
                </Col>
              </Row>
              <Line />
              <Query
                  query={Group}
                  fetchPolicy='network-only'
                  errorPolicy='all'
                  onError={() => console.log('ups...error in query product/article/group')}
                  displayName={'Product/Article'}>
                {({error, data, loading, networkStatus}) => {
                  if (networkStatus === 4) return "Refetching";
                  if (error) return (
                      <div>`Error:`<button onClick={() => window.location.reload()}>Please click for refetching</button></div>
                  );
                  return (
                    <Row>
                      {loading && <Loader/>}
                      <Col lg={4}>
                        <Dropdown
                            list={data.listProductArticleGroup}
                            defaultValue={activeName}
                            activeId={this.activeId}
                            title='WerenGruppe'
                            nameKey={keys}
                            id={'1'}
                        />
                      </Col>
                      <Col lg={4}>
                        <Dropdown
                            list={data.listProductArticleGroup2}
                            defaultValue={activeName2}
                            activeId={this.activeId}
                            title='ProduktionGruppe'
                            nameKey={keys}
                        />
                      </Col>
                      <Col lg={4}>
                        <Dropdown
                            list={data.listProductArticleGroup3}
                            defaultValue={activeName3}
                            activeId={this.activeId}
                            title='ProduktionGruppe'
                            nameKey={keys}
                        />
                      </Col>
                    </Row>
                      )
                }}
              </Query>
              <Row>
                <Col lg={2}>
                  <Input text="Load" value={amount1} width="140px" />
                </Col>
                <Col lg={2}>
                  <Input text="Deliver" value={amount2} width="140px" />
                </Col>
                <Col lg={2}>
                  <Input text="Gross" value={amount3} width="140px" />
                </Col>
                <Col lg={2}>
                  <Input text="Netto" value={amount4} width="140px" />
                </Col>
                <Col lg={2}>
                  <Input text="Im Haus" value={amount5} width="140px" />
                </Col>
              </Row>
            </Main>
        )
        }}
      </Query>

        <BlockMenu>
          <Menu menuObj={menuObj} isAddition={true}/>
        </BlockMenu>

        <Tables>
          <Switch>
            <Route path={"/products/article/categoriesPrice"}>
              <BlockTable arr={newArrCategories} widths={arrWidthsCategories} names={arrNamesCategories} getSearchValue={true} align={"left"} value={"CREATE"} width={"180px"}/>
            </Route>
            <Route path={"/products/article/customerPrice"}>
              <BlockTable arr={newArrResseler} widths={arrWidthsResseler} names={arrNamesResseler} getSearchValue={true} align={"left"} value={"CREATE"} width={"180px"}/>
            </Route>
            <Route path={"/products/article/resselerPrice"}>
              <BlockTable arr={newArrCustomer} widths={arrWidthsCustomer} names={arrNamesCustomer} getSearchValue={true} align={"left"} value={"CREAsTE"} width={"180px"}/>
            </Route>
          </Switch>
        </Tables>

      </Body>
    )
  }
}

Article.propTypes = {
  id: PropTypes.number
};

Article.defaultProps = {
  id: 1
};

export default withRouter(Article);

const Body = styled.div`
  min-width: 1090px;
`;

const Main = styled.div`
  background-color: #f5f5f5;
  box-shadow: 0 6px 4px -4px rgba(90, 90, 90, .2);
  padding: 0 20px 20px;
`;

const BlockMenu = styled.div`
  margin-top: 27px;
`;

const Tables = styled.div`
  margin-top: 64px;
  height: 335px;
  background-color: #f5f5f5;
  box-shadow: 0 6px 4px -4px rgba(90, 90, 90, .2);
  padding: 30px 20px 20px 20px;
`;
