import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { NavLink } from 'react-router-dom'
import {Route, Switch} from 'react-router-dom';
import { graphql, compose, Query } from 'react-apollo';
import styled from 'styled-components';

import ImgComponent from './component/ImgComponent.js'
import ListSale from './component/ListSale.js'
import LoadingComponent from './component/LoadingComponent.js'
import TablesArtikel from './component/tables/TablesArtikel.js'

import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';
import Dropdown from '../../../../../../@appElements/dropDown/Dropdown.js'
import HeaderTable from '../../../../../../@appElements/table/HeaderTable.js'
import Table from '../../../../../../@appElements/table/Table.js'
import Title from '../../../../../../@appElements/title/Title.js'
import Plus_green from '../../../../../../@appElements/item_Img/Plus_green.js'
import Minus_red from '../../../../../../@appElements/item_Img/Minus_red.js'
import Edit_blue from '../../../../../../@appElements/item_Img/Edit_blue.js'
import Icon_medical_on from '../../../../../../@appElements/item_Img/Icon_medical_on.js'
import Modal from '../../../../../../@appElements/modal/Modal.js'
import ModalInfoKundenpreise from './ModalInfoKundenpreise.js'
import ModalInfoPreiskategorien from './ModalInfoPreiskategorien.js'
import ModalInfoResellerPreise from './ModalInfoResellerPreise.js'
import Input from '../../../../../../@appElements/input/Input.js'

import {objectIntoDropdownArray} from '../../../../../storeFunctions.js'

import AllProduct_Artikel from '../../../../../../functions/query/product/allProduct_Artikel.js'
import AllProduct_Article_Price_Category from '../../../../../../functions/query/product/allProduct_Article_Price_Category.js'
import AllProduct_Artikel_Werengruppe from '../../../../../../functions/query/product/allProduct_Artikel_Werengruppe.js'
import AllProduct_Artikel_Gruppe from '../../../../../../functions/query/product/allProduct_Artikel_Gruppe.js'
import AllProduct_Artikel_Gruppe2 from '../../../../../../functions/query/product/allProduct_Artikel_Gruppe2.js'
import AllProduct_Artikel_Preikategorien from '../../../../../../functions/query/product/allProduct_Artikel_Preikategorien.js'
import AllProduct_Artikel_Kundenpreise from '../../../../../../functions/query/product/allProduct_Artikel_Kundenpreise.js'
import AllProduct_Artikel_ResellerPreise from '../../../../../../functions/query/product/allProduct_Artikel_ResellerPreise.js'
import updateProductArticle from '../../../../../../functions/mutation/product/updateProductArticle.js'
import GetProductImage from '../../../../../../functions/query/product/getProductImage.js'

import updateSubscProductArtikelPreikategorien from '../../../../../../functions/subscription/product/updateSubscProductArtikelPreikategorien.js'

import icon_download from '../../img/download.png'
import icon_download_copy from '../../img/going.png'
import icon_delete from '../../img/delete.png'
import icon_bread from '../../img/icon_bread.svg'
import add_color from '../../../../../../img/add_color.svg';
import edit from '../../../../../../img/edit.svg';
import delete_color from '../../../../../../img/delete_color.svg';

import './Articel.css';

class Articel extends Component {
	constructor() {
    super();
    this.state = {
		modalIsOpen: false,
		modalIsOpenEdit: false,
		modalIsOpenPlus: false,
		modalIsOpenName: "",
		test: '',
		status: '',
		//
		name: '',
		id: '',
		isTitel: false,
		isNetto: false,
		isActive: false,
		itemsNm: '',
		LinkGruppe: '',
		LinkGruppe2: '',
		LinkGruppe3: '',
		werengruppe: [],
		gruppe: [],
		gruppe2: [],
		amount1: '',
		amount2: '',
		amount3: '',
		amount4: '',
		amount5: '',
		amount6: '',
		amount7: '',
		amount8: '',
		amount9: '',
		amount10: '',
		articleImage: '',
		article_Price_Category1: '',
		article_Price_Category2: '',
		article_Price_Category3: '',
		article_Price_Category4: '',
		article_Price_Category5: '',
		article_Price_Category6: '',
		article_Price_Category7: '',
		article_Price_Category8: '',
		article_Price_Category9: '',
		article_Price_Category10: '',
		preikategorien: [],
		kundenpreise: [],
		kundenpreiseOneRow: [],
		resellerPreise: [],
		modalOneRow: [],
	};
  }

	static getDerivedStateFromProps(nextProps, prevState) {
		if(
	 		!nextProps.AllProduct_Artikel.loading &&
		 	!nextProps.AllProduct_Article_Price_Category.loading &&
			!nextProps.AllProduct_Artikel_Kundenpreise.loading &&
			!nextProps.AllProduct_Artikel_ResellerPreise.loading &&
			!nextProps.GetProductImage.loading){
				const  store = nextProps.AllProduct_Artikel.allProduct_Artikel[0];
				const  store1 = nextProps.AllProduct_Article_Price_Category.allProduct_Article_Price_Category[0];
				const 	store3 = nextProps.AllProduct_Artikel_Kundenpreise.allProduct_Artikel_Kundenpreise;
				const 	store4 = nextProps.AllProduct_Artikel_ResellerPreise.allProduct_Artikel_ResellerPreise;
				const  store5 = nextProps.GetProductImage.getProductImg ? nextProps.GetProductImage.getProductImg[0] : null;
				if(store !== prevState) {
					return {
					id: store.id,
					name: store.name,
					isTitel: store.isTitel,
					isNetto: store.isNetto,
					additiveCustomer: store.additiveCustomer,
					isActive: store.isActive,
					LinkGruppe: store.LinkGruppe,
					LinkGruppe2: store.LinkGruppe2,
					LinkGruppe3: store.LinkGruppe3,
					itemsNm: store.itemsNm,
					amount1: store.amount1,
					amount2: store.amount2,
					amount3: store.amount3,
					amount4: store.amount4,
					amount5: store.amount5,
					amount6: store.amount6,
					amount7: store.amount7,
					amount8: store.amount8,
					amount9: store.amount9,
					amount10: store.amount10,
					articleImage: store5 ? store5.img : null,
					article_Price_Category1: store1.Article_Price_Category1,
					article_Price_Category2: store1.Article_Price_Category2,
					article_Price_Category3: store1.Article_Price_Category3,
					article_Price_Category4: store1.Article_Price_Category4,
					article_Price_Category5: store1.Article_Price_Category5,
					article_Price_Category6: store1.Article_Price_Category6,
					article_Price_Category7: store1.Article_Price_Category7,
					article_Price_Category8: store1.Article_Price_Category8,
					article_Price_Category9: store1.Article_Price_Category9,
					article_Price_Category10: store1.Article_Price_Category10,
					kundenpreise: store3,
					resellerPreise: store4,
				}
			}
			return null
		}
		return null
	}

	updateProductArticle = (values) => {
	  const {updateProductArticle, idProduct} = this.props;
	  updateProductArticle({
	    variables: {
	      id: idProduct,
	      ...values
	    },
	    options: {
	      fetchPolicy: 'network-only'
	    }
	  })
	}

	updateProductArticleDropdown = (id) => {
	  const {updateProductArticle, idProduct} = this.props;
	  updateProductArticle({
	    variables: {
	      id: idProduct,
				LinkGruppe: id,
	    },
	    options: {
	      fetchPolicy: 'network-only'
	    }
	  })
	}

	changeValueOnCheckbox = (e) => {
	  const key = e.target.id;
	  const value = !this.state[key]
	  this.updateProductArticle({
	    [key]: value
	  })
	}

	getValueOfInput = (e) => {
		const key = e.target.name;
	  const value = e.target.value;
	  this.setState({[key]: value});
	}

	test = (e) => {
		this.setState({
			test: e.target.value
		})
	}

	getValueOfInputBlur = (e) => {
		const key = e.target.name;
	  const value = this.state[key];
		this.updateProductArticle({
	    [key]: value
	  })
	}

	componentDidMount = () => {
		// const werengruppe = objectIntoDropdownArray("AllProduct_Artikel_Werengruppe", "allProduct_Artikel_Werengruppe", "name", this.props);
		// const gruppe = objectIntoDropdownArray("AllProduct_Artikel_Gruppe", "allProduct_Artikel_Gruppe", "name", this.props);
		// const gruppe2 = objectIntoDropdownArray("AllProduct_Artikel_Gruppe2", "allProduct_Artikel_Gruppe2", "name", this.props);
		// this.setState({
		// 	werengruppe: werengruppe,
		// 	gruppe: gruppe,
		// 	gruppe2: gruppe2
		// })
	}

	indexOnClickTable = (name, status, index) => {
		const value = this.state[name][index];
		this.setState({
			status: true,
			modalIsOpen: true,
			modalOneRow: value,
			modalIsOpenEdit: true
		})
  }

// 	openModal = (status) => {
// 		console.log(status);
// 		if (status == "edit"){
// 			this.setState({
// 				modalIsOpenEdit: true
// 			})
// 		} else {
// 			this.setState({
// 				modalIsOpenPlus: true
// 			})
// 		}
// }

openModal = (status) => {
	this.setState({
		modalIsOpen: true,
		status: false
	})
}

	closeModal = () => {
    this.setState({
			modalIsOpen: false,
			modalIsOpenEdit: false,
			modalIsOpenPlus: false
		});
  }

	addNewValueDropDown = () => {

	}

  render() {

		console.log(this.state);
		console.log(this.props);

  	const arrayKundenpreise=[];
    this.state.kundenpreise.forEach((item)=>{
    	let fromDate = item.FromDate===null?'':item.FromDate.substring(0,10);
			let toDate = item.ToDate===null?'':item.ToDate.substring(0,10);
      arrayKundenpreise.push([toDate, fromDate, item.KundenNr, item.AktNameIntern, item.Price, item.FromAmount, item.Discount, <CheckBox open={item.DiscountsDisabled}/>, item.Description])
    })

    const arrayPreikategorien=[];
    this.state.preikategorien.forEach((item)=>{
    	let fromDate = item.FromDate===null?'':item.FromDate.substring(0,10);
			let toDate = item.ToDate===null?'':item.ToDate.substring(0,10);
      arrayPreikategorien.push([toDate, fromDate, item.Price1, item.Price2, item.Price3, item.Price4, item.Price5, item.Description])
    })

    const arrayResellerPreise=[];
    this.state.resellerPreise.forEach((item)=>{
      arrayResellerPreise.push([item.KundenNR, item.AktNameIntern,  item.Price, item.Description])
    })

		if(this.props.AllProduct_Artikel.loading || this.props.AllProduct_Artikel_Gruppe2.loading || this.props.AllProduct_Artikel_Gruppe.loading || this.props.AllProduct_Artikel_Werengruppe.loading || this.props.AllProduct_Article_Price_Category.loading || this.props.AllProduct_Artikel_ResellerPreise.loading  ||  this.props.AllProduct_Artikel_Kundenpreise.loading  || this.props.GetProductImage.loading ){ return <LoadingComponent/>}
		if(this.props.AllProduct_Artikel.error){ return <div> {this.props.AllProduct_Artikel.error}</div>}
		else{
    	return (
      <div>
				<StyledCol>
					<TitleProduct>{this.state.itemsNm}, {this.state.name}</TitleProduct>
				</StyledCol>
      	<div style={{padding: "0 0 0 15px"}}>
      		<Col lg={12}>
      			<Col lg={4}>
							<Input
								text="Artikel-Nr."
								value={this.state.itemsNm}
								name="itemsNm"
								onBlur={this.getValueOfInputBlur}
								onChange={this.getValueOfInput}
							/>
							<Input
									text="Bezeichnung"
									value={this.state.name}
									name="name"
									onChange={this.getValueOfInput}
									onBlur={this.getValueOfInputBlur}
								/>
		      		<Col lg={12}>
			      		<Col lg={6} onClick={this.changeValueOnCheckbox} >
			      			<CheckBox top="15px" value={'Artikel als Titel'} open={this.state.isTitel} id="isTitel"/>
			      		</Col>
			      		<Col lg={6} onClick={this.changeValueOnCheckbox} onBlur={this.updateProductArticle}>
			      			<CheckBox top="15px" value={'Nettoartikel'} open={this.state.isNetto} id="isNetto"/>
			      		</Col>
			      	</Col>
		      		<Col lg={12} onClick={this.changeValueOnCheckbox} onBlur={this.updateProductArticle}>
		      			<CheckBox top="10px" value={'Artikel ist Aktiv'} open={this.state.isActive} id="isActive" />
		      		</Col>
		      		<Dropdown
								text="Warengruppe"
								row={"name"}
								style={{zIndex: 3, width: '100%'}}
								list={this.props.AllProduct_Artikel_Werengruppe.allProduct_Artikel_Werengruppe}
								gruppeId={this.state.LinkGruppe}
								onBlur={this.updateProductArticleDropdown}
								deleteDropDown={this.isFunc=()=>{}}
								addDropDown={this.addNewValueDropDown}
								updeteDrop={this.isFunc=()=>{}}/>
		      		<Dropdown
								text="Produktionsgruppe"
								style={{zIndex: 2, width: '100%'}}
								list={this.props.AllProduct_Artikel_Gruppe.allProduct_Artikel_Gruppe}
								gruppeId={this.state.LinkGruppe2}
								onBlur={this.updateProductArticle}
								addDropDown={this.addNewValueDropDown}/>
		      		<Dropdown
								text="Marketing-Gruppe"
								style={{zIndex: 1, width: '100%'}}
								list={this.props.AllProduct_Artikel_Gruppe2.allProduct_Artikel_Gruppe2}
								gruppeId={this.state.LinkGruppe3}
								onBlur={this.updateProductArticle}
								deleteDropDown={this.isFunc=()=>{}}
								addDropDown={this.addNewValueDropDown}
								updeteDrop={this.isFunc=()=>{}}/>
	      		</Col>
	      		<Col lg={4} lgOffset={2}>
	      			<Title text="Bild"/>
							<ImgComponent idProduct={this.props.idProduct}/>

		      		<ListSale idProduct={this.props.idProduct}/>

	      		</Col>
	      		<Col lg={2}>
		      		<Col lg={10} lgOffset={2}>

						{this.state.article_Price_Category3 === null ? "" :
		      				<Input text={this.state.article_Price_Category3} value={this.state.amount3 === null ? "" : this.state.amount3} onBlur={this.getValueOfInputBlur}
									onChange={this.getValueOfInput}/>
						}

						{this.state.article_Price_Category6 === null ? "" :
							<Input text={this.state.article_Price_Category6} value={this.state.amount6 === null ? "" : this.state.amount6} onBlur={this.getValueOfInputBlur}
							onChange={this.getValueOfInput}/>
						}

						{this.state.article_Price_Category9 === null ? "" :
							<Input text={this.state.article_Price_Category9} value={this.state.amount9 === null ? "" : this.state.amount9} onBlur={this.getValueOfInputBlur}
							onChange={this.getValueOfInput}/>
						}

		      		</Col>
	      		</Col>
      		</Col>
      		</div>

      		<TablesArtikel
						id={this.state.id}
						idProduct={this.props.idProduct}
						/>

	   	</div>
    	);
  	}
	}
}

const graph = compose(
  graphql(AllProduct_Artikel, {
        options: (props) => ({
            fetchPolicy: 'network-only',
            variables: {
              id: props.idProduct,
            }
        }),
        name: "AllProduct_Artikel",
	}),


	graphql(AllProduct_Artikel_Kundenpreise, {
				options: (props) => ({
						fetchPolicy: 'network-only',
						variables: {
							id: props.idProduct,
						}
				}),
				name: "AllProduct_Artikel_Kundenpreise",
	}),
	graphql(AllProduct_Artikel_ResellerPreise, {
				options: (props) => ({
						fetchPolicy: 'network-only',
						variables: {
							id: props.idProduct,
						}
				}),
				name: "AllProduct_Artikel_ResellerPreise",
	}),
	graphql(GetProductImage, {
				options: (props) => ({
						fetchPolicy: 'network-only',
						variables: {
							id: props.idProduct,
						}
				}),
				name: "GetProductImage",
	}),
	graphql(AllProduct_Article_Price_Category, {name: "AllProduct_Article_Price_Category"}),
	graphql(AllProduct_Artikel_Werengruppe, {name: "AllProduct_Artikel_Werengruppe"}),
	graphql(AllProduct_Artikel_Gruppe, {name: "AllProduct_Artikel_Gruppe"}),
	graphql(AllProduct_Artikel_Gruppe2, {name: "AllProduct_Artikel_Gruppe2"}),
	graphql(updateProductArticle, {name: "updateProductArticle"}),
	)(Articel);

export default graph;

export const StyledCol = styled(Col)`
	border-bottom: 1px solid #ffffff;
	margin: 11px 11px 0 9px;
	padding-bottom: 19px;
`;

export const TitleProduct = styled.span`
	width: 302px;
  height: 28px;
  font-family: HelveticaNeue;
  font-size: 24px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #060606;
`;

export const ButtonAddElement = styled.button`
  width: 57px;
  height: 17px;
  font-family: Helvetica;
  font-size: 14px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #ffffff;
  width: 220px;
  height: 41px;
  border-radius: 4px;
  background-color: #99d5d7;
  margin: 17px 0;
  text-transform: uppercase;
`;
