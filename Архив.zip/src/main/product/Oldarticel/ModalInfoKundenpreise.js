import React, { Component } from 'react';
import { graphql, compose } from 'react-apollo';
import { withApollo } from 'react-apollo'
import { Col, Row } from 'react-bootstrap';
import styled from 'styled-components';
import PropTypes from 'prop-types';

import AllProduct_Artikel_Kundenpreise_Modal from '../../../../../../functions/query/product/allProduct_Artikel_Kundenpreise_Modal.js'
import updateProduct_Artikel_Kundenpreise from '../../../../../../functions/mutation/product/updateProduct_Artikel_Kundenpreise.js'
import addProduct_Artikel_Kundenpreise from '../../../../../../functions/mutation/product/addProduct_Artikel_Kundenpreise.js'

import Dropdown from '../../../../../../@appElements/dropDown/Dropdown.js';
import SimpleDropdown from '../../../../../../@appElements/dropDown/SimpleDropdown.js';
import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';
import Title from '../../../../../../@appElements/title/Title.js'
import Input from '../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../@appElements/textarea/Textarea.js'
import Button from '../../../../../../@appElements/button/Button.js'
import Calendar from '../../../../../../@appElements/calendar/Calendar.js'
import Text from '../../../../../../@appElements/text/Text.js'

import Cancel_black from '../../../../../../@appElements/item_Img/Cancel_black.js'
import Ok_green from '../../../../../../@appElements/item_Img/Ok_green.js'
import Cancel_red from '../../../../../../@appElements/item_Img/Cancel_red.js'

class ModalInfoKundenpreise extends Component {
  constructor(props) {
    super(props);
    this.state = {
    ...props.info,
    };
    this.getValueOfInput = this.getValueOfInput.bind(this);
  }

  changeValueOnCheckbox = (e) => {
	  const key = e.target.id;
	  const value = !this.state[key]
    console.log(key);
    console.log(value);
	  this.updateProduct_Artikel_Kundenpreise({
	    [key]: value
	  })
	}

  getValueOfInput = (e) => {
    const key = e.target.name;
	  const value = e.target.value;
	  this.setState({
      [key]: value
    });
  }

  getValueOfInputBlur = (e) => {
		const key = e.target.name;
	  const value = this.state[key];
		this.updateProduct_Artikel_Kundenpreise({
	    [key]: value
	  })
	}

  updateProduct_Artikel_Kundenpreise = (values) => {
	  const {updateProduct_Artikel_Kundenpreise, idLinkCustomer} = this.props;
  	  updateProduct_Artikel_Kundenpreise({
  	    variables: {
  	      Intern: this.state.Intern,
          LinkArticle: idLinkCustomer,
  	      ...values
  	    },
  	    options: {
  	      fetchPolicy: 'cache-first'
  	    }
  	  })
    }

    addProduct_Artikel_Kundenpreise = () => {
  	  const {addProduct_Artikel_Kundenpreise, idLinkCustomer} = this.props;
  	  addProduct_Artikel_Kundenpreise({
  	    variables: {
          LinkArticle: idLinkCustomer,
          Price: this.state.Price,
          FromAmount:this.state.FromAmount,
          Discount: this.state.Discount,
          DiscountsDisabled: this.state.DiscountsDisabled,
          Description: this.state.Description
  	    },
  	    options: {
  	      fetchPolicy: 'cache-first'
  	    }
  	  })
  	}

    changeIndexDropDawn = () => {

    }

  render() {
    console.log(this.state);

    if(this.props.AllProduct_Artikel_Kundenpreise_Modal.loading ){ return <div> Loading</div>}
		if(this.props.AllProduct_Artikel_Kundenpreise_Modal.error){ return <div> {this.props.AllProduct_Artikel_Kundenpreise_Modal.error}</div>}
		else{
    return (
      <div style={{zIndex: 4}}>
        <Row style={{padding: "10px 0 0 0"}}>
          <Col lg={5}>
            <Title
              top={"0px"}
              text="Kundenpreise"/>
          </Col>
          <Col lg={1} lgOffset={6}>
            <Cancel_black onClick={this.props.closeModal}/>
          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={4}>
            <Input
              text="Arn"
              value={this.props.idArtikel}/>
          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={5}>
            <Text text={"Von Datum"} height={"18px"} size={"16px"} color={"#6e6e6e"} marginTop={"20px"} top={"4px"} align={"left"}/>
            <Calendar getDate={this.state.ToDate || ""} colorText={"black"}/>
          </Col>

          <Col lg={5} lgOffset={2}>
            <Text text={"Bis Datum"} height={"18px"} size={"16px"} color={"#6e6e6e"} marginTop={"20px"} top={"4px"} align={"left"}/>
              <Calendar getDate={this.state.FromDate  || ""} colorText={"black"}/>
          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={12}>
            <Dropdown
              style={{zIndex: 1}}
              list={this.props.AllProduct_Artikel_Kundenpreise_Modal.allProduct_Artikel_Kundenpreise_Modal}
              text="Kunde"
              gruppeId={this.state.LinkCustomer - 2}
              row={"AktNmeIntern"}
              onBlur={this.changeIndexDropDawn}
            />

            <SimpleDropdown
              style={{zIndex: 1}}
                onBlur={this.changeIndexDropDawn}
                searchValue={this.props.searchValue}
                search={this.props.getValueOfInput}
                list={this.props.AllProduct_Artikel_Kundenpreise_Modal.allProduct_Artikel_Kundenpreise_Modal}
                text="Kunde"
                row={"AktNmeIntern"}
                next={this.more}
                gruppeId={this.state.LinkCustomer}
                />

          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={5}>
            <Input
              name="Price"
              text="Preis"
              value={this.state.Price || ""}
              onChange={this.getValueOfInput}
              onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}/>
          </Col>

          <Col lg={5} lgOffset={2}>
            <Input
              name="FromAmount"
              text="Ad Menge"
              value={this.state.FromAmount || ""}
              onChange={this.getValueOfInput}
              onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}/>
          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={5} >
            <Input
              name="Discount"
              text="Rabbat"
              value={this.state.Discount || ""}
              onChange={this.getValueOfInput}
              onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}/>
          </Col>

          <Col lg={5} lgOffset={2} style={{padding: "50px 0 0 0"}} onClick={this.changeValueOnCheckbox} onBlur={this.getValueOfInputBlur}>
            <CheckBox
              value="Nettoartikel"
              open={this.state.DiscountsDisabled || false}
              id="DiscountsDisabled"/>
          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={12}>
            <Textarea
              width="450px"
              name='Description'
              type="text"
              text="Note"
              value={this.state.Description || ""}
              onChange={this.getValueOfInput}
              onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}
              />
          </Col>
        </Row>

        <Col lg={12} style={{border: "1px solid #d2d2d2", margin: "10px 0 0 0"}} />

        <Row style={{padding: "0 0 10px 0"}}>
          <Col lg={4} lgOffset={1}  onClick={this.state.Intern == null ? this.addProduct_Artikel_Kundenpreise : this.props.closeModal}>
            <Button
              top={"11px"}
              width={"145px"}
              size={"16px"}
              height={"30px"}
              color={"#7ed321"}
              text={
                <div style={{padding: "5px 0 0 0"}}>
                  <Ok_green/>
                  <span lg={8} style={{padding: "3px 0 0 30px"}}>Save</span>
                </div>
            }/>
          </Col>

          <Col lg={4} lgOffset={2}  onClick={this.props.closeModal}>
            <Button
              top={"11px"}
              width={"145px"}
              size={"16px"}
              height={"30px"}
              color={"#9b9b9b"}
              text={
                <Row style={{padding: "5px 0 0 0"}}>
                  <Cancel_red/>
                  <span lg={8} style={{padding: "3px 0 0 20px"}}>Cancel</span>
                </Row>
            }/>
          </Col>
        </Row>

      </div>
    )
}
  }
}

const graph = compose(
	graphql(AllProduct_Artikel_Kundenpreise_Modal, {name: "AllProduct_Artikel_Kundenpreise_Modal"}),
  graphql(updateProduct_Artikel_Kundenpreise, {name: "updateProduct_Artikel_Kundenpreise"}),
  graphql(addProduct_Artikel_Kundenpreise, {name: "addProduct_Artikel_Kundenpreise"}),
	)(ModalInfoKundenpreise);

export default graph;
