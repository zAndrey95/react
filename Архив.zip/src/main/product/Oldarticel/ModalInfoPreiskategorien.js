import React, { Component } from 'react';
import { graphql, compose } from 'react-apollo';
import { withApollo } from 'react-apollo'
import { Col, Row } from 'react-bootstrap';
import styled from 'styled-components';

import Dropdown from '../../../../../../@appElements/dropDown/Dropdown.js';
import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';
import Title from '../../../../../../@appElements/title/Title.js'
import Input from '../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../@appElements/textarea/Textarea.js'
import Button from '../../../../../../@appElements/button/Button.js'
import Calendar from '../../../../../../@appElements/calendar/Calendar.js'
import Text from '../../../../../../@appElements/text/Text.js'

import Cancel_black from '../../../../../../@appElements/item_Img/Cancel_black.js'
import Ok_green from '../../../../../../@appElements/item_Img/Ok_green.js'
import Cancel_red from '../../../../../../@appElements/item_Img/Cancel_red.js'

import updateProduct_Artikel_Preikategorien from '../../../../../../functions/mutation/product/updateProduct_Artikel_Preikategorien.js'
import addProduct_Artikel_Preikategorien from '../../../../../../functions/mutation/product/addProduct_Artikel_Preikategorien.js'

class ModalInfoKundenpreise extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ...props.info,
    };
    this.getValueOfInput = this.getValueOfInput.bind(this);
  }

  getValueOfInput = (e) => {
    const key = e.target.name;
	  const value = e.target.value;
	  this.setState({
      [key]: value
    });
  }

  getValueOfInputBlur = (e) => {
		const key = e.target.name;
	  const value = this.state[key];
		this.updateProduct_Artikel_Preikategorien({
	    [key]: value
	  })
	}

  updateProduct_Artikel_Preikategorien = (values) => {
	  const {updateProduct_Artikel_Preikategorien, idLinkCustomer} = this.props;
  	  updateProduct_Artikel_Preikategorien({
  	    variables: {
  	      Intern: this.state.Intern,
          LinkArticle: idLinkCustomer,
  	      ...values
  	    },
  	    options: {
  	      fetchPolicy: 'cache-first'
  	    }
  	  })
    }

  addProduct_Artikel_Preikategorien = () => {
	  const {addProduct_Artikel_Preikategorien, idLinkCustomer} = this.props;
	  addProduct_Artikel_Preikategorien({
	    variables: {
        LinkArticle: idLinkCustomer,
        Description: this.state.Description,
        Price1: this.state.Price1,
        Price2: this.state.Price2,
        Price3:this.state.Price3,
        Price4: this.state.Price4,
        Price5: this.state.Price5,
        Price6: this.state.Price6
	    },
	    options: {
	      fetchPolicy: 'cache-first'
	    }
	  })
	}

  render() {
    return (
      <div>

        <HeaderTitle>
          <HeaderText>Preikategorien</HeaderText> <Cancel_black onClick={this.props.closeModal}/>
        </HeaderTitle>


        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={4}>
            <Text text={"Von Datum"} height={"18px"} size={"16px"} color={"#6e6e6e"} marginTop={"20px"} top={"4px"} align={"left"}/>
            <Calendar getDate={this.state.ToDate || ""} colorText={"black"}/>
          </Col>

          <Col lg={4} lgOffset={3}>
            <Text text={"Bis Datum"} height={"18px"} size={"16px"} color={"#6e6e6e"} marginTop={"20px"} top={"4px"} align={"left"}/>
          <Calendar getDate={this.state.FromDate || ""} colorText={"black"}/>
          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={5}>
            <Input
              text="Laden"
              name="Price1"
              value={this.state.Price1 || ""}
              onChange={this.getValueOfInput}
              onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}

              />
          </Col>

          <Col lg={5} lgOffset={2}>
            <Input
              text="Lieferung"
              name="Price2"
              value={this.state.Price2}
              onChange={this.getValueOfInput}
              onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}
              />
          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={5}>
            <Input
              text="Netto"
              name="Price3"
              value={this.state.Price3}
              onChange={this.getValueOfInput}
              onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}/>
          </Col>

          <Col lg={5} lgOffset={2}>
            <Input
              text="Im Haus"
              name="Price4"
              value={this.state.Price4}
              onChange={this.getValueOfInput}
              onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}/>
          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={5}>
            <Input
              text="Brutto"
              name="Price5"
              value={this.state.Price5}
              onChange={this.getValueOfInput}
              onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}/>
          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={12}>
            <Textarea
              width="450px"
              name='Description'
              type="text"
              text="Bemerkung"
              value={this.state.Description}
              onChange={this.getValueOfInput}
              onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}
              />
          </Col>
        </Row>

        <Col lg={12} style={{border: "1px solid #d2d2d2", margin: "10px 0 0 0"}} />

        <Row style={{padding: "0 0 10px 0"}}>
          <Col lg={4} lgOffset={1}  onClick={this.state.Intern == null ? this.addProduct_Artikel_Preikategorien : this.props.closeModal}>
            <Button
              top={"11px"}
              width={"145px"}
              size={"16px"}
              height={"30px"}
              color={"#7ed321"}
              text={
                <div style={{padding: "5px 0 0 0"}}>
                  <Ok_green/>
                  <span lg={8} style={{padding: "3px 0 0 30px"}}>Save</span>
                </div>
            }/>
          </Col>

          <Col lg={4} lgOffset={2}  onClick={this.props.closeModal}>
            <Button
              top={"11px"}
              width={"145px"}
              size={"16px"}
              height={"30px"}
              color={"#9b9b9b"}
              text={
                <Row style={{padding: "5px 0 0 0"}}>
                  <Cancel_red/>
                  <span lg={8} style={{padding: "3px 0 0 20px"}}>Cancel</span>
                </Row>
            }/>
          </Col>
        </Row>

      </div>
    )
  }
}

const graph = compose(
  graphql(updateProduct_Artikel_Preikategorien, {name: "updateProduct_Artikel_Preikategorien"}),
  graphql(addProduct_Artikel_Preikategorien, {name: "addProduct_Artikel_Preikategorien"}),
	)(ModalInfoKundenpreise);

export default graph;

const HeaderTitle = styled(Row)`
  width: 549px !important;
  height: 60px;
  border-radius: 3px;
  background-color: #2e3941;

`;

const HeaderText = styled.span`
  margin-top: 16px;
  margin-left: 20px;
  float: left;
  width: 167px;
  height: 28px;
  font-family: HelveticaNeue;
  font-size: 24px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #ffffff;
`;
