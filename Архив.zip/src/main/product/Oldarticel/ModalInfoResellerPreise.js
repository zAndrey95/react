import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import { Col, Row } from 'react-bootstrap';
import styled from 'styled-components';

import Dropdown from '../../../../../../@appElements/dropDown/Dropdown.js';
import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';
import Title from '../../../../../../@appElements/title/Title.js'
import Input from '../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../@appElements/textarea/Textarea.js'
import Button from '../../../../../../@appElements/button/Button.js'

import Cancel_black from '../../../../../../@appElements/item_Img/Cancel_black.js'
import Ok_green from '../../../../../../@appElements/item_Img/Ok_green.js'
import Cancel_red from '../../../../../../@appElements/item_Img/Cancel_red.js'

class ModalInfoKundenpreise extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ...props.info,
    };
    this.getValueOfInput = this.getValueOfInput.bind(this);
  }

  addModalInputsInArray(){
    //let ar = this.state.artikelArray;
    //Object.preventExtensions(ar);
    //ar.push(1);
  }

  getValueOfInput(event){
    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})
  }

  render() {
    console.log(this.state);
    console.log(this.props);
    return (
      <div>
        <Row style={{padding: "10px 0 0 0"}}>
          <Col lg={5}>
            <Title
              top={"0px"}
              text="Reseller Preise"/>
          </Col>
          <Col lg={1} lgOffset={6}>
            <Cancel_black onClick={this.props.closeModal}/>
          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={12}>
            <Dropdown
              style={{zIndex: 100}}
              list={["ss","ss"]}
              text="Art"
            />
          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={5}>
            <Input text="Brutto" value={this.state.Price}/>
          </Col>
        </Row>

        <Row style={{padding: "0 10px 0 10px"}}>
          <Col lg={12}>
            <Textarea
              width="450px"
              name='modalBemerkung'
              type="text"
              text="Bemerkung"
              value={this.state.AktNameIntern}
              />
          </Col>
        </Row>

        <Col lg={12} style={{border: "1px solid #d2d2d2", margin: "10px 0 0 0"}} />

        <Row style={{padding: "0 0 10px 0"}}>
          <Col lg={4} lgOffset={1}  onClick={this.props.closeModal}>
            <Button
              top={"11px"}
              width={"145px"}
              size={"16px"}
              height={"30px"}
              color={"#7ed321"}
              text={
                <div style={{padding: "5px 0 0 0"}}>
                  <Ok_green/>
                  <span lg={8} style={{padding: "3px 0 0 30px"}}>Save</span>
                </div>
            }/>
          </Col>

          <Col lg={4} lgOffset={2}  onClick={this.props.closeModal}>
            <Button
              top={"11px"}
              width={"145px"}
              size={"16px"}
              height={"30px"}
              color={"#9b9b9b"}
              text={
                <Row style={{padding: "5px 0 0 0"}}>
                  <Cancel_red/>
                  <span lg={8} style={{padding: "3px 0 0 20px"}}>Cancel</span>
                </Row>
            }/>
          </Col>
        </Row>

      </div>
    )
  }
}

export default ModalInfoKundenpreise;
