import React, { Component } from 'react';
import {Col} from 'react-bootstrap';
import {Query } from 'react-apollo';
import styled from 'styled-components';

import GetProductImage from '../../../../../../../functions/query/product/getProductImage.js'

import icon_download from '../../../img/download.png'
import icon_download_copy from '../../../img/going.png'
import icon_delete from '../../../img/delete.png'

export default class ImgComponent extends Component {

  saveBase64AsFile = (base64, fileName) => {
    var link = document.createElement("a");
    link.setAttribute("href", base64);
    link.setAttribute("download", fileName);
    link.click();
  }

  img = () => {
    var img = document.createElement('img');
    img.setAttribute('src', 'адрес_картинки');
    document.body.appendChild(img);
    console.log("add");
  }

  onFileSelected = (e) => {
    var selectedFile = e.target.files[0];
    console.log(selectedFile);
    var reader = new FileReader();
    reader.onload = function(e) {
      var imgtag = e.target.result;
      console.log(imgtag);
    };
    var res = reader.readAsDataURL(selectedFile);
    console.log(res);

    var myBlob = new Blob();
    function blobToFile(theBlob, selectedFile){
    //A Blob() is almost a File() - it just missing the two properties below which we will add
    theBlob.lastModifiedDate = new Date();
    theBlob.name = selectedFile;
    console.log(theBlob);
    return theBlob;
  }
    console.log(myBlob);

    fetch(selectedFile)
    .then(res => res.blob())
    .then(blob => console.log(blob))
  }

  render() {
    	return (
					<Query
			      query = {GetProductImage}
			      variables = {{id: this.props.idProduct}}
			      fetchPolicy = 'network-only'
			      >
			      {
			        ({ loading, error, data, refetch, networkStatus}) => {
			          if (networkStatus === 4) return "Refetching...";
			          if (loading) return (
                  <Col lg={12}>
									<Col lg={6}>
			      				<StyledImg>
											<StyledImgText lg={12}>
												<span>Loading...</span>
											</StyledImgText>
										</StyledImg>
			      			</Col>
                  <Col lg={6}>
                    <Col lg={9} lgOffset={3}>
                      <Block>
                        <StyledButton><ImgButton src={icon_download}/><span>Download</span></StyledButton>
                        <StyledButton><ImgButton src={icon_download_copy}/><span>Bild Rezpt</span></StyledButton>
                        <ButtonDel><ImgButton src={icon_delete}/><span>Delete</span></ButtonDel>
                      </Block>
                    </Col>
                  </Col>
                </Col>
								);
			          if (error) return (
                  <Col lg={12}>
									<Col lg={6}>
			      				<StyledImg>
											<StyledImgText lg={12}>
												<input type="file" onChange={this.onFileSelected}/><span>Add a photo</span>
											</StyledImgText>
										</StyledImg>
			      			</Col>
                  <Col lg={6}>
                    <Col lg={9} lgOffset={3}>
                      <Block>
                        <StyledButton><ImgButton src={icon_download}/><span>Download</span></StyledButton>
                        <StyledButton><ImgButton src={icon_download_copy}/><span>Bild Rezpt</span></StyledButton>
                        <ButtonDel><ImgButton src={icon_delete}/><span>Delete</span></ButtonDel>
                      </Block>
                    </Col>
                  </Col>
                </Col>
								);
			          let image = data.getProductImg[0].img;
                console.log(image);
								return (
                  <Col lg={12}>
  									<Col lg={6}>
  			      				<StyledImg >
  											<Img src={image} onClick={this.saveBase64AsFile.bind(this, image)}/>
  										</StyledImg>
  			      			</Col>
                    <Col lg={6}>
            					<Col lg={9} lgOffset={3}>
            						<Block>
            							<StyledButton onClick={this.saveBase64AsFile.bind(this, image)}><ImgButton src={icon_download}/><span>Download</span></StyledButton>
            							<StyledButton><ImgButton src={icon_download_copy}/><span>Bild Rezpt</span></StyledButton>
            							<ButtonDel><ImgButton src={icon_delete}/><span>Delete</span></ButtonDel>
            						</Block>
            					</Col>
            				</Col>
                  </Col>
								)
							}
						}
					</Query>
    	);
  	}
	}

//Styled

const Block = styled.div`
	float: right;
	width: 100%;
`;

const StyledButton = styled.button`
	font-family: HelveticaNeue;
	font-size: 18px;
	font-weight: normal;
	font-style: normal;
	font-stretch: normal;
	line-height: normal;
	letter-spacing: normal;
	color: #ffffff;
	padding-left: 10%;
	text-align: center;
	width: 175px;
	height: 31px;
	border-radius: 6px;
	border: solid 1px #99d5d7;
	margin-top: 25px;
	background-color: #99d5d7;
`;

const StyledImg = styled(StyledButton)`
	color: #9b9b9b;
	width: 200px;
	height: 200px;
	border-radius: 50%;
	margin-top: 10px;
	background-color: #f5f5f5;
`;

const StyledImgText = styled(Col)`
	margin-top: 25px;
`;

const ButtonDel = styled(StyledButton)`
	background-color: #ff4b57;
	border-color: #ff4b57;
`;

const ImgButton = styled.img`
	float:left;
  border: 1ps solid ff4b57;
`;

const Img = styled.img`
	border-radius: 50%;
	margin: -1px 0 0 -23px;
	width: 200px;
	heigh: 200px;
`;
