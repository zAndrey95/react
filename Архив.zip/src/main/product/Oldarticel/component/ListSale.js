import React, { Component } from 'react';
import {Col} from 'react-bootstrap';
import {Query, Mutation } from 'react-apollo';
import styled from 'styled-components';

import Input from '../../../../../../../@appElements/input/Input.js'

import AllProduct_Artikel from '../../../../../../../functions/query/product/allProduct_Artikel.js'
import AllProduct_Article_Price_Category from '../../../../../../../functions/query/product/allProduct_Article_Price_Category.js'
import updateProductArticle from '../../../../../../../functions/mutation/product/updateProductArticle.js'

export default class ListSale extends Component {
  constructor() {
     super();
     this.state = {
      amount1: '',
   		amount2: '',
   		amount3: '',
   		amount4: '',
   		amount5: '',
   		amount6: '',
   		amount7: '',
   		amount8: '',
   		amount9: '',
   		amount10: ''
     }
   }

   onCompleted = (data) => {
     let sale = data.allProduct_Artikel[0];
     this.setState({
       amount1: sale.amount1,
       amount2: sale.amount2,
       amount3: sale.amount3,
       amount4: sale.amount4,
       amount5: sale.amount5,
       amount6: sale.amount6,
       amount7: sale.amount7,
       amount8: sale.amount8,
       amount9: sale.amount9,
       amount10: sale.amount10
     });
   }

   getValueOfInput = (e) => {
 		const key = e.target.name;
 	  const value = e.target.value;
 	  this.setState({[key]: value});
 	}

  update = (methode, e) => {
    const {name} = e.target;
    e.preventDefault();
    methode({
      variables: {
        id: this.props.idProduct,
        [name]: this.state[name]
      }
    })
  }

  render() {
    	return (
        <Query
          query = {AllProduct_Artikel}
          variables = {{id: this.props.idProduct}}
          fetchPolicy = 'network-only'
          onCompleted = {this.onCompleted}
          >
          {
            ({loading, error, data, refetch, networkStatus}) => {
              if (networkStatus === 4) return "Refetching...";
              if (loading)
              return (
                <Col lg={12}>
                  <Col lg={6}>
                    <Col lg={10}>
                      <Input
                        name="amount1"
                        text={"Laden"}
                        value={0}
                        onBlur={null}
                        onChange={null}
                        />
                    </Col>
                    <Col lg={2}/>
                  </Col>
                  <Col lg={6}>
                    <Col lg={10} lgOffset={2}>
                      <Input
                        name="amount2"
                        text={"Café"}
                        value={0}
                        onBlur={null}
                        onChange={null}/>
                      </Col>
                  </Col>
                </Col>);
              if (error)
              return (
                <Col lg={12}>
                  <Col lg={6}>
                    <Col lg={10}>
                      <Input
                        name="amount1"
                        text={"Laden"}
                        value={0}
                        onBlur={null}
                        onChange={null}
                        />
                    </Col>
                    <Col lg={2}/>
                  </Col>
                  <Col lg={6}>
                    <Col lg={10} lgOffset={2}>
                      <Input
                        name="amount2"
                        text={"Café"}
                        value={0}
                        onBlur={null}
                        onChange={null}/>
                      </Col>
                  </Col>
                </Col>);
              console.log(data);
              return(
                <Query
                  query = {AllProduct_Article_Price_Category}
                  fetchPolicy = 'network-only'
                  >
                  {
                    ({loading, error, data, refetch, networkStatus}) => {
                      if (networkStatus === 4) return "Refetching...";
                      if (loading)
                      return (
                        <Col lg={12}>
                          <Col lg={6}>
                            <Col lg={10}>
                              <Input
                                name="amount1"
                                text={"Laden"}
                                value={0}
                                onBlur={null}
                                onChange={null}
                                />
                            </Col>
                            <Col lg={2}/>
                          </Col>
                          <Col lg={6}>
                            <Col lg={10} lgOffset={2}>
                              <Input
                                name="amount2"
                                text={"Café"}
                                value={0}
                                onBlur={null}
                                onChange={null}/>
                              </Col>
                          </Col>
                        </Col>);
                      if (error) return `Error: ${error}`;
                      let price = data.allProduct_Article_Price_Category[0];
                      return(
                        <Mutation mutation={updateProductArticle}>
                          {updateArticle => (
                        <Col lg={12}>

                          <Col lg={6}>
                            <Col lg={10}>

                                  <Input
                                    name="amount1"
                                    text={price.Article_Price_Category1}
                                    value={this.state.amount1}
                                    onBlur={this.update.bind(this, updateArticle)}
                                    onChange={this.getValueOfInput}
                                    />

                                  {price.Article_Price_Category4 === null ? "" :
                              <Input
                                name="amount4"
                                text={price.Article_Price_Category4}
                                value={this.state.amount4 || ""}
                                onBlur={this.update.bind(this, updateArticle)}
                                onChange={this.getValueOfInput}/>
                          }

                          {price.Article_Price_Category7 === null ? "" :
                              <Input
                                name="amount7"
                                text={price.Article_Price_Category7}
                                value={this.state.amount7=== null ? "" : this.state.amount7}
                                onBlur={this.update.bind(this, updateArticle)}
                                onChange={this.getValueOfInput}/>
                          }

                          {price.Article_Price_Category10 === null ? "" :
                              <Input
                                name="amount10"
                                text={price.Article_Price_Category10}
                                value={this.state.amount10 === null ? "" : this.state.amount10}
                                onBlur={this.update.bind(this, updateArticle)}
                                onChange={this.getValueOfInput}/>
                          }
                            </Col>
                            <Col lg={2}/>
                          </Col>

                          <Col lg={6}>
                            <Col lg={10} lgOffset={2}>
                              <Input
                                name="amount2"
                                text={price.Article_Price_Category2}
                                value={this.state.amount2 === null ? "" : this.state.amount2}
                                onBlur={this.update.bind(this, updateArticle)}
                                onChange={this.getValueOfInput}/>

                              {price.Article_Price_Category5 === null ? "" :
                              <Input
                                name="amount5"
                                text={price.Article_Price_Category5}
                                value={this.state.amount5 === null ? "" : this.state.amount5}
                                onBlur={this.update.bind(this, updateArticle)}
                                onChange={this.getValueOfInput}/>
                          }

                          {price.Article_Price_Category8 === null ? "" :
                              <Input
                                name="amount8"
                                text={price.Article_Price_Category8}
                                value={this.state.amount8 === null ? "" : this.state.amount8}
                                onBlur={this.update.bind(this, updateArticle)}
                                onChange={this.getValueOfInput}/>
                          }

                            </Col>
                          </Col>

                        </Col>
                      )}
                      </Mutation>
                      )
                    }
                  }
                </Query>
              )
            }
          }
        </Query>
      );
  	}
	}

//Styled

const Block = styled.div`
	float: right;
	width: 100%;
`;

const StyledButton = styled.button`
	font-family: HelveticaNeue;
	font-size: 18px;
	font-weight: normal;
	font-style: normal;
	font-stretch: normal;
	line-height: normal;
	letter-spacing: normal;
	color: #ffffff;
	padding-left: 10%;
	text-align: center;
	width: 175px;
	height: 31px;
	border-radius: 6px;
	border: solid 1px #99d5d7;
	margin-top: 25px;
	background-color: #99d5d7;
`;

const StyledImg = styled(StyledButton)`
	color: #9b9b9b;
	width: 200px;
	height: 200px;
	border-radius: 50%;
	margin-top: 10px;
	background-color: #f5f5f5;
`;

const StyledImgText = styled(Col)`
	margin-top: 25px;
`;

const ButtonDel = styled(StyledButton)`
	background-color: #ff4b57;
	border-color: #ff4b57;
`;

const ImgButton = styled.img`
	float:left;
`;

const Img = styled.img`
	border-radius: 50%;
	margin: -1px 0 0 -23px;
	width: 200px;
	heigh: 200px;
`;
