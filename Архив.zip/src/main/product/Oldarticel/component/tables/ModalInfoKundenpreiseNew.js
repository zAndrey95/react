import React, { Component } from 'react';
import { graphql, compose } from 'react-apollo';
import { Col, Row } from 'react-bootstrap';
import styled from 'styled-components';

import {ModalWindow, ModalBody, ModalHead, HeadTitle, IconCancel, ModalButton, ModalText} from './ModalInfoPreiskategorienNew.js'

import AllProduct_Artikel_Kundenpreise_Modal from '../../../../../../../../functions/query/product/allProduct_Artikel_Kundenpreise_Modal.js'
import updateProduct_Artikel_Kundenpreise from '../../../../../../../../functions/mutation/product/updateProduct_Artikel_Kundenpreise.js'
import addProduct_Artikel_Kundenpreise from '../../../../../../../../functions/mutation/product/addProduct_Artikel_Kundenpreise.js'

import Dropdown from '../../../../../../../../@appElements/dropDown/Dropdown.js';
import SimpleDropdown from '../../../../../../../../@appElements/dropDown/SimpleDropdown.js';
import CheckBox from '../../../../../../../../@appElements/checkBox/CheckBox.js';
import Input from '../../../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../../../@appElements/textarea/Textarea.js'
import Calendar from '../../../../../../../../@appElements/calendar/Calendar.js'

class ModalInfoKundenpreiseNew extends Component {
  constructor(props) {
    super(props);
    this.state = {
    ...props.info,
    };
    this.getValueOfInput = this.getValueOfInput.bind(this);
  }

  changeValueOnCheckbox = (e) => {
	  const key = e.target.id;
	  const value = !this.state[key]
    console.log(key);
    console.log(value);
	  this.updateProduct_Artikel_Kundenpreise({
	    [key]: value
	  })
	}

  getValueOfInput = (e) => {
    const key = e.target.name;
	  const value = e.target.value;
	  this.setState({
      [key]: value
    });
  }

  getValueOfInputBlur = (e) => {
		const key = e.target.name;
	  const value = this.state[key];
		this.updateProduct_Artikel_Kundenpreise({
	    [key]: value
	  })
	}

  updateProduct_Artikel_Kundenpreise = (values) => {
	  const {updateProduct_Artikel_Kundenpreise, idLinkCustomer} = this.props;
  	  updateProduct_Artikel_Kundenpreise({
  	    variables: {
  	      Intern: this.state.Intern,
          LinkArticle: idLinkCustomer,
  	      ...values
  	    },
  	    options: {
  	      fetchPolicy: 'cache-first'
  	    }
  	  })
    }

    addProduct_Artikel_Kundenpreise = () => {
  	  const {addProduct_Artikel_Kundenpreise, idLinkCustomer} = this.props;
  	  addProduct_Artikel_Kundenpreise({
  	    variables: {
          LinkArticle: idLinkCustomer,
          Price: this.state.Price,
          FromAmount:this.state.FromAmount,
          Discount: this.state.Discount,
          DiscountsDisabled: this.state.DiscountsDisabled,
          Description: this.state.Description
  	    },
  	    options: {
  	      fetchPolicy: 'cache-first'
  	    }
  	  })
  	}

    changeIndexDropDawn = () => {

    }

  render() {
    console.log(this.state);

    if(this.props.AllProduct_Artikel_Kundenpreise_Modal.loading ){ return <div> Loading</div>}
		if(this.props.AllProduct_Artikel_Kundenpreise_Modal.error){ return <div> {this.props.AllProduct_Artikel_Kundenpreise_Modal.error}</div>}
		else{
    return (
      <ModalWindow>
        <ModalHead>
          <HeadTitle>
            Kundenpreise
          </HeadTitle>
          <IconCancel onClick={this.props.closeModal} src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACsSURBVEhL7ZVRDoMwDEO7O+5SILRx4m6xZKNqsJKUfPIkVNVtnvtHuQlRa33aN3MbBrNwcLvHDqePYeuLkRvMcLb/wOaiuyQ8ExkIy4VncFgueoLLcnEkSpOLVpguFxKDdDn4KXgzzkFyrJCnlrRyRsi2ElsejOMcycXlkp4cQDpcciYXkDYlK/Y8+o9XLiCl/LzELsy86JILSJuShfEeOxz+4bBkgYPRjYdSvtX7jKmE+SdnAAAAAElFTkSuQmCC"/>
        </ModalHead>
        <ModalBody>

        <TitleArn>
          <Col lg={4}>
            <Input
              text="Arn"
              value={this.props.idArtikel}/>
          </Col>
        </TitleArn>

        <Row>
          <Col lg={5}>
            <ModalText>Von Datum</ModalText>
            <Calendar getDate={this.state.ToDate || ""} colorText={"black"}/>
          </Col>

          <Col lg={5} lgOffset={2}>
            <ModalText>Bis Datum</ModalText>
            <Calendar getDate={this.state.FromDate  || ""} colorText={"black"}/>
          </Col>
        </Row>

        <Row>
          <Col lg={12}>
            <Dropdown
              style={{zIndex: 1}}
              list={this.props.AllProduct_Artikel_Kundenpreise_Modal.allProduct_Artikel_Kundenpreise_Modal}
              text="Kunde"
              gruppeId={99}
              row={"AktNmeIntern"}
              onBlur={this.changeIndexDropDawn}
            />

            <SimpleDropdown
              style={{zIndex: 1}}
                onBlur={this.changeIndexDropDawn}
                searchValue={this.props.searchValue}
                search={this.props.getValueOfInput}
                list={this.props.AllProduct_Artikel_Kundenpreise_Modal.allProduct_Artikel_Kundenpreise_Modal}
                text="Kunde"
                row={"AktNmeIntern"}
                next={this.more}
                gruppeId={this.state.LinkCustomer}
                />

          </Col>
        </Row>

        <Row>
          <Col lg={5}>
            <Input
              name="Price"
              text="Preis"
              value={this.state.Price || ""}
              onChange={this.getValueOfInput}
              onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}/>
          </Col>

          <Col lg={5} lgOffset={2}>
            <Input
              name="FromAmount"
              text="Ad Menge"
              value={this.state.FromAmount || ""}
              onChange={this.getValueOfInput}
              onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}/>
          </Col>
        </Row>

        <Row>
          <Col lg={5} >
            <Input
              name="Discount"
              text="Rabbat"
              value={this.state.Discount || ""}
              onChange={this.getValueOfInput}
              onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}/>
          </Col>

          <Col lg={5} lgOffset={2} style={{padding: "50px 0 0 0"}} onClick={this.changeValueOnCheckbox} onBlur={this.getValueOfInputBlur}>
            <CheckBox
              value="Nettoartikel"
              open={this.state.DiscountsDisabled || false}
              id="DiscountsDisabled"/>
          </Col>
        </Row>

        <Row>
          <Col lg={12}>
            <Textarea
              width="450px"
              name='Description'
              type="text"
              text="Note"
              value={this.state.Description || ""}
              onChange={this.getValueOfInput}
              onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}
              />
          </Col>
        </Row>

          <Row>
            <ModalButton onClick={this.state.Intern == null ? this.addProduct_Artikel_Preikategorien : this.props.closeModal} marginRight="69px">SAVE</ModalButton>
            <ModalButton onClick={this.props.closeModal} backgroundButton="#2e3941">CANCEL</ModalButton>
          </Row>
        </ModalBody>
    </ModalWindow>
    )
}
  }
}

const graph = compose(
	graphql(AllProduct_Artikel_Kundenpreise_Modal, {name: "AllProduct_Artikel_Kundenpreise_Modal"}),
  graphql(updateProduct_Artikel_Kundenpreise, {name: "updateProduct_Artikel_Kundenpreise"}),
  graphql(addProduct_Artikel_Kundenpreise, {name: "addProduct_Artikel_Kundenpreise"}),
	)(ModalInfoKundenpreiseNew);

export default graph;

export const TitleArn = styled(Row)`
  margin-bottom: 25px;
`;
