import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import { Col, Row } from 'react-bootstrap';
import styled from 'styled-components';

import {ModalWindow, ModalBody, ModalHead, HeadTitle, IconCancel, ModalButton} from './ModalInfoPreiskategorienNew.js'

import Dropdown from '../../../../../../../../@appElements/dropDown/Dropdown.js';
import Input from '../../../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../../../@appElements/textarea/Textarea.js'

class ModalInfoKundenpreiseNew extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ...props.info,
    };
    this.getValueOfInput = this.getValueOfInput.bind(this);
  }

  addModalInputsInArray(){
    //let ar = this.state.artikelArray;
    //Object.preventExtensions(ar);
    //ar.push(1);
  }

  getValueOfInput(event){
    let eventname= event.target.name;
    this.setState({[eventname]: event.target.value})
  }

  render() {
    console.log(this.state);
    console.log(this.props);
    return (
      <ModalWindow>
        <ModalHead>
          <HeadTitle>
            Preikategorien
          </HeadTitle>
          <IconCancel onClick={this.props.closeModal} src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACsSURBVEhL7ZVRDoMwDEO7O+5SILRx4m6xZKNqsJKUfPIkVNVtnvtHuQlRa33aN3MbBrNwcLvHDqePYeuLkRvMcLb/wOaiuyQ8ExkIy4VncFgueoLLcnEkSpOLVpguFxKDdDn4KXgzzkFyrJCnlrRyRsi2ElsejOMcycXlkp4cQDpcciYXkDYlK/Y8+o9XLiCl/LzELsy86JILSJuShfEeOxz+4bBkgYPRjYdSvtX7jKmE+SdnAAAAAElFTkSuQmCC"/>
        </ModalHead>
        <ModalBody>

        <Row>
          <Col lg={12}>
            <Dropdown
              style={{zIndex: 100}}
              list={["ss","ss"]}
              text="Art"
            />
          </Col>
        </Row>

        <Row>
          <Col lg={5}>
            <Input text="Brutto" value={this.state.Price}/>
          </Col>
        </Row>

        <Row>
          <Col lg={12}>
            <Textarea
              width="450px"
              name='modalBemerkung'
              type="text"
              text="Bemerkung"
              value={this.state.Description}
              />
          </Col>
        </Row>

          <Row>
            <ModalButton onClick={this.state.Intern == null ? this.addProduct_Artikel_Preikategorien : this.props.closeModal} marginRight="69px">SAVE</ModalButton>
            <ModalButton onClick={this.props.closeModal} backgroundButton="#2e3941">CANCEL</ModalButton>
            </Row>
        </ModalBody>
      </ModalWindow>
    )
  }
}

export default ModalInfoKundenpreiseNew;
