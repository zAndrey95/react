import React, { Component } from 'react';
import { graphql, compose } from 'react-apollo';
import { Col, Row } from 'react-bootstrap';
import styled from 'styled-components';

import Input from '../../../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../../../@appElements/textarea/Textarea.js'
import Calendar from '../../../../../../../../@appElements/calendar/Calendar.js'

import updateProduct_Artikel_Preikategorien from '../../../../../../../../functions/mutation/product/updateProduct_Artikel_Preikategorien.js'
import addProduct_Artikel_Preikategorien from '../../../../../../../../functions/mutation/product/addProduct_Artikel_Preikategorien.js'

class ModalInfoKundenpreiseNew extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: this.props.info,
    };
    this.getValueOfInput = this.getValueOfInput.bind(this);
  }

  handleFieldChange = e => {
    const { name, value } = e.target;
    this.setState(({ data }) => ({
      data: { ...data, [name]: value }
    }));
  };

  handleSubmit = e => {
    e.preventDefault();
    this.props.onSubmit(this.state.data);
  };

  getValueOfInput = (e) => {
    const key = e.target.name;
	  const value = e.target.value;
	  this.setState({
      [key]: value
    });
  }

  getValueOfInputBlur = (e) => {
		const key = e.target.name;
	  const value = this.state[key];
		this.updateProduct_Artikel_Preikategorien({
	    [key]: value
	  })
	}

  updateProduct_Artikel_Preikategorien = (values) => {
	  const {updateProduct_Artikel_Preikategorien, idLinkCustomer} = this.props;
  	  updateProduct_Artikel_Preikategorien({
  	    variables: {
  	      Intern: this.state.Intern,
          LinkArticle: idLinkCustomer,
  	      Price1: this.state.data.Price1
  	    },
  	    options: {
  	      fetchPolicy: 'cache-first'
  	    }
  	  })
      console.log("save");
    }

  addProduct_Artikel_Preikategorien = () => {
	  const {addProduct_Artikel_Preikategorien, idLinkCustomer} = this.props;
	  addProduct_Artikel_Preikategorien({
	    variables: {
        LinkArticle: idLinkCustomer,
        Description: this.state.Description,
        Price1: this.state.Price1,
        Price2: this.state.Price2,
        Price3:this.state.Price3,
        Price4: this.state.Price4,
        Price5: this.state.Price5,
        Price6: this.state.Price6
	    },
	    options: {
	      fetchPolicy: 'cache-first'
	    }
	  })
	}

  render() {
    console.log(this.state);
    console.log(this.props);
    const { data } = this.state;
    return (
      <ModalWindow>
        <ModalHead>
          <HeadTitle>
            Preikategorien
          </HeadTitle>
          <IconCancel onClick={this.props.closeModal} src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACsSURBVEhL7ZVRDoMwDEO7O+5SILRx4m6xZKNqsJKUfPIkVNVtnvtHuQlRa33aN3MbBrNwcLvHDqePYeuLkRvMcLb/wOaiuyQ8ExkIy4VncFgueoLLcnEkSpOLVpguFxKDdDn4KXgzzkFyrJCnlrRyRsi2ElsejOMcycXlkp4cQDpcciYXkDYlK/Y8+o9XLiCl/LzELsy86JILSJuShfEeOxz+4bBkgYPRjYdSvtX7jKmE+SdnAAAAAElFTkSuQmCC"/>
        </ModalHead>
        <ModalBody>
          <Row>
            <Col lg={4}>
              <ModalText>Von Datum</ModalText>
              <Calendar getDate={this.state.ToDate || ""} colorText={"black"}/>
            </Col>

            <Col lg={4} lgOffset={3}>
              <ModalText>Bis Datum</ModalText>
              <Calendar getDate={this.state.FromDate || ""} colorText={"black"}/>
            </Col>
          </Row>
        <form onSubmit={this.handleSubmit}>
          <Row>

            <Col lg={5}>
              <Input
                width={"145px"}
                text="Laden"
                name="Price1"
                value={data.Price1 || ""}
                onChange={this.handleFieldChange}
                onBlur={this.state.Intern == null ? null : this.updateProduct_Artikel_Preikategorien}
                />
            </Col>

            <Col lg={5} lgOffset={2}>
              <Input
                width={"145px"}
                text="Lieferung"
                name="Price2"
                value={this.state.Price2}
                onChange={this.getValueOfInput}
                onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}
                />
            </Col>
          </Row>

          <Row>
            <Col lg={5}>
              <Input
                width={"145px"}
                text="Netto"
                name="Price3"
                value={this.state.Price3}
                onChange={this.getValueOfInput}
                onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}/>
            </Col>

            <Col lg={5} lgOffset={2}>
              <Input
                width={"145px"}
                text="Im Haus"
                name="Price4"
                value={this.state.Price4}
                onChange={this.getValueOfInput}
                onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}/>
            </Col>
          </Row>

          <Row>
            <Col lg={5}>
              <Input
                width={"145px"}
                text="Brutto"
                name="Price5"
                value={this.state.Price5}
                onChange={this.getValueOfInput}
                onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}/>
            </Col>
          </Row>

          <Row>
            <Col lg={12}>
              <Textarea
                width="453px"
                height="104px"
                name='Description'
                type="text"
                text="Bemerkung"
                value={this.state.Description}
                onChange={this.getValueOfInput}
                onBlur={this.state.Intern == null ? null : this.getValueOfInputBlur}
                />
            </Col>
          </Row>

          <Row>
            <ModalButton type="submit" onClick={this.state.Intern == null ? this.addProduct_Artikel_Preikategorien : this.props.closeModal} marginRight="69px">SAVE</ModalButton>
            <ModalButton onClick={this.props.closeModal} backgroundButton="#2e3941">CANCEL</ModalButton>
            </Row>
      </form>
        </ModalBody>
      </ModalWindow>
    )
  }
}

const graph = compose(
  graphql(updateProduct_Artikel_Preikategorien, {name: "updateProduct_Artikel_Preikategorien"}),
  graphql(addProduct_Artikel_Preikategorien, {name: "addProduct_Artikel_Preikategorien"}),
)(ModalInfoKundenpreiseNew);

export default graph;

export const ModalWindow = styled.div`
  width: 549px;
  background-color: #f5f5f5;
  box-shadow: 0 2px 4px 0 rgba(90, 90, 90, 0.2);
`;

export const ModalHead = styled.div`
  width: 100%;
  height: 60px;
  border-radius: 3px;
  background-color: #2e3941;
  padding: 16px 10px 16px 20px;
`;

export const HeadTitle = styled.span`
  width: 147px;
  height: 28px;
  font-family: HelveticaNeue;
  font-size: 24px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #ffffff;
`;

export const IconCancel = styled.img`
  width: 20px;
  float: right;
  margin: 0px 5px 20px 0px;
  cursor: pointer;
`;

export const ModalBody = styled.div`
  margin: 15px 56px 0 27px;
  `;

export const ModalText = styled(HeadTitle)`
  width: 80px;
  height: 18px;
  font-size: 16px;
  color: #000000;
`;

export const ModalButton = styled.button`
  width: ${props => props.width || "180px"};
  height: 42px;
  border-radius: 4px;
  margin-right: ${props => props.marginRight || "0"};
  margin-top: ${props => props.marginTop || "40px"};
  margin-left: ${props => props.marginLeft || "10px"};
  margin-bottom: 37px;
  background-color: ${props => props.backgroundButton || "#99d5d7"};
  border: none;
  font-family: HelveticaNeue;
  font-size: 14px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: center;
  color: #ffffff;
`;
