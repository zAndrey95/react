import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { NavLink } from 'react-router-dom'
import {Route, Switch} from 'react-router-dom';
import { graphql, compose, Query } from 'react-apollo';
import styled from 'styled-components';

import CheckBox from '../../../../../../../../@appElements/checkBox/CheckBox.js';
import HeaderTable from '../../../../../../../../@appElements/table/HeaderTable.js'
import Table from '../../../../../../../../@appElements/table/Table.js'
import Minus_red from '../../../../../../../../@appElements/item_Img/Minus_red.js'

import Modal from '../../../../../../../../@appElements/modal/Modal.js'
import ModalInfoKundenpreiseNew from './ModalInfoKundenpreiseNew.js'
import ModalInfoPreiskategorienNew from './ModalInfoPreiskategorienNew.js'
import ModalInfoResellerPreiseNew from './ModalInfoResellerPreiseNew.js'

import AllProduct_Artikel_Preikategorien from '../../../../../../../../functions/query/product/allProduct_Artikel_Preikategorien.js'
import AllProduct_Artikel_Kundenpreise from '../../../../../../../../functions/query/product/allProduct_Artikel_Kundenpreise.js'
import AllProduct_Artikel_ResellerPreise from '../../../../../../../../functions/query/product/allProduct_Artikel_ResellerPreise.js'
import updateProduct_Artikel_Preikategorien from '../../../../../../../../functions/mutation/product/updateProduct_Artikel_Preikategorien.js'

import updateSubscProductArtikelPreikategorien from '../../../../../../../../functions/subscription/product/updateSubscProductArtikelPreikategorien.js'

import '../../Articel.css';

class TablesArtikel extends Component {
	constructor() {
    super();
    this.state = {
		modalIsOpen: false,
		modalIsOpenName: "",
		test: '',
		preikategorien: [],
		kundenpreise: [],
		kundenpreiseOneRow: [],
		resellerPreise: [],
		modalOneRow: [],
		editingRow: '',
		//
		Price1: ''
	};
  }

	static getDerivedStateFromProps(nextProps, prevState) {
		if(
			!nextProps.AllProduct_Artikel_Preikategorien.loading &&
			!nextProps.AllProduct_Artikel_Kundenpreise.loading &&
			!nextProps.AllProduct_Artikel_ResellerPreise.loading){
				const 	store2 = nextProps.AllProduct_Artikel_Preikategorien.allProduct_Artikel_Preikategorien;
				const 	store3 = nextProps.AllProduct_Artikel_Kundenpreise.allProduct_Artikel_Kundenpreise;
				const 	store4 = nextProps.AllProduct_Artikel_ResellerPreise.allProduct_Artikel_ResellerPreise;
					return {
					preikategorien: store2,
					kundenpreise: store3,
					resellerPreise: store4,
			}
		return null
	}
}

	componentDidMount = () => {
		this.props.subscribeToUpdPreikategorien();
		this.setState({});
	}

	indexOnClickTable = (name, status, index) => {
		const value = this.state[name][index];
		console.log(value);
		console.log(index);
		this.setState({
			status: true,
			modalIsOpen: true,
			modalOneRow: value,
			Price1: value.Price1,
			editingRow: index
		})
  }

	openModal = (status) => {
		this.setState({
			modalIsOpen: true,
			status: false
		})
	}

		closeModal = () => {
	    this.setState({
				modalIsOpen: false
			});
	  }

		getValueOfInput = (e) => {
			let eventname = e.target.name;
			console.log(eventname);
			this.setState({[eventname]: e.target.value})
			console.log(this.state.Price1);
		}

		getValueOfInputBlur = (e) => {
			const key = e.target.name;
		  const value = this.state[key];
			this.updateProduct_Artikel_Preikategorien({
		    [key]: value
		  })
		}

	  updateProduct_Artikel_Preikategorien = (values) => {
		  const {updateProduct_Artikel_Preikategorien, idProduct} = this.props;
	  	  updateProduct_Artikel_Preikategorien({
	  	    variables: {
	  	      Intern: this.state.modalOneRow.Intern,
	          LinkArticle: idProduct,
	  	      ...values
	  	    },
	  	    options: {
	  	      fetchPolicy: 'cache-first'
	  	    }
	  	  })
	    }

	changeRow = (index, row) => {
    const newData = [...this.state.preikategorien]; // copy array for "safe" mutations (dont't do that, it's just for shortness)
    newData[index] = row;
    this.setState({ preikategorien: newData, editingRow: null }); // in real life there will be api call
  };

  render() {
		console.log(this.state.modalOneRow.Price1);
		console.log(this.state);
		console.log(this.props);

  	const arrayKundenpreise=[];
    this.state.kundenpreise.forEach((item)=>{
    	let fromDate = item.FromDate===null?'':item.FromDate.substring(0,10);
			let toDate = item.ToDate===null?'':item.ToDate.substring(0,10);
      arrayKundenpreise.push([toDate, fromDate, item.KundenNr, item.AktNameIntern, item.Price, item.FromAmount, item.Discount, <CheckBox open={item.DiscountsDisabled}/>, item.Description])
    })

    const arrayPreikategorien=[];
    this.state.preikategorien.forEach((item)=>{
    	let fromDate = item.FromDate===null?'':item.FromDate.substring(0,10);
			let toDate = item.ToDate===null?'':item.ToDate.substring(0,10);
      arrayPreikategorien.push([toDate, fromDate, item.Price1, item.Price2, item.Price3, item.Price4, item.Price5, item.Description])
    })

    const arrayResellerPreise=[];
    this.state.resellerPreise.forEach((item)=>{
      arrayResellerPreise.push([item.KundenNR, item.AktNameIntern,  item.Price, item.Description])
    })

		if(this.props.AllProduct_Artikel_Preikategorien.loading ||
			this.props.AllProduct_Artikel_ResellerPreise.loading  ||
			this.props.AllProduct_Artikel_Kundenpreise.loading)
			{ return <div></div>}
		if(this.props.AllProduct_Artikel_Preikategorien.error)
			{return <div> {this.props.AllProduct_Artikel_Preikategorien.error}</div>}
		else{
    	return (
      	<Col lg={12} style={{padding: "0 15px 0 15px"}}>
      			<div style={{padding: "20px 0 0 0"}}>
			     		<Col lg={4} className="list_menu_two"><NavLink to={'/products/' + this.props.id +'/articel/preikategorien'}  activeClassName="active_element"><button className="item_link_two"> Preikategorien</button></NavLink></Col>
			      	<Col lg={4} className="list_menu_two"><NavLink to={'/products/' + this.props.id +'/articel/kundenpreise'} activeClassName="active_element"> <button className="item_link_two"> Kundenpreise</button></NavLink> </Col>
			      	<Col lg={4} className="list_menu_two"><NavLink to={'/products/' + this.props.id +'/articel/resellerPreise'} activeClassName="active_element"><button className="item_link_two"> Reseller Preise</button></NavLink> </Col>
			    	</div>

					<Switch>
						<Route path={'/products/' + this.props.id +'/articel/preikategorien'} render={props =>
							<Row>
								<Modal
				            isOpen={this.state.modalIsOpen}
				            width={"481px"}
										component={
											<ModalInfoPreiskategorienNew
												closeModal={this.closeModal}
												info={this.state.status ? this.state.preikategorien[this.state.editingRow] : {} }
												value={this.state.Price1}
												idLinkCustomer={this.props.idProduct}
												onChange={this.getValueOfInput}
												onBlur={this.getValueOfInputBlur}
												onSubmit={datum => this.changeRow(this.state.editingRow, datum)}
												/>}
				          />
								<Col lg={12}>
									<HeaderTable widths={["7%","93%"]}
										items={[
											<Minus_red top="11px"/>,
											<div></div>
										]}
									/>
						        <Table
					            onClick={this.indexOnClickTable.bind(this, "preikategorien", "edit")}
					            names={["Von Datum", "Bis Datum", "Laden", "Lieferung", "Netto", "Im Haus", "Brutto","Bemerkung"]}
					            widths={['12.5%', '12.5%', '12.5%', '12.5%', '12.5%', '12.5%', '12.5%', '12.5%']}
					            arr={arrayPreikategorien}
											searchParameter = {"7"}
										/>
									<ButtonAddElement onClick={this.openModal.bind(this, "plus")}>Create</ButtonAddElement>
								</Col>
							</Row>
						}/>
						<Route path={'/products/' + this.props.id +'/articel/kundenpreise'} render={props =>
							<Row>
								<Modal
									isOpen={this.state.modalIsOpen}
									width={"481px"}
									component={ <ModalInfoKundenpreiseNew
										closeModal={this.closeModal}
										info={this.state.status ? this.state.modalOneRow : {} }
										idArtikel={this.state.itemsNm}
										idLinkCustomer={this.props.idProduct}
										kunde={this.state.kundenpreise_Modal}
										/>}
				          />
								<Col lg={12}>
									<HeaderTable widths={["7%","93%"]}
										items={[
											<Minus_red top="11px"/>,
											<div></div>
										]}
									/>
									<Table
										onClick={this.indexOnClickTable.bind(this, "kundenpreise", "edit")}
										widths={['10%', '10%', '10%', '20%', '10%', '10%', '10%', '10%', '10%']}
										arr={arrayKundenpreise}
										searchParameter = {"3"}
										names={["Von Datum", "Bis Datum", "KundenNr", "Name", "Preis", "Ab Menge", "Rabbat", "Netto artikel", "Bemerkung"]}
									/>
								<ButtonAddElement onClick={this.openModal.bind(this, "plus")}>Create</ButtonAddElement>
						    </Col>
							</Row>
						}/>
						<Route path={'/products/' + this.props.id +'/articel/resellerPreise'} render={props =>
							<Row>
									<Modal
										isOpen={this.state.modalIsOpen}
										width={"481px"}
										component={ <ModalInfoResellerPreiseNew
											closeModal={this.closeModal}
											info={this.state.status ? this.state.modalOneRow : {} }
											idArtikel={this.state.kundenpreiseOneRow.DiscountsDisabled}
											kunde={this.state.kundenpreise_Modal}
											/>}
					          />
								<Col lg={12}>
									<HeaderTable widths={["7%","93%"]}
										items={[
											<Minus_red top="11px"/>,
											<div></div>
										]}
									/>
					        <Table
					          onClick={this.indexOnClickTable.bind(this, "resellerPreise", "edit")}
					          names={["KundenNr", "Name", "Preis", "Bemerkung"]}
					          widths={['15%', '40%', '15%', '30%']}
										searchParameter = {"1"}
					          arr={arrayResellerPreise}
									/>
								<ButtonAddElement onClick={this.openModal.bind(this, "plus")}>Create</ButtonAddElement>
								</Col>
							</Row>
						}/>
					</Switch>

      	</Col>
    	);
  	}
	}
}

const graph = compose(
	graphql(AllProduct_Artikel_Preikategorien, {
		name: "AllProduct_Artikel_Preikategorien",
				options: (props) => ({
						fetchPolicy: 'network-only',
						variables: {
							id: props.idProduct,
						}
				}),
			}),
	graphql(AllProduct_Artikel_Preikategorien, {
	name: "Preikategorien",
			options: (props) => ({
					fetchPolicy: 'network-only',
					variables: {
						id: props.idProduct,
					}
			}),
	props: (props) => ({
	subscribeToUpdPreikategorien: params => {
			props.Preikategorien.subscribeToMore({
					document: updateSubscProductArtikelPreikategorien,
						updateQuery: (prev, { subscriptionData: { data : { updateSubscProductArtikelPreikategorien}}  }) => ({
							 ...prev,
							 allProduct_Artikel_Preikategorien: [ ...prev.allProduct_Artikel_Preikategorien.map(function(name){
									return List()
									function List(){
										if(name.Intern === updateSubscProductArtikelPreikategorien.Intern){return updateSubscProductArtikelPreikategorien}
										else{
											console.log(name);
											console.log(updateSubscProductArtikelPreikategorien);
											return name}
								}
							}
						)] , __typename: 'PreikategorienSub',
					}),
			});
	},
	})
	}),
	graphql(AllProduct_Artikel_Kundenpreise, {
				options: (props) => ({
						fetchPolicy: 'network-only',
						variables: {
							id: props.idProduct,
						}
				}),
				name: "AllProduct_Artikel_Kundenpreise",
	}),
	graphql(AllProduct_Artikel_ResellerPreise, {
				options: (props) => ({
						fetchPolicy: 'network-only',
						variables: {
							id: props.idProduct,
						}
				}),
				name: "AllProduct_Artikel_ResellerPreise",
	}),
	graphql(updateProduct_Artikel_Preikategorien, {name: "updateProduct_Artikel_Preikategorien"}),
)(TablesArtikel);

export default graph;

export const ButtonAddElement = styled.button`
  width: 57px;
  height: 17px;
  font-family: Helvetica;
  font-size: 14px;
  font-weight: normal;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #ffffff;
  width: 220px;
  height: 41px;
  border-radius: 4px;
  background-color: #99d5d7;
  margin: 17px 0;
  text-transform: uppercase;
`;
