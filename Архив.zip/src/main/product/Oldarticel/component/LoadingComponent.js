import React, { Component } from 'react';
import {Col} from 'react-bootstrap';
import {Query } from 'react-apollo';
import styled from 'styled-components';

import {StyledCol, TitleProduct} from '../Articel.js';

import CheckBox from '../../../../../../../@appElements/checkBox/CheckBox.js';
import Dropdown from '../../../../../../../@appElements/dropDown/Dropdown.js';
import Input from '../../../../../../../@appElements/input/Input.js'
import Title from '../../../../../../../@appElements/title/Title.js'

import ImgComponent from './ImgComponent.js'
import ListSale from './ListSale.js'

const LoadingData = {name: 'Loading..', falseCheckbox: false}

export default class LoadingComponent extends Component {
  test = () =>{

  }
  render() {

    const data = LoadingData;
    console.log(data);

    	return (
      <div>
        <StyledCol>
          <TitleProduct>{data.name}</TitleProduct>
				</StyledCol>
        <div style={{padding: "0 0 0 15px"}}>
      		<Col lg={12}>
      			<Col lg={4}>
							<Input
								text="Artikel-Nr."
								value={data.name}
							/>
							<Input
									text="Bezeichnung"
									value={data.name}
								/>
		      		<Col lg={12}>
			      		<Col lg={6}>
			      			<CheckBox top="15px" value={'Artikel als Titel'} open={data.falseCheckbox}/>
			      		</Col>
			      		<Col lg={6} >
			      			<CheckBox top="15px" value={'Nettoartikel'} open={data.falseCheckbox}/>
			      		</Col>
			      	</Col>
		      		<Col lg={12}>
		      			<CheckBox top="10px" value={'Artikel ist Aktiv'} open={data.falseCheckbox}/>
		      		</Col>
		      		<Dropdown
								text="Warengruppe"
								row={"name"}
								style={{zIndex: 3, width: '100%'}}
								list={[1,2,3]}
								gruppeId={1}
								onBlur={this.test}
								deleteDropDown={this.test}
								addDropDown={this.test}
								updeteDrop={this.test}/>
		      		<Dropdown
								text="Produktionsgruppe"
								style={{zIndex: 2, width: '100%'}}
                list={[1,2,3]}
								gruppeId={1}
								onBlur={this.test}
								deleteDropDown={this.test}
								addDropDown={this.test}
								updeteDrop={this.test}/>
		      		<Dropdown
								text="Marketing-Gruppe"
								style={{zIndex: 1, width: '100%'}}
                list={[1,2,3]}
								gruppeId={1}
								onBlur={this.test}
								deleteDropDown={this.test}
								addDropDown={this.test}
								updeteDrop={this.test}/>
	      		</Col>
	      		<Col lg={4} lgOffset={2}>
	      			<Title text="Bild"/>
							<ImgComponent idProduct={{}}/>

		      		<ListSale idProduct={{}}/>

	      		</Col>

      		</Col>
      	</div>
      </div>
    	);
  	}
	}
