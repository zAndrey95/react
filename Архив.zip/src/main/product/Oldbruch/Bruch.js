import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { graphql, compose, Query, Mutation } from 'react-apollo';
import styled from 'styled-components';
import gql from 'graphql-tag';

import Input from'../../../../../../@appElements/input/Input.js'
import Title from'../../../../../../@appElements/title/Title.js'
import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';
import Dropdown from '../../../../../../@appElements/dropDown/Dropdown'
import Items from '../components/index.js'

import AllProduct_Artikel from '../../../../../../functions/query/product/allProduct_Artikel.js'
import updateProductArticle from '../../../../../../functions/mutation/product/updateProductArticle.js'
import {Active, List} from '../../../../../../functions/query/product/bruchItems_Active.js'

class Bruch extends Component {
 constructor() {
    super();
    this.state = {
     BruchVerwendeteTeile: '',
     IsBruchTitel: '',
     idActiveElement: '',
     isOpenModal: false,
     activeElement: '',
     listItems: [],
     search: '',

     BruchSummierenAuf:'',
     dataS: '',

     test: 'info',

     activeValue: ''
    }
  }

	getValueOfInput = (e) => {
		const key = e.target.name;
	  const value = e.target.value;
	  this.setState({[key]: value});
	}

  onCompleted = (data) => {
    try {
      let info = data.allProduct_Artikel[0];
      this.setState({
        BruchVerwendeteTeile: info.BruchVerwendeteTeile,
        IsBruchTitel: info.IsBruchTitel,
        idActiveElement: info.BruchSummierenAuf
      })
    }
    catch(error){
      this.setState({
        BruchVerwendeteTeile: '',
        IsBruchTitel: '',
        idActiveElement: ''
      })
			console.log(error);
		}
  }

  onCompletedActive = (data) => {
    try {
      let info = data.allArtikleBruchActiveElement[0];
      this.setState({
        activeElement: info.ConcatenatedField
      })
    }
    catch(error){
      this.setState({
        activeElement: ''
      })
			console.log(error);
		}
  }

  onCompletedList = (data) => {
    try {
      let info = data.allArtikleBruchList;
      this.setState({
        listItems: info
      })
    }
    catch(error){
      this.setState({
        listItems: ''
      })
			console.log(error);
		}
  }

  update = (methode, e) => {
    const {name} = e.target;
    e.preventDefault();
    methode({
      variables: {
        id: this.props.intern,
        [name]: this.state[name]
      }
    })
  }

  updateCheckBox = (methode, e) => {
    const name = e.target.id;
    e.preventDefault();
    this.setState({
      [name]: !this.state[name]
    })
    methode({
      variables: {
        id: this.props.intern,
        [name]: !this.state[name]
      }
    })
  }

  openModal = () => {
    this.setState({isOpenModal: true});
  }

  closeModal = () => {
    this.setState({isOpenModal: false});
  }

  changeActiveName = (methode, idActive, nameActive, e) => {
    console.log(nameActive);
    this.setState({
      activeElement: nameActive
    })
      e.preventDefault();
      methode({
        variables: {
          id: this.props.intern,
          BruchSummierenAuf: idActive
        }
      })
  }

  completedSearch = (e) =>{
    this.setState({
      search: e.target.value.toLowerCase()
    })
  }

 render() {
  return (
    <Query
      query = {AllProduct_Artikel}
      variables = {{id: this.props.intern}}
      fetchPolicy = 'network-only'
      onCompleted = {this.onCompleted}
      errorPolicy = "all"
      onError = {() => console.log('ups..error in product/bruch')}
      displayName = {"Bruch"}>
      {({error, data, networkStatus, refetch}) => {
          if (networkStatus === 4) return "Refetching...";
          if (error) return (
            <div>
              Error:
              <button onClick={() => window.location.reload()}>Refetch!</button>
            </div>
          )
          console.log(data);
          return (
               <Query
                 query = {Active}
                 variables = {{Intern: this.state.idActiveElement}}
                 fetchPolicy = 'network-only'
                 onCompleted = {this.onCompletedActive}
                 errorPolicy = "all"
                 onError = {() => console.log('ups..error in product/bruch')}
                 displayName = {"Bruch"}>
                 {({error, data, networkStatus, refetch}) => {
                     if (networkStatus === 4) return "Refetching...";
                     if (error) return (
                       <div>
                         Error:
                         <button onClick={() => window.location.reload()}>Refetch!</button>
                       </div>
                     )
                     return (
                       <Query
                         query = {List}
                         variables = {{search: this.state.search}}
                         fetchPolicy = 'network-only'
                         onCompleted = {this.onCompletedList}
                         errorPolicy = "all"
                         onError = {() => console.log('ups..error in product/bruch')}
                         displayName = {"Bruch"}>
                         {({error, data, networkStatus, refetch}) => {
                             if (networkStatus === 4) return "Refetching...";
                             if (error) return (
                               <div>
                                 Error:
                                 <button onClick={() => window.location.reload()}>Refetch!</button>
                               </div>
                             )
                             console.log(data);
                             return (
                               <Mutation mutation={updateProductArticle}>
                                 {updateArticle => (
                               <Row style={{padding: "10px 15px 0 15px"}}>
                                <Col lg={4}>
                                 <Items
                                   isOpen={this.state.isOpenModal}
                                   onAfterOpen={this.afterOpenModal}
                                   onRequestClose={this.closeModal}
                                   onClickCLoseModal={this.closeModal}
                                   onClickOpenModal = {this.openModal}
                                   activeValue={this.state.activeElement}
                                   listItems={this.state.listItems}
                                   changeActiveName={this.changeActiveName.bind(this, updateArticle)}
                                   completedSearch={this.completedSearch}
                                   titleName={"Brunch"}

                                   onChange={this.getValueOfInput}
                                   onBlur={this.updateProductLists}

                                   isSearch = {this.isSearch}
                                   />
                                   <div>
                                   <Input
                                     text="Verwendete Teile des Bruchs Fur Dliesen Artikle"
                                     type="number"
                                     onChange={this.getValueOfInput}
                                     onBlur = {this.update.bind(this, updateArticle)}
                                     name={"BruchVerwendeteTeile"}
                                     value={this.state.BruchVerwendeteTeile}
                                     className='input_bruch_article'/>

                                   <Col onClick={this.updateCheckBox.bind(this, updateArticle)}>
                                     <CheckBox
                                       id={"IsBruchTitel"}
                                       top="15px"
                                       tabIndex="99"
                                       open={this.state.IsBruchTitel}
                                       value={'Bruch-Artikel'}/>
                                   </Col>
                                 </div>
                               </Col>
                                </Row>
                               )}
                               </Mutation>
                             )
                           }}
                         </Query>
                     )
                   }}
                 </Query>
          )
        }
      }
    </Query>
   )
 }
}

export default Bruch;

const ChangeModal = styled.button`
  width: 100%;
  height: 30px;
  border-radius: 6px;
  background-color: #ffffff;
  border: 1px solid #ffffff;
  float: right;
  box-shadow: 0 2px 2px 0 rgba(0,0,0,0.1);
`;


// if(this.props.AllProduct_Artikel.loading){return null}
// if(this.props.AllProduct_Artikel.error){return this.props.AllProduct_Artikel.refetch()}
//
//
// <Row style={{padding: "10px 15px 0 15px"}}>
//  <Col lg={4}>
//   <Dropdown
//     text="Bruch"
//     style={{zIndex: 9, width: '100%'}}
//     list={[1,2,3]}
//     gruppeid={1}
//     onBlur={this.isFunc}
//     addDropDown={this.isFunc}/>
//   <Input
//     text="Verwendete Teile des Bruchs Fur Dliesen Artikle"
//     type="number"
//     onChange={this.getValueOfInput}
//     onBlur={this.getValueOfInputBlur}
//     name="BruchVerwendeteTeile"
//     value={this.state.BruchVerwendeteTeile}
//     className='input_bruch_article'/>
//   <Col onClick={this.changeValueOnCheckbox}>
//     <CheckBox
//       id="IsBruchTitel"
//       top="15px"
//       onClick={this.changeValueOnCheckbox}
//       tabIndex="99"
//       open={this.state.IsBruchTitel}
//       value={'Bruch-Artikel'}/>
//   </Col>
//  </Col>
// </Row>
//
//
// const graph = compose(
//    graphql(AllProduct_Artikel, {
//     options: (props) => ({
//       fetchPolicy: 'network-only',
//         variables: {
//           id: props.intern,
//         }
//       }),
//     name: "AllProduct_Artikel",
//   }),
// 	graphql(updateProductArticle, {name: "updateProductArticle"}),
// )(Bruch);
