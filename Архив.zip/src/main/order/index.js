
import React from 'react';
import {Route, Switch} from 'react-router-dom';

import CreateOrder from './createOrder/index';
import EditOrder from './editOrder/index';
import Overview from './overview/index';

export default ({ childProps }) =>
  <Switch>
    <Route path="/order/create" component={CreateOrder} props={childProps} />
    <Route path="/order/edit" component={EditOrder} props={childProps} />
    <Route path="/order/overview" component={Overview} props={childProps} />
  </Switch>;
        