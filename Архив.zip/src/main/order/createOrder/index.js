import React, { Component } from 'react';
import {  Row, Col} from 'react-bootstrap';
import styled from 'styled-components'
import {Route, Switch} from 'react-router-dom';

import Items from  '../../../components/container/items/Items'
import Menu from '../../../components/container/Menu'
import InfoList from '../../../components/container/infoList/InfoList'

import Order from './order/index.js'

//Menu obj

const menuObj = [
  {
    name: 'Create',
    link: '/order/create'
  },
  {
    name: 'Edit',
    link: '/order/edit '
  },
  {
    name: 'Overview',
    link: '/order/overview'
  }
];
const additionalMenuObj = [
  {
    name: 'Order',
    link: '/order/create/order'
  },
  {
    name: 'Default',
    link: '/order/create/default '
  }
]

class CreateOrders extends React.Component {
  state = {id: 3}

  changeId = () =>{
    this.setState({id: this.state.id + 1})
  }

  changeSearch = () =>{

  }
  render() {
    const newArr=[[1,2], [3,4]];

    return (
      <Row>
        <Col lg = {3}>
          <Items
            name="Order"
            names={['Id:', 'Order:']}
            widths = {['25%', '75%']}
            float= {["left", "left"]}
            align="left"
            arr={newArr}
            getSearchValue={this.changeSearch}
            searchValue=''
            filterBtn={true}
            isfilterButton={true}
            firstBtnName = "ADD CUSTOMER"
            secondBtnName = "DELETE CUSTOMER"
          />
        </Col>
        <Col lg = {9}>
          <Body>
            <Menu menuObj={menuObj} text='For exp 1 item =-)'/>
            <InfoList id={this.props.headerId}/>
            <Menu menuObj={additionalMenuObj} isAddition={true}/>
            <div onClick={this.changeId}> +1 </div>
            <Switch>
              <Route path="/order/create/order">
                <Order {...this.props} id={this.state.id}/> 
              </Route>
            </Switch>
            
          </Body>
        </Col>
        

      </Row>
    );
  }
}

export default CreateOrders

const Body = styled.div`
  margin-left: 20px;
`;







