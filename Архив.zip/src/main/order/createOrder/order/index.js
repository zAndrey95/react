import React, { Component } from 'react';
import {  Row, Col} from 'react-bootstrap';
import styled from 'styled-components';
import {Query} from 'react-apollo'

import Input from '../../../../components/simple/Input'
import Button from '../../../../components/simple/Button'
import TableWithEdit from '../../../../components/container/tableWithEdit_SC/TableWithEdit'

import AllOrderCreateGrid from '../../../../functions/query/order/allOrderCreateGrid.js'
import GetOrderDeliveryTime from '../../../../functions/query/order/getOrderDeliveryTime.js'




class Order extends Component {
  render(){
  	const {data} = this.props
    return (
      <MainBlock>
      	<Row>
	      	<Col lg={2}>
	      		<Input text='Order-ref' width='90%'/>
	      	</Col>

	      	<Col lg={2}>
	      		<Input text='Order type' width='90%'/>
	      	</Col>

	      	<Col lg={2}>
	      		<Input text='Delovery time' width='90%'/>
	      	</Col>

	      	<Col lg={3}>
	      		<ButtonBlock>
	      			<Button value='No Order' className='red-btn'/>
	      		</ButtonBlock>
	      	</Col>

	      	<Col lg={3}>
	      		<ButtonBlock>
	      			<Button value='Create Order'/>
	      		</ButtonBlock>
	      	</Col>
      	</Row>

      	<Row>
      		<TableWithEdit data={data}/>
      	</Row>
      </MainBlock>
    );
  }
}


function getQuery(WrappedComponent) {
   class HOCQuery extends React.Component {
   	render() {
      return <Query
	    query={AllOrderCreateGrid}
	    fetchPolicy={'network-only'}
	    variables = {{
        TempLS: 0,
        OfferID:  0,
        id: this.props.id,
        date: '2018-10-10',
        table: "3",
        VorgabeLieferschein: 1,
        LinkOrder: 3
      }}>
	    {({ loading,error, data}) => {
	      if (loading) return <WrappedComponent data={[]}/>
	      if (error) return <span>{error}</span>
	      return <WrappedComponent data={data.allOrderCreateGrid} deleteTable={this.deleteTable}/>
	    }}
	  </Query>
    }
  }
  return HOCQuery;
}

export default getQuery(Order)

const ButtonBlock = styled.div`
	width: 90%;
	margin-top: 26px;
`;

const MainBlock = styled.div`

`;