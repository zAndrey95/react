import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import Input from '../../../../../../../@appElements/input/Input.js';

import './Cahassist.css';

class Cahassist extends Component {
  constructor() {
    super();
    this.state = {

  }}

    render() {
      const {getOrderUpdateOrderAllInputs} = this.props;
    return (
    <div>
      <Row>
        <Col lg={2}>
          <Input
            text="Cash register No." 
            type="text" 
            value={getOrderUpdateOrderAllInputs.CashAssistKasse} 
            name="telefong" 
            onBlur={this.updateCustomer} 
            onChange={this.getValueOfInput}
          />
        </Col>
        <Col lg={2} lgOffset={1}>
          <Input
            text="Receipt No." 
            type="text" 
            value={getOrderUpdateOrderAllInputs.CashAssistBelegNr} 
            name="telefong" 
            onBlur={this.updateCustomer} 
            onChange={this.getValueOfInput}
          />
        </Col>
      </Row>

      <Row>
        <Col lg={2}>
          <Input
            text="Delivery time" 
            type="text" 
            value={getOrderUpdateOrderAllInputs.CALieferzeit} 
            name="telefong" 
            onBlur={this.updateCustomer} 
            onChange={this.getValueOfInput}
          />
        </Col>
        <Col lg={2}  lgOffset={1}>
          <Input
            text="Delivery type" 
            type="text" 
            value={getOrderUpdateOrderAllInputs.CALieferart} 
            name="telefong" 
            onBlur={this.updateCustomer} 
            onChange={this.getValueOfInput}
          />
        </Col>
      </Row>

      <Row>
        <Col lg={5}>
          <Input
            text="CashAssist user" 
            type="text" 
            value={getOrderUpdateOrderAllInputs.CABenutzer} 
            name="telefong" 
            onBlur={this.updateCustomer} 
            onChange={this.getValueOfInput}
          />
        </Col>
      </Row>
    </div>
    );
  }
}


export default Cahassist;