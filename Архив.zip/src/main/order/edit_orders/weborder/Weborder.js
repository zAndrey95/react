import React, { Component } from 'react';
import {Col} from 'react-bootstrap';

import Input from '../../../../../../../@appElements/input/Input.js';

import './Weborder.css';

class Weborder extends Component {
  constructor() {
    super();
    this.state = {

  }}

    render() {
    return (
    <div >
      <Col lg={3}>
        <Input
          text="Mobile" 
          type="text" 
          value={''} 
          name="telefong" 
          onBlur={this.updateCustomer} 
          onChange={this.getValueOfInput}
        />
      </Col>
    </div>
    );
  }
}


export default Weborder;