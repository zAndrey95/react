import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { NavLink } from 'react-router-dom'
import {Route, Switch} from 'react-router-dom';
import { withApollo, Query, Mutation } from 'react-apollo'
import { graphql, compose } from 'react-apollo';

import CheckBox from '../../../../../../../@appElements/checkBox/CheckBox.js';
import SimpleDropdown from '../../../../../../../@appElements/dropDown/SimpleDropdown'
import HeaderTable from '../../../../../../../@appElements/table/HeaderTable.js'
import Table from '../../../@components/tableWithChangeItem/TableWithChangeItem.js'
import Input from '../../../../../../../@appElements/input/Input.js'
import Button from'../../../../../../../@appElements/button/Button.js'
import InputWithDropdown from '../../../@components/inputWithDropdown/InputWithDropdown.js'
import Modal from '../../../../../../../@appElements/modal/Modal.js';
import Calendar from '../../../../../../../@appElements/calendar/Calendar.js';

import SaveChangesModal from'./modal/SaveChangesModal.js'




import Plus_green from '../../../../../../../@appElements/item_Img/Plus_green.js'
import Minus_red from '../../../../../../../@appElements/item_Img/Minus_red.js'
import Ok_green from '../../../../../../../@appElements/item_Img/Ok_green.js'
import Settings from '../../../../../../../@appElements/item_Img/Settings.js'
import Cancel_red from '../../../../../../../@appElements/item_Img/Cancel_red.js'
import DeliveryBox_yellow from '../../../../../../../@appElements/item_Img/DeliveryBox_yellow.js'

import delivery from '../../../img/delivery.png';
import cancel_red from '../../../img/cancel_red.svg';
import ok_green from '../../../img/ok_green.svg';
import add_color from '../../../img/add_color.svg';
import delete_color from '../../../img/delete_color.svg';
import edit from '../../../img/edit.svg';

import GetOrderDeliveryTime from '../../../../../../../functions/query/order/getOrderDeliveryTime.js'
import view_fkOrderTypes from '../../../../../../../functions/query/order/view_fkOrderTypes.js'
import AllOrderCreateGrid from '../../../../../../../functions/query/order/allOrderCreateGrid.js'



import AllOrderRecalculationValues from '../../../../../../../functions/query/order/allOrderRecalculationValues.js'
import EditNewOrder from '../../../../../../../functions/mutation/order/editNewOrder.js'

import AllorderTableOnChangeInput from '../../../../../../../functions/query/order/allorderTableOnChangeInput.js'

import CreateTemporaryOrder from '../../../../../../../functions/mutation/order/createTemporaryOrder.js'

import AllCheckOrders from '../../../../../../../functions/query/order/allCheckOrders.js'

import './Order.css';

const dropDownType = [{type: 'Order'},{type: 'Special order'},{type: 'Additional order'},{type: 'Return'},{type: 'Credit order'},{type: 'Catering'}]


class Order extends Component {
  constructor(){
    super();
      this.state = {
        date: new Date(),
        allOrderCreateGrid:[],
        orderType: 1,
        allOrderCreateGridMemory:[],
        tableIndex: -1,
        searchArtikel: '',
        isOrder: false,
        id: 1,
        isOpenSaveChangesModal: false,
        isSaveChangesModal: false,
        tableSearch: ''
      }
      this.mergeInput = [];
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if(!nextProps.GetOrderUpdateOrderGridWithPositions.loading){
      if(nextProps.id !== prevState.id){
        console.log(nextProps)
      return {
        allOrderCreateGrid: !nextProps.GetOrderUpdateOrderGridWithPositions.loading ? nextProps.GetOrderUpdateOrderGridWithPositions.getOrderUpdateOrderGridWithPositions: [],
        allOrderCreateGridMemory: !nextProps.GetOrderUpdateOrderGridWithPositions.loading ? nextProps.GetOrderUpdateOrderGridWithPositions.getOrderUpdateOrderGridWithPositions:[],
        id: nextProps.id,
        isCreateOrder: false
      }
    }
    }
  }

  //Call in left grid by ref, when client changes table. Show modal with yes and no. yes create this.orderCreate(), no return null
  checkSavesChanges = (boolean) =>{
   const {allOrderCreateGrid, allOrderCreateGridMemory} =this.state
    if(allOrderCreateGrid !== allOrderCreateGridMemory){
     this.setState({isSaveChangesModal: true})
     return false
   }
   else {
    return true
   }
  }

  onTrueCheckSavesChanges = async() =>{
    const {temporaryOrderIndex, temporaryOrderIntern, getItemInListWithCustomerEdit} = this.props;
    this.sendOrderDataIntoDatabase();
    this.setState({isSaveChangesModal: false})
    
  }

  onFalseCheckSavesChanges = () =>{
    const {temporaryOrderIndex, temporaryOrderIntern, getItemInListWithCustomerEdit} = this.props;
    
    this.setState({isSaveChangesModal: false, allOrderCreateGrid: this.state.allOrderCreateGridMemory})
    
  }

  closeSaveChangesModal = () =>{
    this.setState({isSaveChangesModal: false})
  }

  deleteTable = (index) =>{
    let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    cloneArrayone.splice(index, 1);

    this.setState({allOrderCreateGrid: cloneArrayone})
  }

  addNewRecord = (index) =>{
    let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    const newArray = {
      Addition: '',
      ArtikelNr: '',
      Bezeichnung: '',
      PreisLieferung: '',
      Total: '',
      Menge: '',
      RabattP: '',
      MWStCode: ''

    }
    cloneArrayone.unshift(newArray);
    this.setState({allOrderCreateGrid: cloneArrayone})
  }

  validationInSaveChangesModal = (boolean) =>{
    
  }

  changeInputWithDropdownValue = (e) => {
    let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    const {tableIndex} = this.state
    cloneArrayone[tableIndex].ArtikelNr = e.target.value;
    this.setState({allOrderCreateGrid: cloneArrayone, searchArtikel: e.target.value })
    
  }


  //******************************ALL FUNCTIONS TO CREATE ORDER******************************//

  createNewOrder = async () => { //Its MAIN FUNCTION TO CREATE ORDER. SEND INTO BUTTON "ORDER CREATE
    const {AllCheckOrders} = this.props;
    try {
      await this.validationOnCreateNewOrder();
    } catch (err) {
      console.log(err)
    }
  }

  validationOnCreateNewOrder = () =>{ //Second Function Check Order List. When we have [] load 
    const {AllCheckOrders} = this.props;
    if(!AllCheckOrders.loading){
      if(AllCheckOrders.allCheckOrders.length >= 1){ 
        this.setState({isOpenOrderListModal: true})
      }
      else {
        this.sendOrderDataIntoDatabase()}
    }
  }

  sendOrderDataIntoDatabase = async() => {
  console.log('gg') //Get Data Into BD.
    const validation = this.validationMergeValue();  // !Merge <= 0
    if(!validation) {
      this.setState({isOpenWarningModal: true}
    )} //Second validation. Field with Menge must not equal 0 
    else{
      this.setState({isSaveChangesModal: true})
      let variables = [];
      let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
      cloneArrayone.forEach((item)=>{
        const array = {
          LinkArtikel: item.LinkArtikel,
          Menge: item.Menge,
          Total: item.PreisLieferung,
          RabbattP: item.RabattP ? item.RabattP : null,
          MWStCode: item.MWStCode ? item.MWStCode: 2,
          IndTextDeliveryNote: item.Bezeichnung,
          IndTextProduction: 6
        }
        variables.push(array);
      })

           this.props.EditNewOrder({
        variables: {
          userId: 1,
          orderType: 1,
          date: this.props.date,
          Intern: this.props.customerId,
          userTable: String,
          editOrderId: this.props.id,
          variables: variables
        },
      }).then((data) => {
          const editNewOrder = data.data.editNewOrder[0];
          console.log(editNewOrder.ErrorCode);
          if(editNewOrder.ErrorCode){
            console.log(editNewOrder.ErrorText)
          }
          else{
          this.setState({isSaveChangesModal: false})
          } 
        }).catch((err)=>{console.log(err)})
       
       
      
      this.setState({allOrderCreateGridMemory: this.state.allOrderCreateGrid})
    }
  }

  validationMergeValue = () => { //Validation on Menge. When Menge nothing prodecure cant run
    let validation = false;
    for (let n of this.state.allOrderCreateGrid) {
      if(n.Menge == 0 || n.Menge == null){
        validation = false;
        break;
      }
    validation = true;
    }
    return validation;
  }

  validationOrderListModal =(boolean)=>{ //Validation with Promise. If user press OK in Modal boolean = true and run func this.sendOrderDataIntoDatabase
    let promise = new Promise((resolve, reject) => {
      resolve(boolean);
    });

    promise.then(
      result => {
          this.setState({isOpenOrderListModal: false})
          this.sendOrderDataIntoDatabase();
      },
      error => {
        console.log(error)
      }
    );
  }

  onClickInputWithDropdown = (index, item) =>{
    let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    const {tableIndex} = this.state
    cloneArrayone[tableIndex].ArtikelNr = item.ArtikelNr
    cloneArrayone[tableIndex].Bezeichnung = item.Bezeichnung
    cloneArrayone[tableIndex].PreisLieferung = item.Betrag1
    cloneArrayone[tableIndex].LinkArtikel = item.Intern
    cloneArrayone[tableIndex].RabbattP = item.Intern
    this.setState({allOrderCreateGrid: cloneArrayone})
    console.log(item)
  }

  changeTableByInput = (index, e) =>{
    var cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    const name = e.target.name
    console.log(e.target.name)
    cloneArrayone[index][name] = e.target.value;
    cloneArrayone[index].Total = this.changeMerge(cloneArrayone[index]);;
    
    
    this.setState({allOrderCreateGrid: cloneArrayone});
  }

//****************************** END FUNCTIONS TO CREATE ORDER******************************//


  indexOnClickTable = (index) => {
    this.setState({tableIndex: index})
  }

  changeNumbersOnZero = () =>{
    var cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    for (const key in cloneArrayone){
      cloneArrayone[key].Menge = 0
      cloneArrayone[key].Total = 0
      
    }
    this.setState({allOrderCreateGrid: cloneArrayone})
  }

  changeMerge = (cloneArrayone) =>{

    let sum = cloneArrayone.Menge * cloneArrayone.PreisLieferung;
    let total = Math.round(sum * 100) / 100
    return total
  }


  openSaveChangesModal = () =>{
    this.setState({isOpenSaveChangesModal: true})
  }

   onClickTable = (index, e) =>{
    this.setState({tableIndex: index})
  }

  getDate = () =>{}

  changeTableSearch = (e) =>{
    this.setState({tableSearch: e.target.value})
  }

  onPressEnter =  (e) => {
    const {tableIndex,allOrderCreateGrid} = this.state;
    console.log(e)
    if(e.which === 13){
      console.log('this enter')
      
     // e.target.select();
      const isLast = tableIndex === allOrderCreateGrid.length - 1;
      if(isLast){
        this.addNewRecord(isLast);
        console.log(this.mergeInput)
        
      }
      else {
        this.selectAndFocusMergeInput();
      }
    }
  }

  selectAndFocusMergeInput = () =>{
    const {tableIndex} = this.state;
    this.mergeInput[tableIndex + 1].focus();
    this.mergeInput[tableIndex + 1].select();
    this.setState({tableIndex: tableIndex + 1})
  }

  componentDidMount() {
    this.props.onRef(this)
    console.log('componentDidMount')
  }
  componentWillUnmount() {
    this.props.onRef(undefined)
  }
  

  render() {
    console.log(this.state.allOrderCreateGridMemory)
    return(
      <Row>
        <Col lg={12}>
          <Modal
            isOpen={this.state.isSaveChangesModal}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            width={"350px"}
            height={"220px"}
            component={<SaveChangesModal 
              closeModal={this.closeSaveChangesModal} 
              checkSavesChanges={this.checkSavesChanges} 
              onFalseCheckSavesChanges={this.onFalseCheckSavesChanges}
              onTrueCheckSavesChanges={this.onTrueCheckSavesChanges}
            />}
        />
                <Col lg={12} style={{padding: '0 0 10px 0'}}>
                  
                  <Col lg={2}>
                    <Input
                      text="Order-ref"  
                      type="text" 
                      value={1} 
                      name="search" 
                      onBlur={null} 
                      onChange={null}
                      width = '90%'
                    />
                  </Col>

                  <Col lg={2}>
                        <SimpleDropdown text="Order tupe"
                          row={"type"}
                          row1={false}
                          style={{zIndex: 1, margin: '-2px 0px 0px 0px'}} 
                          list={dropDownType} 
                          gruppeId={0} 
                        />
                  </Col>

                  <Col lg={2}>
                    <Calendar
              getDate={this.getDate} 
              style={{margin: '17px 0px 6px 0px', width: '95%'}}

        />
                  </Col>

                  <Col lg={2}>
                    <Input
                      text="Delovery time"  
                      type="text" 
                      value={1} 
                      name="search" 
                      onBlur={null} 
                      onChange={null}
                      width = '90%'
                    />
                  </Col>

                  <Col lg={2}>
                    <Input
                      text="Customer"  
                      type="text" 
                      value={1} 
                      name="search" 
                      onBlur={null} 
                      onChange={null}
                      width = '90%'
                    />
                  </Col>

                  <Col lg={2}>
                     <Button 
                      background="#99d5d7" 
                      top="39px" 
                      paddingTop="12px"
                      width = '93%'
                      height="40px"
                      size="16px"
                      text='Save changes'
                      onClick={async () => { await this.sendOrderDataIntoDatabase()}} 
                      />
                  </Col>
                </Col>
        </Col>


          <Query
                      query={AllorderTableOnChangeInput}
                      variables={{search: this.state.searchArtikel}}
                    > 
                    {({ loading, error, data, refetch, networkStatus }) => {
                      if (networkStatus === 4) return "Refetching!";
                      if (error) return `Error!: ${error}`;
                      return (
         <Table     tableSearch={this.state.tableSearch}
                    changeTableSearch={this.changeTableSearch}
                    orderType = {this.state.orderType}
                    changeTableByInput= {this.changeTableByInput}
                    changeNumbersOnNegative= {this.changeNumbersOnNegative}
                    allOrderCreateGrid={this.state.allOrderCreateGrid}
                    onClick={this.indexOnClickTable} 
                    delete={this.deleteTable}
                    testFunctionToInput= {this.testFunctionToInput}
                    changeSearchArtikel={this.changeSearchArtikel}
                    inputValue = {this.state.inputValue}
                    list={data.allorderTableOnChangeInput ? data.allorderTableOnChangeInput : null} 
                    onClickTable={this.onClickTable}
                    addNewRecord={this.addNewRecord}
                    changeInputWithDropdownValue={this.changeInputWithDropdownValue}
                    onClickInputWithDropdown={this.onClickInputWithDropdown}
                    mergeInput={this.mergeInput}
                    //FFFFF
                    names={[
                      "Article no.", 
                      "Quantity", 
                      "Description", 
                      "Addition",
                      "Price",
                      "Total",
                      "Discount",
                      "VAT"
                    ]} 
                    widths={[
                      '10%',
                      '10%',
                      '20%', 
                      '10%',
                      '10%',
                      '10%',
                      '10%',
                      '20%',
                    ]} 
                  />   
                   );
                    }}
                    </Query>                  
      </Row>
    );
}
}




const graph = compose(
  graphql(EditNewOrder, {
    options: {
      refetchQueries: (mutationResult) => [
        console.log(mutationResult)
      ],
    },
    name: "EditNewOrder"
  })
)(Order);

export default withApollo (graph)
