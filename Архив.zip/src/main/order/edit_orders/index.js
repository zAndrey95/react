import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { NavLink } from 'react-router-dom'
import {Route, Switch} from 'react-router-dom';
import { graphql, compose } from 'react-apollo';

import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';
import Dropdown from '../../../../../../@appElements/dropDown/Dropdown'

import Message from '../../img/message.png';
import Icon_fax from '../../img/icon_fax.png';
import Icon_smartphone_screen from '../../img/icon_smartphone_screen.png';
import agenda from '../../img/agenda.png';

import Order from './order/Order.js'
import Note from './note/Note.js'
import Cahassist from './cahassist/Cahassist.js'
import Weborder from './weborder/Weborder.js'
import Menu from './Menu.js';
import HeaderOrder from '../HeaderOrder.js'


import './Edit_orders.css';

import GetOrderUpdateOrderGridWithPositions from '../../../../../../functions/query/order/getOrderUpdateOrderGridWithPositions.js'
import GetOrderUpdateOrderAllInputs from '../../../../../../functions/query/order/getOrderUpdateOrderAllInputs.js'

const InitialState = {
  CashAssistKasse: '',
  CashAssistBelegNr: '',
  CALieferzeit:'',
  CALieferart:'',
  CABenutzer:''
}
class Edit_orders extends Component {
 constructor() {
    super();
    this.state = {
      change:true,

  }}
  onTrueChange(){
    this.setState({change: true})
  }
   onFalseChange(){
    this.setState({change: false})
  }
    render() {
      const { GetOrderUpdateOrderAllInputs,  GetOrderUpdateOrderGridWithPositions} =this.props;
    return (
    <div>
      <HeaderOrder id={this.props.customerId}/>
      <Col lg={12} > <Menu id={this.props.customerId}/> </Col>
      <Col lg={12}>
             <Switch>
                <Route path={'/order/edit/order'}  render={props =>
                            <Order
                            GetOrderUpdateOrderGridWithPositions= {GetOrderUpdateOrderGridWithPositions}
                            onRef={this.props.onRef}
                            id={this.props.id}
                            customerId={this.props.customerId}
                            date={this.props.date}
                            temporaryOrderIndex = {this.props.temporaryOrderIndex}
                            temporaryOrderIntern = {this.props.temporaryOrderIntern}
                            getItemInListWithCustomerEdit={this.props.getItemInListWithCustomerEdit}
                            /> }
                />
                <Route path={'/order/edit/note'} render={props =>
                            <Note
                            /> }
                />
                <Route path={'/order/edit/cashassist'} render={props =>
                            <Cahassist
                            id={this.props.id}
                            getOrderUpdateOrderAllInputs={ 
                              GetOrderUpdateOrderAllInputs ?
                                GetOrderUpdateOrderAllInputs.length < 1 ? GetOrderUpdateOrderAllInputs.getOrderUpdateOrderAllInputs[0] : InitialState 
                              : InitialState}
                            /> }
                />

                <Route path={'/order/edit/web_order'} render={props =>
                            <Weborder
                            id={this.props.id}
                            /> }
                />
               
                />
              </Switch>
        </Col>  
    </div>
    );
  }
}

const graph = compose(
  graphql(GetOrderUpdateOrderAllInputs, {
    options: (props) => ({
      fetchPolicy: 'network-only',
      variables: {
        id: props.id
      }
    }),
    name: "GetOrderUpdateOrderAllInputs",
  }
  ),
  graphql(GetOrderUpdateOrderGridWithPositions, {
    options: (props) => ({
      fetchPolicy: 'network-only',
      variables: {
        id: props.id
      }
    }),
    name: "GetOrderUpdateOrderGridWithPositions",
  }
  ),
)(Edit_orders);

export default graph

