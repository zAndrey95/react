import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';

import Textarea from '../../../../../../../@appElements/textarea/Textarea.js';
import Calendar from '../../../../../../../@appElements/calendar/Calendar.js';


class Note extends Component {

  constructor() {
    super();
    this.state={
      date: new Date()
    }
  }
 getDate = (date) => {
    this.setState({date: date});
    
  }
  render() {
    return (
      <Row >
      <Col lg={5}>
        <Textarea 
          text=" Note" 
          width='70%'
          value={''}
          onBlur={null}
          name="note"
          onChange={null}
          style={{margin: '30px 0px 10px 0px'}}
        />
        </Col>
      </Row>
    );
  }
}


export default Note;