import React, { Component } from 'react';
import Modal from 'react-modal';
import { graphql, compose } from 'react-apollo';
import { NavLink} from 'react-router-dom';
import {Route, Switch} from 'react-router-dom';
import {Col, Row} from 'react-bootstrap';
import styled from 'styled-components';


import HeaderTable from '../../../../../../../@appElements/table/HeaderTable.js'
import Table from '../../../../../../../@appElements/table/Table.js'
import Input from '../../../../../../../@appElements/input/Input.js'
import Plus_green from '../../../../../../../@appElements/item_Img/Plus_green.js'
import Minus_red from '../../../../../../../@appElements/item_Img/Minus_red.js'
import Edit_blue from '../../../../../../../@appElements/item_Img/Edit_blue.js'
import Calendar from '../../../../../../../@appElements/calendar/Calendar.js';
import Button from'../../../../../../../@appElements/button/Button.js'
import CheckBox from '../../../../../../../@appElements/checkBox/CheckBox.js';
import Title from '../../../../../../../@appElements/title/Title.js';
import Dropdown from '../../../../../../../@appElements/dropDown/Dropdown';
import Print from '../../../../../../../@appElements/item_Img/Print';
import Search from '../../../../../../../@appElements/item_Img/Search';
import Agenda from '../../../../../../../@appElements/item_Img/Agenda';
import Settings from '../../../../../../../@appElements/item_Img/Settings.js'



const MenuBlock = styled.div`
  padding: 14px 0 0 0;
`;

class Default extends Component {
  getDate = () => {

  }
  render() {
    const newArr=[];
    newArr.forEach((item)=>{
      newArr.push([item.Artikle, item.Bezeichnung, item.Price,item.Description])
    })
    return(
      <div style={{padding: "0 0 0 15px"}}>
        <Row>
          <MenuBlock>
          <Col lg={2}>
            <Calendar
              getDate={this.getDate}
              style={{width: "90%"}}
              daysStep={1}
            />
          </Col>

          <Col lg={2}>
            <Calendar
              getDate={this.getDate} 
              style={{width: "90%"}}
              daysStep={6}
            />
          </Col>

          <Col lg={4}>
            <Dropdown 
              style={{zIndex: 9}} 
              list={[1,2,3]} 
              gruppeid={1} 
            />
          </Col>

          <Col lg={1}>
            <Print
              top="3px"
              left="37px"
            />
          </Col>

          <Col lg={1}>
            <Search
              top="3px"
              left="20px"
            />
          </Col>

          <Col lg={1}>
            <Agenda
              top="3px"
              left="10px"
            />
          </Col>
          </MenuBlock>
        </Row>

        <Row>
         <Col lg={4}>
          <Title text="Delivered"/>        
         </Col>

         <Col lgOffset={2} lg={4}>
          <Title text="Assortment"/> 
         </Col>
        </Row>

        <Row>
          <Col lg={4}>
          <Dropdown 
            text="Default delivery" 
            style={{zIndex: 11}} 
            list={[1,2,3]} 
            gruppeId={1} 
            onBlur={null} 
            deleteDropDown={null} 
            addDropDown={null} 
            updeteDrop={null}
          />
          </Col>

          <Col lg={2}>
            <CheckBox 
              value={'Creete autoatical'} 
              open={false}
              top = '50px'
              left = '60px'
            /> 
          </Col>

          <Col lg={1}>
            <CheckBox 
              value={'Gruppe'} 
              open={false}
              top = '50px'
              left = '30px'
            /> 
          </Col>

          <Col lg={1}>
            <CheckBox 
              value={'Kleinkunden'} 
              open={false}
              top = '50px'
              left = '30px'
            /> 
          </Col>

          <Col lg={1}>
            <CheckBox 
              value={'Grosskunden'} 
              open={false}
              top = '50px'
              left = '60px'
            /> 
          </Col>
        </Row>

        <Row style={{padding: "50px 0 0 0"}}>
          <Col lg={4} >
            <Title text="Delivery periods"/>
            <Col lg={9} lgOffset={1}>
              <span> Jeden Montag, Dienstag, Donnerstag  </span>
            </Col>
            <Col lg={4} >
              <Button 
                color="#4a90e2" 
                top="39px" 
                paddingTop="2px"
                height="30px"
                size="16px"
                text={<Row><Col lg={3}><Settings/></Col> <Col style={{margin: "6px 0 0 0"}} lg={9}>Availability</Col></Row>}
              /> 
            </Col>
          </Col>
        </Row>

        <Row>
          <HeaderTable 
          items={[
            <Plus_green
              onClick={null}
              top="9px"
            />, 
            <Minus_red
              top="11px"
            />, 
            <CheckBox 
              value={'Flexible orders'} 
              open={false}
              left = '30px'
              top = '7px'
            />,
            <CheckBox 
              value={'Enable splitting'} 
              open={false}
              left = '30px'
              top = '7px'
            />,
            <Input
              type="text" 
              value={1} 
              name="search" 
              onBlur={null} 
              onChange={null}
            />
          ]} 
          widths={["7%", "10%","30%","30%","23%"]}/>   

        <Table 
          onClick={this.indexOnClickTable} 
          names={[
            "Nummer", 
            "Description", 
            "Mon", 
            "Tue",
            "Wed",
            "Thu",
            "Fri",
            "Sat",
            "Sun",
            "Information"
          ]} 
          widths={[
            '10%',
            '30%',
            '7%', 
            '7%',
            '7%',
            '7%',
            '7%',
            '7%',
            '7%',
            '11%',
          ]} 
          arr={newArr}/>
        </Row>
      </div>
    );
  }
} 
export default Default