import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { NavLink } from 'react-router-dom'
import {Route, Switch} from 'react-router-dom';
import { withApollo, Query, Mutation, graphql, compose } from 'react-apollo'
import Calendar from 'react-calendar';

import CheckBox from '../../../../../../../@appElements/checkBox/CheckBox.js';
import SimpleDropdown from '../../../../../../../@appElements/dropDown/SimpleDropdown'
import HeaderTable from '../../../../../../../@appElements/table/HeaderTable.js'
import Table from '../../../@components/tableWithChangeItem/TableWithChangeItem.js'
import Input from '../../../../../../../@appElements/input/Input.js'
import Button from'../../../../../../../@appElements/button/Button.js'
import InputWithDropdown from '../../../@components/inputWithDropdown/InputWithDropdown.js'
import Modal from '../../../../../../../@appElements/modal/Modal.js';

import OrderListModal from'./modal/OrderListModal.js'
import WarningModal from'./modal/WarningModal.js'
import ShippingCostModal from'./modal/ShippingCostModal.js'
import OrderCreatingModal from'./modal/OrderCreatingModal.js'
import LoadingModal from'./modal/LoadingModal.js'



import Plus_green from '../../../../../../../@appElements/item_Img/Plus_green.js'
import Minus_red from '../../../../../../../@appElements/item_Img/Minus_red.js'
import Ok_green from '../../../../../../../@appElements/item_Img/Ok_green.js'
import Settings from '../../../../../../../@appElements/item_Img/Settings.js'
import Cancel_red from '../../../../../../../@appElements/item_Img/Cancel_red.js'
import DeliveryBox_yellow from '../../../../../../../@appElements/item_Img/DeliveryBox_yellow.js'

import delivery from '../../../img/delivery.png';
import cancel_red from '../../../img/cancel_red.svg';
import ok_green from '../../../img/ok_green.svg';
import add_color from '../../../img/add_color.svg';
import delete_color from '../../../img/delete_color.svg';
import edit from '../../../img/edit.svg';

import GetOrderDeliveryTime from '../../../../../../../functions/query/order/getOrderDeliveryTime.js'
import view_fkOrderTypes from '../../../../../../../functions/query/order/view_fkOrderTypes.js'
import AllOrderCreateGrid from '../../../../../../../functions/query/order/allOrderCreateGrid.js'


import AllOrderRecalculationValues from '../../../../../../../functions/query/order/allOrderRecalculationValues.js'
import CreateNewOrder from '../../../../../../../functions/query/order/createNewOrder.js'

import AllorderTableOnChangeInput from '../../../../../../../functions/query/order/allorderTableOnChangeInput.js'

import CreateTemporaryOrder from '../../../../../../../functions/mutation/order/createTemporaryOrder.js'

import AllCheckOrders from '../../../../../../../functions/query/order/allCheckOrders.js'

import NoOrderOnOrderCreate from '../../../../../../../functions/mutation/order/noOrderOnOrderCreate.js'

import './Order.css';

const dropDownType = [{type: 'Order', id: 1},{type: 'Special order', id: 2},{type: 'Additional order', id:4},{type: 'Return', id:5},{type: 'Credit order', id:6},{type: 'Catering', id: 9}]


class Order extends Component {
  constructor(){
    super();
    this.state = {
        date: new Date(),
        allOrderCreateGrid:[],
        orderType: 1,
        allOrderCreateGridMemory:[],
        tableIndex: -1,
        searchArtikel: '',
        isOrder: false,
        id: 1,
        isOpenOrderListModal: false,
        isOpenWarningModal: false,
        isOpenShippingCostModal: false,
        isOrderCreatingModal: false,
        isCreateOrder: true,
        indexOrderTypeDropdown: 0,
        isOpenLoadingModal: false,
        tableSearch: '',
        mergeIndex: 2
    }
      this.mergeInput = [];
      
  }
  

  static getDerivedStateFromProps(nextProps, prevState) {
    if(!nextProps.AllOrderCreateGrid.loading){
      if(nextProps.id !== prevState.id){
      return {
        allOrderCreateGrid: !nextProps.AllOrderCreateGrid.loading ? nextProps.AllOrderCreateGrid.allOrderCreateGrid: [],
        allOrderCreateGridMemory: !nextProps.AllOrderCreateGrid.loading ? nextProps.AllOrderCreateGrid.allOrderCreateGrid:[],
        id: nextProps.id,
        isCreateOrder: false
      }
    }
    }
  }

  //******************************ALL FUNCTIONS TO CREATE ORDER******************************//

  createNewOrder = async () => { //Its MAIN FUNCTION TO CREATE ORDER. SEND INTO BUTTON "ORDER CREATE
    const {AllCheckOrders} = this.props;
    try {
      await AllCheckOrders.refetch();// Refresh DB where we show all orders on this date. Used in validation
      await this.validationOnCreateNewOrder();
    } catch (err) {
      console.log(err)
    }
  }



  validationOnCreateNewOrder = () =>{ //Second Function Check Order List. When we have [] load 
    const {AllCheckOrders} = this.props;
    if(!AllCheckOrders.loading){
      if(AllCheckOrders.allCheckOrders.length >= 1){ 
        this.setState({isOpenOrderListModal: true})
      }
      else {
        this.sendOrderDataIntoDatabase()}
    }
  }


  sendOrderDataIntoDatabase =  () => { //Get Data Into BD.
    const validation = this.validationMergeValue();  // !Merge <= 0
   if(!validation) {
    this.setState({isOpenWarningModal: true}
    )} //Second validation. Field with Menge must not equal 0 
    else{
          this.setState({isOrderCreatingModal: true})
       this.userCreateNewOrder();
      let variables = [];
      let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;

      cloneArrayone.forEach((item)=>{
        if(item.Menge) {
          const array = {
          LinkArtikel: item.LinkArtikel,
          Menge: item.Menge,
          Total: item.PreisLieferung,
          RabbattP: item.RabattP ? item.RabattP : null,
          MWStCode: item.MWStCode ? item.MWStCode: 2,
          IndTextDeliveryNote: null,
          IndTextProduction: 6
        }
        variables.push(array);
        }
        
      })

           this.props.CreateNewOrder({ //Run PR_CalculationOrder, create new temporary table 
          variables: {
            userId: 1,
            orderType: 1,
            date: this.props.date,
            Intern: this.props.id,
            userTable: String,
            variables: variables
          },

     
        }).then((data) => {
          const createNewOrder = data.data.createNewOrder[0];
          console.log(createNewOrder.ErrorCode);
          if(createNewOrder.ErrorCode){
            console.log(createNewOrder.ErrorText)
          }
          
        }).then(()=> this.props.refetch())
          .then(()=>this.setState({isOrderCreatingModal: false}))
          .then(() => this.setState(this.state))
          .catch((err)=>console.log(err))
         
        
}

         
            
        console.log(this.state.isCreateOrder)
       


     
    
  }

  validationMergeValue = () => {  //Validation on Menge. When Menge nothing prodecure cant run     
    let validation = false;
    for (let n of this.state.allOrderCreateGrid) {
      if(n.Menge){
        validation = true;
        break;
      }
    }
    return validation;
  }

  validationOrderListModal =(boolean)=>{ //Validation with Promise. If user press OK in Modal boolean = true and run func this.sendOrderDataIntoDatabase
    let promise = new Promise((resolve, reject) => {
      resolve(boolean);
    });

    promise.then(
      result => {
          this.setState({isOpenOrderListModal: false})
          this.sendOrderDataIntoDatabase();
      },
      error => {
        console.log(error)
      }
    );
  }

//****************************** END FUNCTIONS TO CREATE ORDER******************************//

//****************************** CLOSE ALL MODAL ******************************//
  closeWarningModal = () =>{ 
    this.setState({isOpenWarningModal: false})
  }

  closeOrderListModal = () =>{
    this.setState({isOpenOrderListModal: false})
  }

  closeShippingCostModal = () =>{
    this.setState({isOpenShippingCostModal: false})
  }

  openShippingCostModal = () =>{
    this.setState({isOpenShippingCostModal: true})
  }

  closeOrderCreatingModal = () =>{
    this.setState({isOrderCreatingModal: false})
  }

//****************************** END CLOSE ALL MODAL ******************************//

//******************************No ORDER******************************//
  noOrder = async () =>{
    try{
      await this.props.NoOrderOnOrderCreate({
        variables: {
          id: this.props.id,
          date: this.props.date
        },
      })
      console.log('gg')
      this.setState({allOrderCreateGrid: []})
      await this.props.deleteListPosition();
    }
    catch(err){
      console.log(err);
    }
  }
//******************************No ORDER******************************//



//*****************************All Functions from Input with Dropdown******************************//
  onClickInputWithDropdown = (index, item) =>{
    let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    const {tableIndex} = this.state
    cloneArrayone[tableIndex].ArtikelNr = item.ArtikelNr
    cloneArrayone[tableIndex].Bezeichnung = item.Bezeichnung
    cloneArrayone[tableIndex].PreisLieferung = item.Betrag1
    cloneArrayone[tableIndex].LinkArtikel = item.Intern
    cloneArrayone[tableIndex].RabbattP = item.Intern
    this.setState({allOrderCreateGrid: cloneArrayone})
    console.log(item)
  }

  onClickTable = (index, e) =>{
    this.setState({tableIndex: index})
  }

  changeInputWithDropdownValue = (e) => {
    let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    const {tableIndex} = this.state
    cloneArrayone[tableIndex].ArtikelNr = e.target.value;
    this.setState({allOrderCreateGrid: cloneArrayone, searchArtikel: e.target.value })
    
  }


//******************************END All Functions from Input with Dropdown******************************//


//*****************************All Temporary Order******************************//
 //ValidationOnClick
  validationOnClickItems  = () => {
    if(this.state.isOrder){
      this.createTemporaryOrder();
    }
  }
  //Create TEMPORARY ORDER. Trasfer into left grip in GetOrder.js
  createTemporaryOrder = () => {
    const {allOrderCreateGrid, allOrderCreateGridMemory} = this.state
    if(this.state.isCreateOrder){ console.log('OrderCreATe')}
      if(allOrderCreateGrid===allOrderCreateGridMemory){
        console.log('True')
      }
      else{
        console.log("Temporary Order Creating ")
        let variables = [];
        let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
        cloneArrayone.forEach((item)=>{
          const array = {
              LinkArtikel: item.LinkArtikel ? item.LinkArtikel : null,
              Menge: item.Menge ? item.Menge : null,
              Total: item.PreisLieferung,
              Betrag: item.RabattP ? item.RabattP : null,
              MWStCode: item.MWStCode ?  item.MWStCode :2,
              Total: item.Total ?  item.Total :0
          }
             variables.push(array);
        });
          this.setState({isOpenLoadingModal: true})
           this.props.CreateTemporaryOrder({
              variables: {
                id: this.props.id,
                TempLS: this.props.procedureCustomersListForCreatingOrdersOnDate.TempLS,
                date: this.props.date,
                variables: variables
                },
            }).then((data)=> console.log(data))
              .then(()=> this.props.refetch())
              .then(()=>this.setState({isOpenLoadingModal: false}))
              .catch((err)=>console.log(err))
 
         


         }
  }

  userCreateNewOrder = () =>{
    this.setState({isCreateOrder: true})
    console.log('Yes')
  }
//******************************END All Temporary Order******************************//

selectIndexOrderTypeDropdown = (indexOrderTypeDropdown) =>{
  console.log(indexOrderTypeDropdown)
  this.setState({indexOrderTypeDropdown: indexOrderTypeDropdown})
  this.valueRelativelyOrderType();
  this.props.getOrderTypeFromOrder(dropDownType[indexOrderTypeDropdown].id)
}
















  test = () =>{
    this.props.AllCheckOrders.refetch();
  }

  

  





  //Create NEW ORDER with date, id, GUID





  indexOnClickTable = (index) => {
    this.setState({tableIndex: index})
  }

  changeOrdetTypeValue = (index) =>{
    this.setState({orderType: index}, () => this.valueRelativelyOrderType())
  }
  onChange = date => this.setState({ date })

  specialOrder =() =>{
    this.setState({allOrderCreateGridMemory: this.state.allOrderCreateGrid, allOrderCreateGrid: []})
  }

  memoryOrder =() =>{
    this.setState({allOrderCreateGrid: this.state.allOrderCreateGridMemory})
  }

  valueRelativelyOrderType = () => {
    const {indexOrderTypeDropdown} = this.state;
    console.log(indexOrderTypeDropdown)
    if(indexOrderTypeDropdown === 3){
      this.changeNumbersOnNegative()
    }
    else if(indexOrderTypeDropdown === 1){
      this.recalculationOfValues()
    }
    else if(indexOrderTypeDropdown ===5 ){
      this.changeNumbersOnZero()
    }
    else if(indexOrderTypeDropdown ==='Special order'){
      this.specialOrder();
    }
    else if(indexOrderTypeDropdown ==='Order'){
      this.memoryOrder();
    }
  }

  

  changeNumbersOnNegative = () =>{
    var cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    for (const key in cloneArrayone){
      cloneArrayone[key].Menge = -cloneArrayone[key].Menge
      cloneArrayone[key].Total = -cloneArrayone[key].Total
    }
    console.log('g')
    this.setState({allOrderCreateGrid: cloneArrayone})
  }

  changeTableByInput = (index, e) =>{
    var cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    const name = e.target.name
    console.log(name)
    console.log(e.target.name)
    cloneArrayone[index][name] = e.target.value;
    cloneArrayone[index].Total = this.changeMerge(cloneArrayone[index]);;
    
    
    this.setState({allOrderCreateGrid: cloneArrayone});
  }

  changeMerge = (cloneArrayone) =>{

    let sum = cloneArrayone.Menge * cloneArrayone.PreisLieferung;
    let total = Math.round(sum * 100) / 100
    return total
  }

  changeNumbersOnZero = () =>{
    var cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    for (const key in cloneArrayone){
      cloneArrayone[key].Menge = 0
      cloneArrayone[key].Total = 0
      
    }
    this.setState({allOrderCreateGrid: cloneArrayone})
  }

  

  recalculationOfValues = ( ) =>{
    
         
  }

  sea(term){
    let a = this.state.term
   return function (product){ 
      return product.name.toLowerCase().indexOf(a)  !== -1 || product.cod.toLowerCase().indexOf(a)  !== -1;

    }   
    }

  deleteTable = (index) =>{
    let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    cloneArrayone.splice(index, 1);

    this.setState({allOrderCreateGrid: cloneArrayone})
  }

  addNewRecord = (isLast) =>{
    const {tableIndex} = this.state;
    let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    const newArray = {
      Addition: '',
      ArtikelNr: '',
      Bezeichnung: '',
      PreisLieferung: '',
      Total: '',
      Menge: '',
      RabattP: '',
      MWStCode: ''
    }
    const addPosition = isLast ? tableIndex + 1 : tableIndex - 1; 
    console.log(addPosition);
    cloneArrayone.splice(addPosition, 0, newArray)
    this.setState({allOrderCreateGrid: cloneArrayone}, ()=>{this.setState(this.state)})
  }

  rrrr = (node) =>{
  
  }

  onPressEnter =  (e) => {
    const {tableIndex,allOrderCreateGrid} = this.state;
    console.log(e)
    if(e.which === 13){
      console.log('this enter')
      
     // e.target.select();
      const isLast = tableIndex === allOrderCreateGrid.length - 1;
      if(isLast){
        this.addNewRecord(isLast);
        console.log(this.mergeInput)

      }
      else {
        this.selectAndFocusMergeInput();
      }
    }
  }

  selectAndFocusMergeInput = () =>{
    const {tableIndex} = this.state;
    this.mergeInput[tableIndex + 1].focus();
    this.mergeInput[tableIndex + 1].select();
    this.setState({tableIndex: tableIndex + 1})
  }

  changeTableSearch = (e) =>{
    this.setState({tableSearch: e.target.value})
  }

  getMergeInputRef = (node) =>{ this._mergeInput = node}

  changeMergeIndex = () =>{
    this.setState({mergeIndex: this.state.mergeIndex + 1});
    console.log(this.state.mergeIndex)
  }

  componentDidMount() {
    this.props.onRef(this)
    console.log('componentDidMount')
  }
  componentWillUnmount() {
    this.props.onRef(undefined)
  }
  

  render() {
    
    console.log(this.props.AllOrderCreateGrid.allOrderCreateGrid)
    console.log(this.props.AllOrderCreateGrid)
    console.log(this.props.AllOrderCreateGrid)
    console.log(this.props.AllOrderCreateGrid)
    console.log(this.props.AllOrderCreateGrid)
    let input = '1';
    const {props, procedureCustomersListForCreatingOrdersOnDate} = this.props;
    const {AllCheckOrders} = this.props;
    if(this.props.AllOrderCreateGrid.loading){ return <div>Loading</div>}
      else{
    return (
      <Row>
        <Col lg={12}>

          <Modal
            isOpen={this.state.isOpenOrderListModal}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            width={"481px"}
            height={"300px"}
            component={<OrderListModal 
              allCheckOrders={AllCheckOrders.allCheckOrders ? AllCheckOrders.allCheckOrders : []} 
              date = {this.props.date}
              closeModal={this.closeOrderListModal}
              validationOrderListModal={this.validationOrderListModal} 
              />}
            />

             <Modal
            isOpen={this.state.isOpenLoadingModal}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            width={"200px"}
            height={"50px"}
            component={<LoadingModal 
              allCheckOrders={AllCheckOrders.allCheckOrders ? AllCheckOrders.allCheckOrders : []} 
              date = {this.props.date}
              closeModal={this.closeOrderListModal}
              validationOrderListModal={this.validationOrderListModal} 
              />}
            />

          <Modal
            isOpen={this.state.isOpenWarningModal}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            width={"350px"}
            height={"220px"}
            component={<WarningModal 
            closeModal={this.closeWarningModal}
            />}
          />

          <Modal
            isOpen={this.state.isOpenShippingCostModal}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            width={"350px"}
            height={"220px"}
            component={<ShippingCostModal 
            closeModal={this.closeShippingCostModal}
            />}
          />

          <Modal
            isOpen={this.state.isOrderCreatingModal}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            width={"350px"}
            height={"220px"}
            component={<OrderCreatingModal 
            closeModal={this.closeOrderCreatingModal}
            />}
          />

        </Col>

        <Col lg={12}>
          <Query
            query={GetOrderDeliveryTime}
            variables={{id: this.props.id }}> 
            {({ loading, error, data, refetch, networkStatus }) => {
            if (networkStatus === 4) return "Refetching!";
            if (error) return `Error!: ${error} `;
            return (
              <Col lg={12}>
                <Col lg={2}>
                  <Input
                    text="Order-ref"  
                    type="text" 
                    value={1} 
                    name="search" 
                    onBlur={null} 
                    onChange={(async()=>{ await refetch(); console.log("gg")})}
                    width = '90%'
                    onKeyPress={this.onPressEnter}
                    
                  />
                </Col>

                <Col lg={2}>
                  <Query
                    query={view_fkOrderTypes}
                  > 
                  {({ loading, error, data, refetch, networkStatus }) => {
                    if (networkStatus === 4) return "Refetching!";
                    if (error) return `Error!: ${error}`;
                    return (

                      <SimpleDropdown 
                        text="Order tupe"
                        row={"type"}
                        row1={false}
                        style={{zIndex: 1, margin: '-2px 0px 0px 0px'}} 
                        list={dropDownType} 
                        gruppeId={this.state.indexOrderTypeDropdown + 1} 
                        select={this.selectIndexOrderTypeDropdown}
                      />
                    );
                  }}
                  </Query>
                </Col>

                  <Col lg={2}>
                    <Input
                      text="Delovery time" 
                      type="text" 
                      value={data.getOrderDeliveryTime ? data.getOrderDeliveryTime[0].weekdays: 0} 
                      name="search" 
                      onBlur={null} 
                      onChange={this.rrrr}
                      ref={this.rrrr}
                      width = '90%'
                      left="20px"
                    />
                  </Col>

                  <Col lg={2}>
                    <Col lg={1}/>
                    <Col lg={11}>
                      <Button 
                      background="#f5a623" 
                      top="39px" 
                      paddingTop="12px"
                      width = '93%'
                      height="40px"
                      size="16px"
                      text='Add shipping cost'
                      onClick={this.openShippingCostModal}
                    />
                    </Col>
                  </Col>

                  <Col lg={2}>
                    <Button 
                      onClick={this.noOrder}
                      background="#ff4b57" 
                      top="39px" 
                      paddingTop="12px"
                      width = '93%'
                      height="40px"
                      size="16px"
                      text='No order'
                    />
                  </Col>

                  <Col lg={2}>
                    <Mutation 
                      mutation={CreateNewOrder}
                     ignoreResults={false}
                     >
                    {(CreateNewOrder, { loading, errors, data }) => {
                      if (errors) return `Error! ${error.message}`;
            return (
              <div> 
             
                    <Button 
                    onClick={(async()=>{await this.createNewOrder() })}
                      background="#99d5d7" 
                      top="39px" 
                      paddingTop="12px"
                      width = '93%'
                      height="40px"
                      size="16px"
                      text='Order Create'
                    />
                    </div>
                    )}}
                </Mutation>
                  </Col>
                </Col>
              );
            }}
          </Query>
        </Col>

        <Col lg={12} style={{marginTop: '30px'}}>


           <Query
                      query={AllorderTableOnChangeInput}
                      variables={{search: this.state.searchArtikel}}
                      fetchPolicy='network-only'
                    > 
                    {({ loading, error, data, refetch, networkStatus }) => {
                      if (networkStatus === 4) return "Refetching!";
                      if (error) return `Error!: ${error}`;
                      return (
                        <Table 
                    tableSearch={this.state.tableSearch}
                    changeTableSearch={this.changeTableSearch}
                    orderType = {this.state.orderType}
                    changeTableByInput= {this.changeTableByInput}
                    changeNumbersOnNegative= {this.changeNumbersOnNegative}
                    allOrderCreateGrid={this.state.allOrderCreateGrid}
                    onClick={this.indexOnClickTable} 
                    delete={this.deleteTable}
                    testFunctionToInput= {this.testFunctionToInput}
                    changeInputWithDropdownValue={this.changeInputWithDropdownValue}
                    inputValue = {this.state.inputValue}
                    list={data.allorderTableOnChangeInput ? data.allorderTableOnChangeInput : null} 
                    addNewRecord={this.addNewRecord}
                    onClickInputWithDropdown={this.onClickInputWithDropdown}
                    onClickTable={this.onClickTable}
                    loading={this.props.AllOrderCreateGrid.loading}
                    allOrderCreateGrid={this.state.allOrderCreateGrid}
                    onPressEnter={this.onPressEnter}
                    mergeIndex={this.state.mergeIndex}
                    setTextInputRef={this.setTextInputRef}
                    mergeInput={this.mergeInput}

                    
                    //FFFFF
                    names={[
                      "Article no.", 
                      "Quantity", 
                      "Description", 
                      "Addition",
                      "Price",
                      "Total",
                      "Discount",
                      "VAT"
                    ]} 
                    widths={[
                      '10%',
                      '10%',
                      '20%', 
                      '10%',
                      '10%',
                      '10%',
                      '10%',
                      '20%',
                    ]} 
                  />                     );
                    }}
                    </Query>

             
        </Col>
      </Row>
    );
  }
}
}

const graph = compose(
  
  graphql(AllOrderCreateGrid, {
    options: (props) => ({
      fetchPolicy: 'network-only',
      variables: {
        TempLS: props.procedureCustomersListForCreatingOrdersOnDate.TempLS ? props.procedureCustomersListForCreatingOrdersOnDate.TempLS :  0,
        OfferID: props.procedureCustomersListForCreatingOrdersOnDate.OfferID ? props.procedureCustomersListForCreatingOrdersOnDate.OfferID : 0,
        id: props.id,
        date: props.date,
        table: "3",
        VorgabeLieferschein: props.VorgabeLieferschein,
        LinkOrder: props.id
      }
    }),

    name: "AllOrderCreateGrid",
    withRef: true
  }
  ),
  graphql(AllCheckOrders, {
    options: (props) => ({
      fetchPolicy: 'cache-and-network',
      variables: {
        id: props.id,
        date: props.date,
      }
    }),
    name: "AllCheckOrders",
    withRef: true

  }
  ),
  graphql(CreateNewOrder, {name:"CreateNewOrder"}),
  graphql(CreateTemporaryOrder, {name:"CreateTemporaryOrder"}),
  graphql(NoOrderOnOrderCreate, {name:"NoOrderOnOrderCreate"}),
)(Order);

export default withApollo(graph);
