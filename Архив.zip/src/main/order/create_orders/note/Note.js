import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';

import Textarea from '../../../../../../../@appElements/textarea/Textarea.js';
import Calendar from '../../../../../../../@appElements/calendar/Calendar.js';
import Input from '../../../../../../../@appElements/input/Input.js'



class Note extends Component {

  constructor() {
    super();
    this.state={
      date: new Date()
    }
  }
 getDate = (date) => {
    this.setState({date: date});
    
  }
  render() {
    return (
      <Row style={{padding: "0 0 0 15px"}}>
        <Textarea 
          text=" Note" 
          width='70%'
          value={''}
          onBlur={null}
          name="note"
          onChange={null}
          style={{margin: '30px 0px 10px 0px'}}
        />
        <Input
                    text="Order-ref"  
                    type="text" 
                    value={1} 
                    name="search" 
                    onBlur={null} 
                    
                    width = '90%'
                    onKeyPress={this.onPressEnter}
                    autoFocus={true}
                  />
      </Row>
    );
  }
}


export default Note;