import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { Query } from 'react-apollo'

import CheckBox from '../../../../../../../@appElements/checkBox/CheckBox.js';
import Dropdown from '../../../../../../../@appElements/dropDown/Dropdown'
import HeaderTable from '../../../../../../../@appElements/table/HeaderTable.js'
import TableDropdown from '../../../@components/tableDropdown/TableDropdown.js'

import TableLists from '../../../@components/tableDropdown/TableLists.js'
import Input from '../../../../../../../@appElements/input/Input.js'
import Button from'../../../../../../../@appElements/button/Button.js'
import Modal from '../../../../../../../@appElements/modal/Modal.js';
import Calendar from '../../../../../../../@appElements/calendar/Calendar.js';

import AllOrderOverviewArticles from '../../../../../../../functions/query/order/allOrderOverviewArticles.js'


class articlesOverview extends Component {
	state ={
		date: ''
	}

	getDate = (date) => {
		this.setState({date: date})
	}

	onClick=(index)=>{}
						

 render() {
    return (
    	<div>
	      <Row>
	      	<Col lg={2}>
	      		<Calendar
	              getDate={this.getDate} 
	              style= {{margin: '17px 0px 6px 0px', width:'100%'}}
	        	/>
	      	</Col>
	      	<Col lg={2}>
	        	<Input
		          text="Delovery time" 
		          type="text" 
		          value='' 
		          name="Orger group" 
		          onBlur={null} 
		          onChange={this.rrrr}
		          ref={this.rrrr}
		          width = '90%'
		          left="20px"
	            />
	        </Col>

	        <Col lg={2}>
	        	<Button 
		          background="#99d5d7" 
		          top="39px" 
		          paddingTop="8px"
		          width = '93%'
		          height="35px"
		          size="16px"
		          text='Calculator'
		        />
	        </Col>

	        <Col lg={2}>

	        	<Button 
		          background="#f5a623" 
		          top="39px" 
		          paddingTop="8px"
		          width = '93%'
		          height="35px"
		          size="16px"
		          text='Edit order'
		        />
	        </Col>
	      </Row>

	      <Row style={{marginTop: '25px'}}>
	      	<Query
	          query={AllOrderOverviewArticles}
	          variables={{firstDate: this.state.date, secondDate:this.state.date}}
	          fetchPolicy = 'network-only'
	        > 
	        {({ loading, error, data, refetch, networkStatus }) => {
	          if (networkStatus === 4) return "Refetching!";
	          if (error) return `Error!: ${error}`;
	          if(loading) return 'test'
	          let newArr=[];
	      		let newTest = [];


			 let result  =   data.allOrderOverviewArticles.reduce((r,o) =>{
			    var k = o.ArtikelNr; 
			    if (r[k] || (r[k]=[])) r[k].push(o);
			    return r;
			}, []);

			//if(newTest.indexOf(item.ArtikelNr) ==-1){ newTest.push(item.ArtikelNr)}

			
			console.log(data.allOrderOverviewArticles)
			 
			 

	          
		      data.allOrderOverviewArticles.forEach((item)=>{
		      	if(newTest.indexOf(item.ArtikelNr) ==-1){ newTest.push(item)}
		      	
		      	
		     

		      	


		      		
			      let date = item.Datum===null?'':item.Datum.substring(0,10);
		          newArr.push([
		          	item.ArtikelNr,
		          	item.KundenNr, 
		          	item.Menge,
		          	item.Bezeichnung,
		          	item.AktNameIntern,
		          	item.IndTextDeliveryNote,
		          	item.IndTextProduction,
		          	date,
		          	item.LieferscheinNr,
		          	item.Betrag,
		          	item.RabattP])
	           }
	          )
	          console.log(newTest)
	          console.log(result)
	          return (
	          	<div>
	        
		      	<TableDropdown 
			        arr={newArr} 
			        onClick={this.onClick}
			        //FFFFF
			        names={[
			          "Article No.", 
			          "Customer No.", 
			          "Amount", 
			          "Description",
			          "Name",
			          "Delivery note",
			          "Production list",
			          "Date",
			          "Delivery No.",
			          "Price",
			          "Discount"
			        ]} 
			        widths={[
			          '8.5%',
			          '8.5%',
			          '8.5%',
			          '15%',
			          '8.5%',
			          '8.5%',
			          '8.5%',
			          '8.5%',
			          '8.5%',
			          '8.5%',
			          '8.5%'
			        ]} 
			      />  
			      </div>  
		        );
            }}
            </Query>       
	      </Row>
      </div>
    );
  }
}


export default articlesOverview;