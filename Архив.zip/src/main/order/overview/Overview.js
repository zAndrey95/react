import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { NavLink } from 'react-router-dom'
import {Route, Switch} from 'react-router-dom';
import { graphql, compose } from 'react-apollo';

import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';
import Dropdown from '../../../../../../@appElements/dropDown/Dropdown'


import Menu from './Menu.js';
import OrdersOverview from './ordersOverview/OrdersOverview.js';
import ArticlesOverview from './articlesOverview/ArticlesOverview.js';
import CustomerWithoutOrdersToday from './customerWithoutOrdersToday/CustomerWithoutOrdersToday.js';
import DoughOverview from './doughOverview/DoughOverview.js';




import './Overview.css';


class Overview extends Component {

    render() {
     
    return (
    <div>
      <Col lg={12} > <Menu id={this.props.id}/> </Col>
      <Col lg={12}>
             <Switch>
              
                <Route path={'/order/' + this.props.id + '/overview/ordersOverview'} render={props =>
                            <OrdersOverview
                            id={this.props.id}
                            /> }
                />
                <Route path={'/order/' + this.props.id + '/overview/articlesOverview'} render={props =>
                            <ArticlesOverview
                            id={this.props.id}
                            /> }
                />
                <Route path={'/order/' + this.props.id + '/overview/customerWithoutOrdersToday'} render={props =>
                            <CustomerWithoutOrdersToday
                            id={this.props.id}
                            /> }
                />
                <Route path={'/order/' + this.props.id + '/overview/doughOverview'} render={props =>
                            <DoughOverview
                            id={this.props.id}
                            /> }
                />
               
                />
              </Switch>
        </Col>  
    </div>
    );
  }
}


export default Overview