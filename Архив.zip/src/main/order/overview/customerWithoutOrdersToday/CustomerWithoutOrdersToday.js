import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { Query } from 'react-apollo'

import CheckBox from '../../../../../../../@appElements/checkBox/CheckBox.js';
import Dropdown from '../../../../../../../@appElements/dropDown/Dropdown'
import HeaderTable from '../../../../../../../@appElements/table/HeaderTable.js'
import Table from '../../../../../../../@appElements/table/Table.js'
import Input from '../../../../../../../@appElements/input/Input.js'
import Button from'../../../../../../../@appElements/button/Button.js'
import Calendar from '../../../../../../../@appElements/calendar/Calendar.js';

import AllOrderCustomersWithout from '../../../../../../../functions/query/order/allOrderCustomersWithout.js'

class CustomerWithoutOrdersToday extends Component {


  state ={
		date: ''
	}

	getDate = (date) => {
		this.setState({date: date})
	}
	onClick=(index)=>{}

 render() {
    return (
    	<div>
	      <Row>
	      	<Col lg={2}>
	      		<Calendar
	              getDate={this.getDate} 
	              style= {{margin: '17px 0px 6px 0px', width:'100%'}}
	        	/>
	      	</Col>
	      	<Col lg={2}>
	        	<Input
		          text="Delovery time" 
		          type="text" 
		          value='' 
		          name="Orger group" 
		          onBlur={null} 
		          onChange={this.rrrr}
		          ref={this.rrrr}
		          width = '90%'
		          left="20px"
	            />
	        </Col>

	        <Col lg={2}>
	        	<Button 
		          background="#99d5d7" 
		          top="39px" 
		          paddingTop="8px"
		          width = '93%'
		          height="35px"
		          size="16px"
		          text='Calculator'
		        />
	        </Col>
	      </Row>

	      <Row style={{marginTop: '25px'}}>
	      	<Query
	          query={AllOrderCustomersWithout}
	          variables={{firstDate: this.state.date, secondDate:this.state.date}}
	          fetchPolicy = 'network-only'
	        > 
	        {({ loading, error, data, refetch, networkStatus }) => {
	          if (networkStatus === 4) return "Refetching!";
	          if (error) return `Error!: ${error}`;
	          let newArr=[];
		      !loading  ? data.allOrderCustomersWithout.forEach((item)=>{
			      let date = item.OrderDate===null?'':item.OrderDate.substring(0,10);
		          newArr.push([
		          	date,
		          	item.KundenNr, 
		          	item.AktNameIntern
		          ])
	           }
	          ) : null
	          return (
		      	<Table 
			        arr={newArr} 
			        onClick={this.onClick}
			        //FFFFF
			        names={[
			          "Date", 
			          "Customer No.", 
			          "Name"
			        ]} 
			        widths={[
			          '33.33%',
			          '33.33%',
			          '33.33%'
			        ]} 
			      />    
		        );
            }}
            </Query>       
	      </Row>
      </div>
    );
  }
}


export default CustomerWithoutOrdersToday;