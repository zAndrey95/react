import React, { Component } from 'react';
import {  Row, Col} from 'react-bootstrap';
import { NavLink } from 'react-router-dom'
import './Menu.css';



class Menu extends Component {
  render() {
    return (
      
      	<div>
	     	<Col lg={3} className="col-menu-konditionen"><NavLink to={'/order/' + this.props.id + '/overview/ordersOverview'} activeClassName="selected_konditionen_customer"><button className="menu_button_konditionen"> Orders overview</button></NavLink></Col> 
	      	<Col lg={3} className="col-menu-konditionen"><NavLink to={'/order/'+ this.props.id +'/overview/articlesOverview'} activeClassName="selected_konditionen_customer"> <button className="menu_button_konditionen"> Articles overview</button></NavLink> </Col>
	      	<Col lg={3} className="col-menu-konditionen"><NavLink to={'/order/'+ this.props.id +'/overview/customerWithoutOrdersToday'} activeClassName="selected_konditionen_customer"><button className="menu_button_konditionen"> Customer without orders today</button></NavLink> </Col>
	      	<Col lg={3} className="col-menu-konditionen"><NavLink to={'/order/'+ this.props.id +'/overview/doughOverview'} activeClassName="selected_konditionen_customer"><button className="menu_button_konditionen"> Dough overview</button></NavLink> </Col>
	    </div>     
    );
  }
}

export default Menu;
