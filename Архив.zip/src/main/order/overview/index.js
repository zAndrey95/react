
import React from 'react';

const index = <div>ff </div>
export default index;

