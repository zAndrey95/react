import React, { Component } from 'react';
import {  Col, Row } from 'react-bootstrap';
import { withApollo, Query, Mutation } from 'react-apollo'


import edit from '../../../../../../img/edit.svg';
import InputWithDropdown from '../inputWithDropdown/InputWithDropdown.js'
import Button from '../../../../../../@appElements/button/Button.js'
import TableRow from './TableRow.js'
import AllorderTableOnChangeInput from '../../../../../../functions/query/order/allorderTableOnChangeInput.js'

import './Table.css'

import Input from './Input.js'

import search from '../../../../../../img/search1.svg'

const table = ['LinkArtikel','Menge','Bezeichnung','','PreisLieferung','Total','RabattP','MWStCode']

class TableWithChangeItem extends Component {

  constructor() {
    super();
    this.state = {
      selectItem: new Date(),
      index:'i',
      isArtikelNr: false,
      articalIndex: false,
      quantityIndex: false,
      desIndex: false,
      priceIndex: false,
      discountIndex: false,
      searchArtikel: ''
    }
    this.textInput = React.createRef();

  }


  changeTableRowIndex = (state, tableRowIndex) =>{
    this.setState({[state]: tableRowIndex})
  }

  changeInputWithoutDroponBlur = (state) => {
    this.setState({[state]: false})

  }





  render() {
    console.log(this.props)
    const {
      allOrderCreateGrid, 
      orderType, 
      width,
      changeInputWithDropdownValue,
      changeInputWithoutDroponBlur,
      changeTableByInput,
      onClickInputWithDropdown,
      list,
      tableSearch,
      changeTableSearch,
      onPressEnter,
      mergeIndex,
      setTextInputRef,
      mergeInput
    } = this.props
    //const filterList = allOrderCreateGrid.filter((listsArray)=>{return listsArray.ArtikelNr.toLowerCase().indexOf(tableSearch)  !== -1 })
    const arr = allOrderCreateGrid ? allOrderCreateGrid.map((item, index) => {
      return (
        <Col
          onClick={ this.props.onClickTable.bind(this, index)}
          style={{"text-align": this.props.align?this.props.align:"center", borderLeft: index==this.state.index ? "12px solid #3c445a": "12px solid #cdcdcd"}}
          className="tabRow"
          lg={12}
          key={index}>
          <Row>
            <Col lg={this.props.delete?11:12}>
              <TableRow
                item={item}
                index={index}
                width={width}
                changeInputWithDropdownValue={changeInputWithDropdownValue}
                changeInputWithoutDroponBlur={changeInputWithoutDroponBlur}
                changeTableByInput={changeTableByInput}
                onClickInputWithDropdown={onClickInputWithDropdown}
                list={list}
                onPressEnter = {onPressEnter}
                mergeIndex={mergeIndex}
                setTextInputRef={setTextInputRef}
                mergeInput={mergeInput}

              />
            </Col>
            {this.props.delete?<Col lg={1}><Col lg={12}  className="deleteCustomer"><div onClick={this.props.delete?this.props.delete.bind(this, index):null}>x</div></Col></Col>:null}
          </Row>

        </Col>
      )
    }) : [];
    
    const names = this.props.names.map((item, index)=>{
      const width = this.props.widths[index];
        return(
          <div
            className="headerTable"
            key={index}
            style={{"text-align": this.props.align?this.props.align:"center",'min-width':`${width}`, float: "left", padding: "10px 0 0 9px", height: "37px", "border-bottom": "1px solid #e0e0e0", background: "#3c445a" }}>
            {item}
          </div>
        )
    })

    return (

      <div>
        <Col lg={this.props.delete?11:12}>{names}</Col>{this.props.delete?<Col style={{height: "36px",background: "#3c445a"}} lg={1}></Col>:null}

        <Row>
          <Col lg={12} className="input-search">
              <Col lg={11}>
                <input className="search_main" placeholder="Search" onChange={ changeTableSearch} value={tableSearch} name="search"/>
              </Col>
               <Col lg={1} className="element_search">
                <img src={search} alt=""/>
              </Col>
          </Col>
        </Row>
        <Col lg={12} id="q" className="tableHeight" style={{background: '#fff'}}>
        {arr}
        </Col>
        <Col lg={2}>
          <Button 
          background="#99d5d7" 
          top="27px" 
          paddingTop="12px"
          width = '93%'
          height="46px"
          size="16px"
          text='Add new record'
          onClick={this.props.addNewRecord}
        />
        </Col> 
      </div>


    )
  }
}

export default TableWithChangeItem;