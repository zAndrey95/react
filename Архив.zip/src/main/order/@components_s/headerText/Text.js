import React from 'react'
import PropTypes from 'prop-types'


const Text = ({ text, color }) => (
  <div className="head-text">
    <span> {text}</span>
  </div>
);

Text.propTypes = {
  text: PropTypes.string,
  color: PropTypes.oneOf([
    '#3c445a'
  ])
}

Text.defaultProps = {
  text: ''
}

export default Text

