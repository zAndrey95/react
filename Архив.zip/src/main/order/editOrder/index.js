import React, { Component } from 'react';
import {  Row, Col} from 'react-bootstrap';



class Create_orders extends Component {

  constructor(props) {
    super(props);
     this.state = {
        change:true
      }
    this.createOrderRefItem = React.createRef() ;
  }

  onTrueChange = () => {
   this.setState({change: true})
  }

  onFalseChange = () => {
   this.setState({change: false})
  }



  render() {
    console.log(this.createOrderRef)
    return (
      <Row>
        <span>Test </span>
      </Row>
    );
  }
}

export default Create_orders
