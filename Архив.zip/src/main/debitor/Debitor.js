import React, { Component } from 'react';
import {Route, Switch,} from 'react-router-dom';
import {  Row, Col} from 'react-bootstrap';
import { withRouter } from 'react-router'
import styled from 'styled-components';

import Menu from './Menu.js';

import NewDebts from './table/Debts.js';
import Payment from './table/Payment.js';
import ImportISO from './table/ImportISO.js';

class Debitor extends Component {

  render() {
    return(
      <Block>
        <Menu/>
        <Switch>

          <Route
            path = '/debitor/newdebitors'
            render = {
              props => <NewDebts/>
            }
          />

          <Route
            path = '/debitor/payment'
            render = {
              props => <Payment/>
            }
          />

          <Route
            path = '/debitor/import'
            render = {
              props => <ImportISO/>
            }
          />

        </Switch>
      </Block>
    )
  }
}

export default withRouter(Debitor);

const Block = styled(Row)`
  height: 100%;
  min-height: 600px
  margin-top: 0px;
  margin-bottom: 0px;
  margin-left: 20px !important;
  margin-right: 20px !important;
  background-color: #f5f5f5
`;
