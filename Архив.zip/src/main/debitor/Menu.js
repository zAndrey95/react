import React, { Component } from 'react';
import {NavLink} from 'react-router-dom';
import {Col, Row} from 'react-bootstrap';
import { graphql, compose } from 'react-apollo';
import styled from 'styled-components';

class ImportISO extends Component {

	render() {
		return (
			<Menu>
				<Item lg={4}>
					<ItemLink to="/debitor/newdebitors" activeClassName={rando}>
	          Open Debts
	        </ItemLink>
				</Item>

				<Item lg={4}>
	        <ItemLink to="/debitor/payment" activeClassName={rando}>
						Payments
	        </ItemLink>
				</Item>

				<Item lg={4}>
	        <ItemLink to="/debitor/import" activeClassName={rando}>
	          Import ISO (CAMT,054)
	        </ItemLink>
				</Item>
			</Menu>
		)
	}
}

export default ImportISO;
const rando = btoa(Math.random())

const Menu = styled(Row)`
	padding: 0px;
	width: 100%;
	height: 36px;
	margin: 0px;
	background-color: #2e3941;
`;

const Item = styled(Col)`
	margin-top: 9px;
	text-align: center;
`;

const ItemLink = styled(NavLink).attrs({
	activeClassName: 'active'
})`
	font-family: HelveticaNeue;
	font-size: 16px;
	font-weight: 300;
	font-style: normal;
	font-stretch: normal;
	line-height: normal;
	letter-spacing: normal;
	text-align: center;
	color: #ffffff;

	&:hover {
		color: #c13c44;
	}

	&:focus {
		color: #c13c44;
	}

	&.${rando} {
		color: #c13c44;
	}
`;
