import React, { Component } from 'react';
import {  Row, Col} from 'react-bootstrap';
import styled from 'styled-components';

import Line from '../../../../components/simple/Line'
import Input from '../../../../components/joint/Input'
import Calendar from '../../../../components/joint/Calendar-picker'
import Table from '../../../../components/container/table/Table'
import Button from '../../../../components/simple/Button'

const arrTable = [
  {
    Date: '10.02.1999',
    AccountNo: '3232',
    ReceiptNo: '029471134',
    Subscription: 'Alina Lynuik',
    Amount: '31.2123412'
  },
  {
    Date: '10.02.1999',
    AccountNo: '3232',
    ReceiptNo: '029471134',
    Subscription: 'Alina Lynuik',
    Amount: '31.2123412'
  },
  {
    Date: '10.02.1999',
    AccountNo: '3232',
    ReceiptNo: '029471134',
    Subscription: 'Alina Lynuik',
    Amount: '31.2123412'
  }
]

const arrTableNames = ['Date', 'Account No', 'Receipt No', 'Subscription', 'Amount']
const arrTableWidths = ['15%', '15%', '20%', '25%', '25%']

//<button onClick={this.props.handleCloseModal}>Close Modal</button>

class Modal extends Component {

  render () {
    const arr = [];
    arrTable.forEach((item) => {arr.push([item.Date, item.AccountNo, item.ReceiptNo, item.Subscription, item.Amount])});
    return (
      <ModalStyle>
        <Header>
          <TextModal>Enter payment</TextModal>
          <HeaderClose onClick={this.props.handleCloseModal}>x</HeaderClose>
        </Header>
        <Body>
          <TextModal size={'18px'} color={'#060606'}>300.801 Zurinussli, klein TK </TextModal>
          <Line />
          <Row>
            <Col lg={3}>
              <Input text="Invoice No." value="001" width="140px" />
            </Col>
            <Col lg={3}>
              <Calendar text='Date'/>
            </Col>
            <Col lg={3}>
              <Input text="Total" value="001" width="140px" />
            </Col>
            <Col lg={3}>
              <Input text="Remaing amount" value="001" width="140px" />
            </Col>
          </Row>
          <Row>
            <Col lg={3}>
              <Input text="Customer No." value="001" width="140px" />
            </Col>
            <Col lg={6}>
              <Input text="Name" value="001" width="300px" />
            </Col>
          </Row>

          <br/>

          <TableBlock arr={arr} widths={arrTableWidths} names={arrTableNames} align={'left'} getSearchValue={false}/>

          <TextModal size={'18px'} color={'#060606'} family={'Roboto'} weight={'600'}>Enter payment</TextModal>
          <Line />
          <Row>
            <Col lg={3}>
              <Calendar text='Date'/>
            </Col>
            <Col lg={3}>
              <Input text="Account No." value="001" width="140px" />
            </Col>
            <Col lg={3}>
              <Input text="Recept No." value="001" width="140px" />
            </Col>
          </Row>
          <Row>
            <Col lg={6}>
              <Input text="Subscription" value="001" width="300px" />
            </Col>
            <Col lg={3}>
              <Input text="Amount" value="001" width="140px" />
            </Col>
          </Row>

          <BtnStyle onClick={this.props.handleCloseModal} value={"USE OVERPAYMENTS"} width={"180px"} />
          <BtnStyle onClick={this.props.handleCloseModal} value={"ENTER PAYMENT"} width={"180px"} />
        </Body>
      </ModalStyle>
    );
  }
}

export default Modal;

const TableBlock = styled(Table)`
  margin-top: 20px;
  margin-bottom: 20px;
  width: 90%;
`;

const ModalStyle = styled.div`
  width: 765px;
  height: 670px;
`;

const Header = styled.div`
  width: 765px;
  height: 60px;
  background-color: #2e3941;
  padding: 16px 0 0 20px;
`;

const TextModal = styled.span`
  font-family: ${props => props.family ? props.family : 'HelveticaNeue'};
  font-size: ${props => props.size ? props.size : '24px'};
  font-weight: ${props => props.weight ? props.weight : 'normal'};
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: ${props => props.size ? props.size : '#ffffff'};
`;

const HeaderClose = styled.span`
  color: white;
  float: right;
  margin-right: 20px;
`;

const Body = styled.div`
  background-color: #f5f5f5;
  height: 610px;
  padding: 20px 0 0 16px;
`;

const BtnStyle = styled(Button)`
  margin-top: 30px;
  float: left;
  margin-left: 120px
`;
