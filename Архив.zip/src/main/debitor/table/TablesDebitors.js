import React, { Component } from 'react';
import styled from 'styled-components';
import ReactModal from 'react-modal';

import './TablesDebitors.css';

import ModalEdit from './modal/EditTabs';

const data = [
  { date: "12.07.2018", invoiceNo: "63231", customerNo: "0712102111", name: "Alina Lynuik", total: 31.933, remaining: 31.933, term: "12.07.2018", payment: "", unexpired: "92", unexpiredDebt: 2891, overdue1: 31.933, overdue2: 31.933, overdue3: 31.933, reminders: "3"},
  { date: "12.07.2018", invoiceNo: "63231", customerNo: "0712102111", name: "Alina Lynuik", total: 31.933, remaining: 31.933, term: "12.07.2018", payment: "", unexpired: "92", unexpiredDebt: 2891, overdue1: 31.933, overdue2: 31.933, overdue3: 31.933, reminders: "3"},
  { date: "12.07.2018", invoiceNo: "63231", customerNo: "0712102111", name: "Alina Lynuik", total: 31.933, remaining: 31.933, term: "12.07.2018", payment: "", unexpired: "92", unexpiredDebt: 2891, overdue1: 31.933, overdue2: 31.933, overdue3: 31.933, reminders: "3"},
  { date: "12.07.2018", invoiceNo: "63231", customerNo: "0712102111", name: "Alina Lynuik", total: 31.933, remaining: 31.933, term: "12.07.2018", payment: "", unexpired: "92", unexpiredDebt: 2891, overdue1: 31.933, overdue2: 31.933, overdue3: 31.933, reminders: "3"},
]

const customStyles = {
  content : {
    width               : '765px',
    height                : '670px',
    top                   : '50%',
    left                  : '50%',
    right                 : 'auto',
    bottom                : 'auto',
    marginRight           : '-50%',
    transform             : 'translate(-50%, -50%)',
    padding               : '0',
    overflow              : 'none'
  }
};

class TablesDebitors extends Component {
  constructor() {
    super();
    this.state = {
      showModal: false,
    };

    this.handleOpenModal = this.handleOpenModal.bind(this);
    this.handleCloseModal = this.handleCloseModal.bind(this);
    this.handleIndex = this.handleIndex.bind(this);
  }

  handleOpenModal() {
    this.setState({ showModal: true });
    console.log('this');
  }

  handleCloseModal() {
    this.setState({ showModal: false });
  }

  handleIndex(index, item) {
    // console.log(index);
    // console.log(item);
  }

  render() {
    console.log(this.props);

    let totalSum = 0;
    let totalSumRemainnig = 0;
    let totalSumuUnexpiredDebt = 0;
    let totalSumOverdue1 = 0;
    let totalSumOverdue2 = 0;
    let totalSumOverdue3 = 0;

    const dataI = this.props.data.allOpenDebitor;
		for(const key in dataI){
			 totalSum += dataI[key].total,
       console.log(totalSum);
       totalSumRemainnig += dataI[key].remainingAmount,
       totalSumuUnexpiredDebt += dataI[key].unexpiredDebt,
       totalSumOverdue1 += dataI[key].overdue1_15Days,
       totalSumOverdue2 += dataI[key].overdue16_30Days,
       totalSumOverdue3 += dataI[key].overdueMore30Days
		}

		const dataTable=[];
		this.props.data.allOpenDebitor.forEach((i)=>{
			dataTable.push([i.date, i.invoiceNo,  i.customerNo, i.name, i.total, i.remainingAmount, i.termOfPayment, i.paymentDate, i.paymentDelay, i.unexpiredDebt, i.overdue1_15Days, i.overdue16_30Days, i.overdueMore30Days, i.reminders])
		})

		const bodyInfo = dataTable.map((item, index) => {
			return (
				<tr>
					{dataTable[index].map((name, id) => {
						return(
								<td onClick={this.handleOpenModal} key={id}>{name}</td>
						)
					})}
				</tr>
			)
		})



		return (
			<Block>
				<table className="table">
				  <thead className="thead-dark">
				    <tr>
				      <th scope="col">Date</th>
				      <th scope="col">Invoice No</th>
				      <th scope="col">Customer No</th>
				      <th scope="col">Name</th>
							<th scope="col">Total</th>
							<th scope="col">Remaining amount </th>
							<th scope="col">Term of payment </th>
							<th scope="col">Payment date</th>
							<th scope="col">Payment delay</th>
							<th scope="col">Unexpired debt</th>
							<th scope="col">Overdue 1-15 days</th>
							<th scope="col">Overdue 16-30 days</th>
							<th scope="col">Overdue more 30 days</th>
							<th scope="col">Reminders</th>
				    </tr>
				  </thead>
					<tr className="searchMy">
						<td colspan="14">Larry the Bird</td>
					</tr>
				  <tbody>
						{bodyInfo}
						<tr className="myTr">
				      <td></td>
				      <td></td>
				      <td></td>
				      <td></td>
							<td>{totalSum}</td>
							<td>{totalSumRemainnig}</td>
							<td></td>
							<td></td>
							<td></td>
							<td>{totalSumuUnexpiredDebt}</td>
							<td>{totalSumOverdue1}</td>
							<td>{totalSumOverdue1}</td>
							<td>{totalSumOverdue1}</td>
							<td></td>
				    </tr>
				  </tbody>
				</table>
        <ReactModal
           isOpen={this.state.showModal}
           contentLabel="onRequestClose Example"
           onRequestClose={this.handleCloseModal}
           style={customStyles}
        >
          <ModalEdit handleCloseModal={this.handleCloseModal}/>
        </ReactModal>
			</Block>
		)
	}
}

export default TablesDebitors;

const Block = styled.div`
	margin: 0px 20px 0px 20px;
	overflow-x: scroll;
	height: 100%;
`;
