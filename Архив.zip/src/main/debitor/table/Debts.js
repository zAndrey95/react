import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { Query } from 'react-apollo'

import Line from '../../../components/simple/Line'
import Parameters from './Parameters'
import Table from './TablesDebitors.js';

import Data from '../../../functions/query/debitor/DebtsTable'

class NewDebts extends Component {
	state = {
		dateFrom: '',
		dateTill: '',
		datePayment: ''
	}

	onCompleted = data => {
		this.setState({
			data
		})
	}

	onChangeDateFrom = date => {
		this.setState({ dateFrom: date })
		console.log('text');
	}
	onChangeDateTill = date => this.setState({ dateTill: date })
	onChangeDatePayment = date => this.setState({ datePayment: date })

	onChangeDate = () => {
		// console.log(dataFrom);
		// console.log(e);
		// console.log(dateTill);
		// console.log(datePayment);
		// var options = {year: 'numeric', month: 'numeric', day: 'numeric' };
		// var dateTimeFormat = new Intl.DateTimeFormat(options);
		// console.log(dateTimeFormat.format(date));
	}

	render() {
		console.log(this.state);
		const { dateFrom, dateTill, datePayment } = this.state;
		return (
			<Query
				query = {Data}
        variables = {{
					dateFrom: dateFrom,
					dateTill: dateTill,
					datePayment: datePayment,
				}}
				fetchPolicy = 'network-only'
				onCompleted = {this.onCompleted}
	      errorPolicy = "all"
				pollInterval = {30000}
	      onError = {() => console.log('ups..error in debitor/open tabs')}
	      displayName = {'debitor'}>
				{({loading, error, networkStatus, data}) => {
					if (networkStatus === 4) return "Refetching...";
					if (error) return `ErrorQuery: ${error}`;
          if (loading) return "loading";
					return (
						<Row>
							<Parameters
								onChangeDateFrom={this.onChangeDateFrom}
								dateFrom={this.state.dateFrom}
								onChangeDateTill={this.onChangeDateTill}
								dateTill={this.state.dateTill}
								onChangeDatePayment={this.onChangeDatePayment}
								datePayment={this.state.datePayment}
								/>
							<Line/>
			        <Table data={this.state.data}/>
						</Row>
					)
				}}
			</Query>
		)
	}
}

export default NewDebts;
