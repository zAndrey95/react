import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { graphql, compose } from 'react-apollo';
import styled from 'styled-components';

import Line from '../../../components/simple/Line'
import Input from '../../../components/simple/Input.js'
import Checkbox from '../../../components/simple/Checkbox'
import IcoSettings from '../../../style/img/ico-settings.png'
import Button from '../../../components/simple/Button'
import Table from '../../../components/container/table/Table'

const names = ['Date', 'Invoice No.', 'Invoice date', 'Customer', 'Amount', 'Description amount', 'FIBU Account', 'Status', 'Error massage', 'Sudscriber number', 'Receipt No.']
const widths = ['9%', '7%', '7%', '14%', '9%', '9%', '9%', '9%', '9%', '9%', '9%']

class ImportISO extends Component {

	render() {
		return (
			<Row>
				<Row>
					<Col lg={5}>
						<Col lg={6}>
							<Input text="File name" value="text.txt" width="300px" name="FileName"/>
						</Col>
						<Col lg={6}>
							<StyleButton value="OPEN FILE" width="250px" className="transparent"/>
						</Col>
					</Col>
					<Col lg={5}>
						<Col lg={6}>
							<Input text="File name" value="text.txt" width="300px" name="FileName"/>
						</Col>
						<Col lg={6}>
							<Checkbox value="1 Delete file after import" open={true} top="44px"/>
						</Col>
					</Col>
					<Col lg={2}>
						<BlockSettingsIco src={IcoSettings} onClick={this.changeSetting}/>
					</Col>
				</Row>
				<Line/>
				<Table arr={[]} widths={widths} names={names} align="left"/>
			</Row>
		)
	}
}

export default ImportISO;

const StyleButton = styled(Button)`
	margin-top: 20px;
`;

const BlockSettingsIco = styled.img`
	float: right;
	margin-top: 35px;
	margin-right: 20px;
	width: 34px;
	height: 34px;
	box-shadow: 0 1px 2px 0 rgba(90, 90, 90, 0.2);
  background-color: #f5f5f5;
`;
