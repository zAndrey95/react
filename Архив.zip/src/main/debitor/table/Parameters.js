import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import styled from 'styled-components';

import IcoSettings from '../../../style/img/ico-settings.png'
import Input from '../../../components/simple/Input.js'
import Calendar from '../../../components/joint/Calendar-picker'
import Dropdown from '../../../components/container/dropdown/Dropdown'

class Parameters extends Component {
	constructor() {
	    super();
	    this.state = {
				isOpenModal: false,
				idActiveModal: 0,
				isSettings: "inline-block",
				openSetting: false,
				date: new Date()
	    }
  	}

		//onChange = date => this.setState({ date })

		onChange = date => {
			this.setState({date})
		}

		openModal = (id) => {
			this.setState({
				isOpenModal: !this.state.isOpenModal,
				idActiveModal: id
			})
		}

		changeSetting = () => {
			this.setState({
				openSetting: !this.state.openSetting
			})
		}

	render() {
		console.log(this.props.dateFrom);
		const list = [1,2,3]
		return (
			<Row>
				<BlockSettings>
					<Calendar
						text='Invoices from'
						onChange={this.props.onChangeDateFrom}
						date={this.props.dateFrom}
					/>
				</BlockSettings>

				<BlockSettings>
					<Calendar
						text='Invoices till'
						onChange={this.props.onChangeDateTill}
						date={this.props.dateTill}
					/>
				</BlockSettings>

				<BlockSettings>
					<Calendar
						text='Consider payments up'
						width='300px'
						onChange={this.props.onChangeDatePayment}
						date={this.props.datePayment}
					/>
				</BlockSettings>

				<BlockSettings>
					<Dropdown width='300px' list={list}/>
				</BlockSettings>

				<BlockSettings>
					<Input
						text="Dropdown"
						width="300px"
						value={"12.02.2015"}
						name="Invoces form"
					/>
				</BlockSettings>
				<div>
				<BlockSettingsIco src={IcoSettings} onClick={this.changeSetting}/>

				{this.state.openSetting ?
			 	<BlockSettingItems isSettings={this.state.isSettings}>

					 <SettingsItemsText>
						 <SettingsItemsIco src={IcoSettings} />
						 Print Report
						 <SettingsItemsIcoDown>&rsaquo;</SettingsItemsIcoDown>
					 </SettingsItemsText>

					 <SettingsItemsText>
						 <SettingsItemsIco src={IcoSettings} />
						 Preciew Report
						 <SettingsItemsIcoDown>&rsaquo;</SettingsItemsIcoDown>
					 </SettingsItemsText>

					 <SettingsItemsText>
						 <SettingsItemsIco src={IcoSettings} />
						 Open Report Form
						 <SettingsItemsIcoDown>&rsaquo;</SettingsItemsIcoDown>
					 </SettingsItemsText>

					 <SettingsItemsText>
						 <SettingsItemsIco src={IcoSettings} />
						 Export XML
					 </SettingsItemsText>

					 <SettingsItemsText>
						 <SettingsItemsIco src={IcoSettings} />
						 Histori
					 </SettingsItemsText>

					 <SettingsItemsText>
						 <SettingsItemsIco src={IcoSettings} />
						 Show help
					 </SettingsItemsText>
				 </BlockSettingItems>
				 : <div></div>}
			 	</div>
			</Row>
		)
	}
}

export default Parameters;

const BlockSettings = styled.div`
	margin-left: 20px;
	float: left;
`;

const BlockSettingsIco = styled.img`
	float: right;
	margin-top: 35px;
	margin-right: 20px;
	width: 34px;
	height: 34px;
	box-shadow: 0 1px 2px 0 rgba(90, 90, 90, 0.2);
  background-color: #f5f5f5;

	&:hover ${BlockSettingItems} {
		display: block;
	}
`;

const BlockSettingItems = styled.div`
	display: ${props => props.isSettings || 'none' };
	position: absolute;
  margin: 100px 0 0 170px;
	width: 290px;
  box-shadow: 0 2px 4px 0 rgba(90, 90, 90, 0.2);
  background-color: #ffffff;
`;

const HR = styled.hr`
	width: 270px;
	height: 1px;
	background-color: #e5e5e5;
`;

const SettingsItemsText = styled.div`
	margin: 22px 12px 22px 12px;
	padding-bottom: 22px;
	border-bottom: 1px solid #e5e5e5;
	font-family: Roboto;
	font-size: 16px;
	font-weight: normal;
	font-style: normal;
	font-stretch: normal;
	line-height: normal;
	letter-spacing: normal;
	color: #3c445a;
`;

const SettingsItemsIcoDown = styled.span`
	float: right;
	font-size: 25px;
	font-weight: bolder;
	transform: rotate(90deg);
`;

const SettingsItemsIco = styled.img`
	width: 22px;
	height: 22px;
	margin-right: 10px;
`;
