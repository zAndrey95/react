import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { graphql, compose } from 'react-apollo';
import styled from 'styled-components';

import Line from '../../../components/simple/Line'
import Input from '../../../components/simple/Input.js'
import Checkbox from '../../../components/simple/Checkbox'
import IcoSettings from '../../../style/img/ico-settings.png'
import Button from '../../../components/simple/Button'
import Table from '../../../components/container/table/Table'

import Dropdown from '../../../components/simple/dropdown/Dropdown'

const names = ['Date', 'Invoice No.', 'Customer No.', 'Name', 'Amount', 'Description', 'Account No.', 'Receipt No.']
const widths = ['10%', '10%', '10%', '20%', '10%', '20%', '10%', '10%']

const CurrentMont = () => <div/>;

const DateTange = (value) =>
	<Col lg={3}>
		{/*<StyleDropdownDateTange*/}
			{/*fluid search selection*/}
			{/*noResultsMessage={'no element'}*/}
			{/*defaultValue={'default'}*/}
			{/*options={countryOptions}*/}
			{/*onChange={this.handleChange}*/}
			{/*placeholder='Selection of time period'/>*/}
	</Col>;

const Invoice = () =>
	<StyleColInvoice lg={6}>
		<Col lg={3}><Input text="From" width="140px" name="from"/></Col>
		<Col lg={3}><Input text="From" width="140px" name="from"/></Col>
		<Col lg={4}><StyleButton value="SEARCH" width="250px" /></Col>
	</StyleColInvoice>;

const Customer = () =>
	<Col lg={3}>
		{/*<StyleDropdownDateTange placeholder='Select Country' fluid search selection options={countryOptions} onChange={this.handleChange}/>*/}
	</Col>;

export default class Payment extends Component {
	state = {
		active: 'Orange',
		fruit: [
			{
				id: 0,
				title: 'Apple'
			},
			{
				id: 1,
				title: 'Orange'
			},
			{
				id: 2,
				title: 'Strawberry'
			}
		],
		keys: ['id', 'title']
	};

	handleChange = (e, { value }) => this.setState({value});

	resetThenSet = (id) => {
		console.log(id);
	};

	render() {
		const { value, keys } = this.state;
		console.log(this.state);
		return (
			<Row>
				<Row>
					<Col lg={3}>
						<Dropdown
							defaultValue={this.state.active}
							list={this.state.fruit}
							activeId={this.resetThenSet}
							nameKey={keys}
						/>
					</Col>
					{value == null ? <div/> : value == 1 ? <CurrentMont/> : value == 2 ? <DateTange value='active' /> : value == 3 ? <Invoice/> : <Customer/> }
				</Row>
				<Line/>
				<Table arr={[]} widths={widths} names={names} align="left"/>
			</Row>
		)
	}
}

const StyleButton = styled(Button)`
	margin-top: 20px;
`

const StyleColInvoice = styled(Col)`
	margin-left: 20px;
`;

const StyleDropdownDateTange = styled(Dropdown)`
	margin-left: 20px;
	margin-top: 20px;
`;

const StyleDropdown = styled(Dropdown)`
	margin-top: 20px;
`;

const BlockSettingsIco = styled.img`
	float: right;
	margin-top: 35px;
	margin-right: 20px;
	width: 34px;
	height: 34px;
	box-shadow: 0 1px 2px 0 rgba(90, 90, 90, 0.2);
  background-color: #f5f5f5;
`;
