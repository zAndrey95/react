import React, { Component } from 'react';
import {Route, Switch} from 'react-router-dom';
import {  Row, Col} from 'react-bootstrap';
import { withApollo } from 'react-apollo'
import { graphql, compose } from 'react-apollo';
import { withRouter } from 'react-router'
import PropTypes from 'prop-types'

class Description extends Component {
  render() { 
    return <span> Offer</span>
  }
}


export default Description;
