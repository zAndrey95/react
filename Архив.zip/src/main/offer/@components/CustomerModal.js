import React, { Component } from 'react';
import { graphql, compose } from 'react-apollo';
import { Col, Row } from 'react-bootstrap';
import { withApollo, Query, Mutation } from 'react-apollo'
import styled from 'styled-components';

import Dropdown from '../../../../../@appElements/dropDown/Dropdown.js';
import CheckBox from '../../../../../@appElements/checkBox/CheckBox.js';
import Title from '../../../../../@appElements/title/Title.js'
import Input from '../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../@appElements/textarea/Textarea.js'
import Button from '../../../../../@appElements/button/Button.js'

import Cancel_black from '../../../../../@appElements/item_Img/Cancel_black.js'
import Ok_green from '../../../../../@appElements/item_Img/Ok_green.js'
import Cancel_red from '../../../../../@appElements/item_Img/Cancel_red.js'

import AllCustomerListsOnOrder from '../../../../../functions/query/order/allCustomerListsOnOrder.js'



class Modal_Add extends Component {
  constructor(props) {
    super(props);
    this.state = {
      resellerArray: [],
    };
  }
  test =  (Intern)  => {
    this.props.getCustomerIntern(Intern)

  }
  ger = (e) => {
  }

  render() { 
    const customerArray = this.props.allCustomerListsOnOrder.map((item, index) => {
      return(
        <div key ={item.Intern} onClick={this.props.getCustomerIntern.bind(null, item.Intern)} >
          <Col lg={3} >{item.KundenNr}</Col>
          <Col lg={9} >{item.AktNameIntern}</Col>
        </div>
      )
    });
    return (
      <div>
              <div>
                <Row style={{padding: "10px 0 0 0"}}>
                  <Col lg={5}>
                    <Title 
                      top={"0px"} 
                      text="Choose Customer"
                    />
                  </Col>
                  <Col lg={1} lgOffset={6}>
                    <Cancel_black onClick={this.props.closeModal}/>
                  </Col>
                </Row>

                <Row>
                  <Col lg={12} className="list_modal_name" style={{margin: '30px 0 0 30px'}}>
                    <Col lg={3}>
                      <span>Id:</span>
                    </Col>
                    <Col lg={9}>
                      <span>Name:</span>
                    </Col>
                  </Col>
                </Row>

                <Row> 
                  <Col lg={12} className='items_modal_list'>
                    {customerArray}
                  </Col>
                </Row>
        </div>
      </div> 
    )
  }
}

const graph =compose(
  graphql(AllCustomerListsOnOrder, {
  props: props => ({
    allCustomerListsOnOrder: props.AllCustomerListsOnOrder.allCustomerListsOnOrder ? props.AllCustomerListsOnOrder.allCustomerListsOnOrder : [],
  }),

  name: "AllCustomerListsOnOrder",
  })
)(Modal_Add);
export default withApollo(graph);
