import React, { Component } from 'react';
import {  Row, Col} from 'react-bootstrap';
import { NavLink } from 'react-router-dom'
import './Menu.css';



class Menu extends Component {
  render() {
    return (
      
      	<div style={{marginTop: '10px'}}>
	     	<Col lg={6}  className="col-menu-konditionen"><NavLink to={'/offer/create'} activeClassName="selected_konditionen_customer"><button className="menu_button_konditionen"> Offer</button></NavLink></Col> 
	      	<Col lg={6} className="col-menu-konditionen"><NavLink to={'/offer/note'} activeClassName="selected_konditionen_customer"> <button className="menu_button_konditionen"> Note</button></NavLink> </Col>
	    </div>     
    );
  }
}

export default Menu;
