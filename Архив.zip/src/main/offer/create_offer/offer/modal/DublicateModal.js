import React, { Component } from 'react';
import { graphql, compose } from 'react-apollo';
import { Col, Row } from 'react-bootstrap';
import { withApollo, Query, Mutation } from 'react-apollo'
import styled from 'styled-components';

import Dropdown from '../../../../../../../../@appElements/dropDown/Dropdown.js';
import CheckBox from '../../../../../../../../@appElements/checkBox/CheckBox.js';
import Title from '../../../../../../../../@appElements/title/Title.js'
import Input from '../../../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../../../@appElements/textarea/Textarea.js'
import Text from '../../../../../../../../@appElements/text/Text.js'
import Button from '../../../../../../../../@appElements/button/Button.js'
import Calendar from '../../../../../../../../@appElements/calendar/Calendar.js'

import Cancel_black from '../../../../../../../../@appElements/item_Img/Cancel_black.js'
import Ok_green from '../../../../../../../../@appElements/item_Img/Ok_green.js'
import Cancel_red from '../../../../../../../../@appElements/item_Img/Cancel_red.js'




class ShippingCostModal extends Component {

  getToDateDate = () =>{
  }
  render() { 
    return (
      <div style={{zIndex: 999, position: "relative"}}>
              <div>
                <Row style={{padding: "10px 0 0 0"}}>
                  <Col lg={5}>
                    <Title 
                      top={"0px"} 
                      text="Dublicate"
                    />
                  </Col>
                  <Col lg={1} lgOffset={6}>
                    <Cancel_black onClick={this.props.closeModal}/>
                  </Col>
                </Row>

                <Row>
                  <Col lg={12} style={{margin: '15px 0 0 30px'}}>
                  <Text text={"Offer to date"} height={"18px"} size={"16px"} color={"#6e6e6e"} marginTop={"1px"} top={"4px"} align={"left"}/>
                    <Col lg={4}>
                <Calendar 
                  getDate={this.getToDateDate}
                  text = 'Offer for date'
                  date={this.props.ToDate?new Date(this.props.ToDate.slice(0, 10).replace(/\-/g, ",")):new Date()}/>
            </Col>
                  </Col>
                </Row>


                <Row>
                  <Col lg={12} style={{margin: '20px 0 0 30px'}}>
                    
                    <Col lg={5}>
                      <CheckBox
                        value={"Regular customer"} 
                        style={{margin:"10px 0 0 0"}} 
                        open={false}
                      />
                    </Col>
                      
                    <Col lg={5}>
                      <CheckBox
                        value={"One-time customer"} 
                        style={{margin:"0 0 0 0"}} 
                        open={true}
                      />
                    </Col>
                  </Col>
                </Row>

                <Row>
                  <Col lg={12} style={{margin: '0 0 0 30px'}}>
                    <Col lg={5} lgOffset={2}>
                      <Button 
                        background="#99d5d7" 
                        top="39px" 
                        paddingTop="12px"
                        width = '93%'
                        height="40px"
                        size="16px"
                        text='Ok'
                        onClick={this.props.closeModal}
                      />
                    </Col>
                  </Col>
                </Row>
        </div>
      </div> 
    )
  }
}

export default ShippingCostModal
