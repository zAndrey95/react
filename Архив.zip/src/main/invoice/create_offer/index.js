import React, { Component } from 'react';
import {Route, Switch} from 'react-router-dom';
import {  Row, Col} from 'react-bootstrap';
import { withRouter } from 'react-router'
import { graphql, compose } from 'react-apollo';
import { withApollo, Query } from 'react-apollo'
import styled from 'styled-components';


import CheckBox from '../../../../../../@appElements/checkBox/CheckBox.js';
import Dropdown from '../../../../../../@appElements/dropDown/Dropdown'

import ListWithImg from '../../@components/listWithImg/ListWithImg'
import {ListLine, BlueText} from '../../@components/listWithImg/ListWithImg'

import Message from '../../img/message.png';
import Icon_fax from '../../img/icon_fax.png';
import Icon_smartphone_screen from '../../img/icon_smartphone_screen.png';
import agenda from '../../img/agenda.png';

import Offer from './offer/Offer.js'
import Note from './note/Note.js'
import Menu from './Menu.js';

import getOrderHead from '../../../../../../functions/query/order/getOrderHead.js'
import GetCreateOrderVorgabeLieferschein from '../../../../../../functions/query/order/getCreateOrderVorgabeLieferschein.js'


class Create_orders extends Component {

  constructor(props) {
    super(props);
     this.state = {
        change:true
      }
    this.createOrderRefItem = React.createRef() ;
  }

  onTrueChange = () => {
	 this.setState({change: true})
  }

  onFalseChange = () => {
	 this.setState({change: false})
  }



  render() {
    return (
      <Row>
        <Col lg={12}> <Menu headerId={this.props.headerId}/> </Col>

        <Col lg={12} >
          <Switch>
              <Route path={'/offer/create'} render={props =>
                <div>
                <Offer
                  id={this.props.id}
                  VorgabeLieferschein = {1}
                  date={this.props.date} 
                  procedureCustomersListForCreatingOrdersOnDate = {this.props.procedureCustomersListForCreatingOrdersOnDate}
                  refetchList={this.props.refetchList}
                  createTemporaryOrder={this.props.createTemporaryOrder}
                  onRef={this.props.onRef} 
                  deleteListPosition = {this.props.deleteListPosition}  
                  getOrderTypeFromOrder={this.props.getOrderTypeFromOrder}   
                  refetch = {this.props.refetch}
                  headerId={this.props.headerId}   
                  offerChooseCustomer = {this.props.offerChooseCustomer}        
                /> </div> }
              />
              <Route path={'/offer/note'} render={props =>
                <Note
                /> }
              />

          </Switch>
        </Col>
      </Row>
    );
  }
}

export default Create_orders
