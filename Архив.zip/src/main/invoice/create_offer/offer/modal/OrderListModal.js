import React, { Component } from 'react';
import { graphql, compose } from 'react-apollo';
import { Col, Row } from 'react-bootstrap';
import { withApollo, Query, Mutation } from 'react-apollo'
import styled from 'styled-components';

import Dropdown from '../../../../../../../../@appElements/dropDown/Dropdown.js';
import CheckBox from '../../../../../../../../@appElements/checkBox/CheckBox.js';
import Title from '../../../../../../../../@appElements/title/Title.js'
import Input from '../../../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../../../@appElements/textarea/Textarea.js'
import Button from '../../../../../../../../@appElements/button/Button.js'

import Cancel_black from '../../../../../../../../@appElements/item_Img/Cancel_black.js'
import Ok_green from '../../../../../../../../@appElements/item_Img/Ok_green.js'
import Cancel_red from '../../../../../../../../@appElements/item_Img/Cancel_red.js'




class OrderListModal extends Component {

  state = {
    isOpenArray: false
  }

  onShowClick = () =>{
    this.setState({isOpenArray: !this.state.isOpenArray})
  }

  render() { 
    const customerArray = this.props.allCheckOrders.map((item, index) => {
      return(
        <div key ={item.LieferscheinNr} style={{margin: '30px 0 0 30px'}}>
          <Col lg={3} >{item.LieferscheinNr}</Col>
          <Col lg={3} >{item.UserFullName}</Col>
          <Col lg={6} >{item.dOperation}</Col>
        </div>
      )
    });
    return (
      <div style={{zIndex: 999, position: "relative"}}>
              <div>
                <Row style={{padding: "10px 0 0 0"}}>
                  <Col lg={5}>
                    <Title 
                      top={"0px"} 
                      text="Warning"
                    />
                  </Col>
                  <Col lg={1} lgOffset={6}>
                    <Cancel_black onClick={this.props.closeModal}/>
                  </Col>
                </Row>

                <Row>
                  <Col lg={12} style={{margin: '30px 0 0 30px'}}>
                    <Col lg={12}>
                      <span> There is orders &nbsp;
                      {this.props.allCheckOrders ? this.props.allCheckOrders.length : 0} 
                      &nbsp; for customer <br/> on selected date {this.props.date}. <br/>
                      Do you want the order to be created? <br/>
                      </span>
                    </Col>
                  </Col>
                </Row>

                <Row>
                  <Col lg={12} style={{margin: '0 0 0 30px'}}>
                    <Col lg={3}>
                      <Button 
                        background="#f5a623" 
                        top="39px" 
                        paddingTop="13px"
                        width = '93%'
                        height="40px"
                        size="16px"
                        text='Show'
                        onClick={this.onShowClick}
                      />
                    </Col>
                    <Col lg={4}>
                      <Button 
                        background="#99d5d7" 
                        top="39px" 
                        paddingTop="13px"
                        width = '93%'
                        height="40px"
                        size="16px"
                        text='Yes'
                        onClick={this.props.validationOrderListModal.bind(null, true)}                      />
                    </Col>
                    <Col lg={4} onClick={this.props.closeModal} >
                      <Button 
                        background="#ff4b57" 
                        top="39px" 
                        paddingTop="13px"
                        width = '93%'
                        height="40px"
                        size="16px"
                        text='No'
                        onClick={this.props.closeModal}
                      />
                    </Col>
                  </Col>
                </Row>


                <Row> 
                  <Col lg={12}>
                    {this.state.isOpenArray ? customerArray : null}
                  </Col>
                </Row>
        </div>
      </div> 
    )
  }
}

export default OrderListModal
