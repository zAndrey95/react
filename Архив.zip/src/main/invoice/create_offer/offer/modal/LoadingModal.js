import React, { Component } from 'react';
import { graphql, compose } from 'react-apollo';
import { Col, Row } from 'react-bootstrap';
import { withApollo, Query, Mutation } from 'react-apollo'
import styled from 'styled-components';

import Dropdown from '../../../../../../../../@appElements/dropDown/Dropdown.js';
import CheckBox from '../../../../../../../../@appElements/checkBox/CheckBox.js';
import Title from '../../../../../../../../@appElements/title/Title.js'
import Input from '../../../../../../../../@appElements/input/Input.js'
import Textarea from '../../../../../../../../@appElements/textarea/Textarea.js'
import Button from '../../../../../../../../@appElements/button/Button.js'

import Cancel_black from '../../../../../../../../@appElements/item_Img/Cancel_black.js'
import Ok_green from '../../../../../../../../@appElements/item_Img/Ok_green.js'
import Cancel_red from '../../../../../../../../@appElements/item_Img/Cancel_red.js'




class LoadingModal extends Component {

  render() { 
    return (
      <div style={{zIndex: 999, position: "relative"}}>
              <div>
            

                <Row>
                  <Col lg={12} style={{margin: '3px 0 0 30px'}}>
                      <span> Loading... Please wait
                      </span>
                  </Col>
                </Row>

        </div>
      </div> 
    )
  }
}

export default LoadingModal
