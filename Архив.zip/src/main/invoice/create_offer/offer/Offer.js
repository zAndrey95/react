import React, { Component } from 'react';
import {Col, Row} from 'react-bootstrap';
import { NavLink } from 'react-router-dom'
import {Route, Switch} from 'react-router-dom';
import { withApollo, Query, Mutation, graphql, compose } from 'react-apollo'


import CheckBox from '../../../../../../../@appElements/checkBox/CheckBox.js';
import SimpleDropdown from '../../../../../../../@appElements/dropDown/SimpleDropdown'
import HeaderTable from '../../../../../../../@appElements/table/HeaderTable.js'
import Table from '../../../@components/tableWithChangeItem/TableWithChangeItem.js'
import Input from '../../../../../../../@appElements/input/Input.js'
import Button from'../../../../../../../@appElements/button/Button.js'
import InputWithDropdown from '../../../@components/inputWithDropdown/InputWithDropdown.js'
import Modal from '../../../../../../../@appElements/modal/Modal.js';
import Calendar from '../../../../../../../@appElements/calendar/Calendar.js'

import OrderListModal from'./modal/OrderListModal.js'
import WarningModal from'./modal/WarningModal.js'
import ShippingCostModal from'./modal/ShippingCostModal.js'
import OrderCreatingModal from'./modal/OrderCreatingModal.js'
import LoadingModal from'./modal/LoadingModal.js'



import Plus_green from '../../../../../../../@appElements/item_Img/Plus_green.js'
import Minus_red from '../../../../../../../@appElements/item_Img/Minus_red.js'
import Ok_green from '../../../../../../../@appElements/item_Img/Ok_green.js'
import Settings from '../../../../../../../@appElements/item_Img/Settings.js'
import Cancel_red from '../../../../../../../@appElements/item_Img/Cancel_red.js'
import DeliveryBox_yellow from '../../../../../../../@appElements/item_Img/DeliveryBox_yellow.js'

import delivery from '../../../img/delivery.png';
import cancel_red from '../../../img/cancel_red.svg';
import ok_green from '../../../img/ok_green.svg';
import add_color from '../../../img/add_color.svg';
import delete_color from '../../../img/delete_color.svg';
import edit from '../../../img/edit.svg';

import GetOrderDeliveryTime from '../../../../../../../functions/query/order/getOrderDeliveryTime.js'
import view_fkOrderTypes from '../../../../../../../functions/query/order/view_fkOrderTypes.js'
import AllOfferCreateGrid from '../../../../../../../functions/query/offer/allOfferCreateGrid.js'


import AllOrderRecalculationValues from '../../../../../../../functions/query/order/allOrderRecalculationValues.js'
import CreateNewOrder from '../../../../../../../functions/query/order/createNewOrder.js'

import AllorderTableOnChangeInput from '../../../../../../../functions/query/order/allorderTableOnChangeInput.js'

import CreateTemporaryOrder from '../../../../../../../functions/mutation/order/createTemporaryOrder.js'

import AllCheckOrders from '../../../../../../../functions/query/order/allCheckOrders.js'

import NoOrderOnOrderCreate from '../../../../../../../functions/mutation/order/noOrderOnOrderCreate.js'


import CreateOffer from '../../../../../../../functions/mutation/offer/createOffer.js' 
import AcceptedOffer from '../../../../../../../functions/mutation/offer/acceptedOffer.js' 
import DeclinedOffer from '../../../../../../../functions/mutation/offer/declinedOffer.js' 
import DublicateOffer from '../../../../../../../functions/mutation/offer/dublicateOffer.js' 
import TemporaryOffer from '../../../../../../../functions/mutation/offer/temporaryOffer.js' 


import './Order.css';

const names=[
  "Article no.", 
  "Quantity", 
  "Description", 
  "Addition",
  "Price",
  "Total",
  "Discount",
  "VAT"
];
const widths=[
  '10%',
  '10%',
  '20%', 
  '10%',
  '10%',
  '10%',
  '10%',
  '20%',
];

class Order extends Component {
  state = {
      date: new Date(),
      allOrderCreateGrid:[],
      orderType: 1,
      allOrderCreateGridMemory:[],
      tableIndex: -1,
      searchArtikel: '',
      isOrder: false,
      id: 1,
      isOpenOrderListModal: false,
      isOpenWarningModal: false,
      isOpenShippingCostModal: false,
      isOrderCreatingModal: false,
      isCreateOrder: true,
      indexOrderTypeDropdown: 0,
      isOpenLoadingModal: false,
      tableSearch: '',




      isOfferCreated: false

  }
  

  static getDerivedStateFromProps(nextProps, prevState) {
    if(!nextProps.AllOfferCreateGrid.loading){
      if(nextProps.id !== prevState.id){
      return {
        allOrderCreateGrid: !nextProps.AllOfferCreateGrid.loading ? nextProps.AllOfferCreateGrid.allOfferCreateGrid: [],
        allOrderCreateGridMemory: !nextProps.AllOfferCreateGrid.loading ? nextProps.AllOfferCreateGrid.allOfferCreateGrid:[],
        id: nextProps.id,
        isCreateOrder: false
      }
    }
    }
  }

// New OFFER FUNCTION!!!!!!!!!!!!!
// New OFFER FUNCTION!!!!!!!!!!!!!
// New OFFER FUNCTION!!!!!!!!!!!!!
// New OFFER FUNCTION!!!!!!!!!!!!!
// New OFFER FUNCTION!!!!!!!!!!!!!
// New OFFER FUNCTION!!!!!!!!!!!!!
// New OFFER FUNCTION!!!!!!!!!!!!!
// New OFFER FUNCTION!!!!!!!!!!!!!
// New OFFER FUNCTION!!!!!!!!!!!!!
// New OFFER FUNCTION!!!!!!!!!!!!!
// New OFFER FUNCTION!!!!!!!!!!!!!

  
  validationMergeValue = () => { //Validation on Menge. When Menge nothing prodecure cant run
    let validation = false;
    for (let n of this.state.allOrderCreateGrid) {
      if(n.Menge == 0 || n.Menge == null){
        validation = false;
        break;
      }
    validation = true;
    }
    return validation;
  }

  createOffer = () =>{
    const validation = this.validationMergeValue();  // !Merge <= 0
    if(false) {
      this.setState({isOpenWarningModal: true}
    )}
    else {
    let variables = [];
    let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    cloneArrayone.forEach((item)=>{
      const array = {
          LinkArtikel: item.LinkArtikel,
          LinkVirtualPosition: null,
          Menge: item.Menge,
          IndTextDeliveryNote: null,
          IndTextProduction: null,
          Betrag: 2,
          RabattP: item.RabattP ? item.RabattP : null,
          MWStCode: 2,
          Total: item.Total,
          TotalNetto: item.Total  

        }
        variables.push(array);
        console.log(array)
        //let values = `@OfferID, ${item.LinkArtikel},null,${item.Menge},${item.IndTextProduction},${item.IndTextDeliveryNote},${item.Betrag},${item.RabattP},${item.MWStCode},${item.Total},${item.TotalNetto}`;

      })
          console.log(this.props.date)
          console.log(this.props.id)
           this.props.CreateOffer({ //Run PR_CalculationOrder, create new temporary table 
          variables: {
            date: this.props.date,
            secondDate: '2018-10-25',
            id: this.props.id,
            variables: variables
  
          }     
        }).then(()=> this.props.refetch())
          .catch((err)=>console.log(err)) 
        }
      }

  declinedOffer = () =>{
    this.props.DeclinedOffer({ //Run PR_CalculationOrder, create new temporary table 
      variables: {
        id: this.props.offerChooseCustomer.OfferID 
      }     
    }).then(()=> this.props.refetch())
          .catch((err)=>console.log(err))  
  }

  acceptedOffer = () =>{
    this.props.AcceptedOffer({ //Run PR_CalculationOrder, create new temporary table 
      variables: {
        id: this.props.offerChooseCustomer.OfferID 
      }     
    }).then(()=> this.props.refetch())
          .catch((err)=>console.log(err)) 
  }

  changeOffer = () => { 
    this.setState({isOfferCreated: true})
  }

  validationOnCreateNewOffer = () =>{ //Second Function Check Order List. When we have [] load 
    const {AllCheckOrders} = this.props;
    if(!AllCheckOrders.loading){
      if(AllCheckOrders.allCheckOrders.length >= 1){ 
        this.setState({isOpenOrderListModal: true})
      }
      else {
        this.sendOrderDataIntoDatabase()}
    }
  }














  sendOrderDataIntoDatabase =  () => { //Get Data Into BD.
    const validation = this.validationMergeValue();  // !Merge <= 0
   if(!validation) {
    this.setState({isOpenWarningModal: true}
    )} //Second validation. Field with Menge must not equal 0 
    else{
          this.setState({isOrderCreatingModal: true})
       this.userCreateNewOrder();
      let variables = [];
      let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
      cloneArrayone.forEach((item)=>{
        const array = {
          LinkArtikel: item.LinkArtikel,
          Menge: item.Menge,
          Total: item.PreisLieferung,
          RabbattP: item.RabattP ? item.RabattP : null,
          MWStCode: item.MWStCode ? item.MWStCode: 2,
          IndTextDeliveryNote: null,
          IndTextProduction: 6
        }
        variables.push(array);
      })

           this.props.CreateNewOrder({ //Run PR_CalculationOrder, create new temporary table 
          variables: {
            userId: 1,
            orderType: 1,
            date: this.props.date,
            Intern: this.props.id,
            userTable: String,
            variables: variables
          },

     
        }).then((data) => {
          const createNewOrder = data.data.createNewOrder[0];
          console.log(createNewOrder.ErrorCode);
          if(createNewOrder.ErrorCode){
            console.log(createNewOrder.ErrorText)
          }
          else{
          this.props.deleteListPosition();
          this.setState({isOrderCreatingModal: false})
          } 
        }).catch((err)=>{console.log(err)})
         
        
}

         
            
        console.log(this.state.isCreateOrder)
       


     
    
  }

  validationMergeValue = () => { //Validation on Menge. When Menge nothing prodecure cant run
    let validation = false;
    for (let n of this.state.allOrderCreateGrid) {
      if(n.Menge == 0 || n.Menge == null){
        validation = false;
        break;
      }
    validation = true;
    }
    return validation;
  }

  validationOrderListModal =(boolean)=>{ //Validation with Promise. If user press OK in Modal boolean = true and run func this.sendOrderDataIntoDatabase
    let promise = new Promise((resolve, reject) => {
      resolve(boolean);
    });

    promise.then(
      result => {
          this.setState({isOpenOrderListModal: false})
          this.sendOrderDataIntoDatabase();
      },
      error => {
        console.log(error)
      }
    );
  }

//****************************** END FUNCTIONS TO CREATE ORDER******************************//

//****************************** CLOSE ALL MODAL ******************************//
  closeWarningModal = () =>{ 
    this.setState({isOpenWarningModal: false})
  }

  closeOrderListModal = () =>{
    this.setState({isOpenOrderListModal: false})
  }

  closeShippingCostModal = () =>{
    this.setState({isOpenShippingCostModal: false})
  }

  openShippingCostModal = () =>{
    this.setState({isOpenShippingCostModal: true})
  }

  closeOrderCreatingModal = () =>{
    this.setState({isOrderCreatingModal: false})
  }

//****************************** END CLOSE ALL MODAL ******************************//

//******************************No ORDER******************************//

//******************************No ORDER******************************//



//*****************************All Functions from Input with Dropdown******************************//
  onClickInputWithDropdown = (index, item) =>{
    let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    const {tableIndex} = this.state
    cloneArrayone[tableIndex].ArtikelNr = item.ArtikelNr
    cloneArrayone[tableIndex].Bezeichnung = item.Bezeichnung
    cloneArrayone[tableIndex].PreisLieferung = item.Betrag1
    cloneArrayone[tableIndex].LinkArtikel = item.Intern
    cloneArrayone[tableIndex].RabbattP = item.Intern
    this.setState({allOrderCreateGrid: cloneArrayone})
    console.log(item)
  }

  onClickTable = (index, e) =>{
    this.setState({tableIndex: index})
  }

  changeInputWithDropdownValue = (e) => {
    let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    const {tableIndex} = this.state
    cloneArrayone[tableIndex].ArtikelNr = e.target.value;
    this.setState({allOrderCreateGrid: cloneArrayone, searchArtikel: e.target.value })
    
  }


//******************************END All Functions from Input with Dropdown******************************//


//*****************************All Temporary Order******************************//
 //ValidationOnClick
  validationOnClickItems  = () => {
    if(this.state.isOrder){
      this.createTemporaryOrder();
    }
  }
  //Create TEMPORARY ORDER. Trasfer into left grip in GetOrder.js
  createTemporaryOrder = () => {
    const {allOrderCreateGrid, allOrderCreateGridMemory} = this.state
    const {offerChooseCustomer, id} = this.props;

    if(allOrderCreateGrid===allOrderCreateGridMemory){ console.log("DONT CREATE TEMP")}
      else{
        console.log("Temporary Order Creating ")
        let variables = [];
        let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
        cloneArrayone.forEach((item)=>{
          const array = {
              LinkArtikel: item.LinkArtikel,
          LinkVirtualPosition: null,
          Menge: item.Menge,
          IndTextDeliveryNote: null,
          IndTextProduction: null,
          Betrag: 2,
          RabattP: item.RabattP ? item.RabattP : null,
          MWStCode: 2,
          Total: item.Total,
          TotalNetto: item.Total 
          }
             variables.push(array);
        });
        console.log(variables)
          this.setState({isOpenLoadingModal: true})
           this.props.TemporaryOffer({
              variables: {
                id: id,
                TempOffer: offerChooseCustomer.TempOfferID ? offerChooseCustomer.TempOfferID : 0,
                OfferId: offerChooseCustomer.OfferID ? offerChooseCustomer.OfferID : 0,
                Declined: offerChooseCustomer.Declined ? offerChooseCustomer.Declined : false,
                Accepted: offerChooseCustomer.Accepted ? offerChooseCustomer.Accepted : false,
                date: this.props.date,
                secondDate: this.props.date, 
                variables: variables
                },
            }).then((data)=> console.log(data))
              .then(()=> this.props.refetch())
              .then(()=>this.setState({isOpenLoadingModal: false}))
              .catch((err)=>console.log(err)) 
 
         


         } 

  }

  userCreateNewOrder = () =>{
    this.setState({isCreateOrder: true})
    console.log('Yes')
  }
//******************************END All Temporary Order******************************//







  //Create NEW ORDER with date, id, GUID


validationMergeValue = () => { //Validation on Menge. When Menge nothing prodecure cant run
    let validation = false;
    for (let n of this.state.allOrderCreateGrid) {
      if(n.Menge ==0 || n.Menge == null){
        validation = false;
        break;
      }
    validation = true;
    }
    return validation;
  }

  indexOnClickTable = (index) => {
    this.setState({tableIndex: index})
  }

  changeOrdetTypeValue = (index) =>{
    this.setState({orderType: index}, () => this.valueRelativelyOrderType())
  }
  onChange = date => this.setState({ date })

  specialOrder =() =>{
    this.setState({allOrderCreateGridMemory: this.state.allOrderCreateGrid, allOrderCreateGrid: []})
  }

  memoryOrder =() =>{
    this.setState({allOrderCreateGrid: this.state.allOrderCreateGridMemory})
  }


  

  changeNumbersOnNegative = () =>{
    var cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    for (const key in cloneArrayone){
      cloneArrayone[key].Menge = -cloneArrayone[key].Menge
      cloneArrayone[key].Total = -cloneArrayone[key].Total
    }
    console.log('g')
    this.setState({allOrderCreateGrid: cloneArrayone})
  }

  changeTableByInput = (index, e) =>{
    var cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    const name = e.target.name
    console.log(name)
    console.log(e.target.name)
    cloneArrayone[index][name] = e.target.value;
    cloneArrayone[index].Total = this.changeMerge(cloneArrayone[index]);;
    
    
    this.setState({allOrderCreateGrid: cloneArrayone});
  }

  changeMerge = (cloneArrayone) =>{

    let sum = cloneArrayone.Menge * cloneArrayone.PreisLieferung;
    let total = Math.round(sum * 100) / 100
    return total
  }

  changeNumbersOnZero = () =>{
    var cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    for (const key in cloneArrayone){
      cloneArrayone[key].Menge = 0
      cloneArrayone[key].Total = 0
      
    }
    this.setState({allOrderCreateGrid: cloneArrayone})
  }

  

  recalculationOfValues = ( ) =>{
    
         
  }

  sea(term){
    let a = this.state.term
   return function (product){ 
      return product.name.toLowerCase().indexOf(a)  !== -1 || product.cod.toLowerCase().indexOf(a)  !== -1;

    }   
    }

  deleteTable = (index) =>{
    let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    cloneArrayone.splice(index, 1);

    this.setState({allOrderCreateGrid: cloneArrayone})
  }

  addNewRecord = (index) =>{
    let cloneArrayone = JSON.parse(JSON.stringify(this.state)).allOrderCreateGrid;
    const newArray = {
      Addition: '',
      ArtikelNr: '',
      Bezeichnung: '',
      PreisLieferung: '',
      Total: '',
      Menge: '',
      RabattP: '',
      MWStCode: ''

    }
    cloneArrayone.unshift(newArray);
    this.setState({allOrderCreateGrid: cloneArrayone})
  }

  rrrr = (node) =>{
  
  }

  changeTableSearch = (e) =>{
    this.setState({tableSearch: e.target.value})
  }

  componentDidMount() {
    this.props.onRef(this)
    console.log('componentDidMount')
  }
  componentWillUnmount() {
    this.props.onRef(undefined)
  }
  

  render() {
    let input = '1';
    console.log(this.state.allOrderCreateGrid)
    console.log(this.props.offerChooseCustomer)
    const {props, procedureCustomersListForCreatingOrdersOnDate} = this.props;
    const {AllCheckOrders, offerChooseCustomer} = this.props;
    const {isOfferCreated} = this.state;
    if(this.props.AllOfferCreateGrid.loading){ return <div>Loading</div>}
      else{
    return (
      <Row>
      {this.props.offerChooseCustomer.OfferID 

        ?
        <div> 
        <Col lg={2} lgOffset={4}>
          <Calendar getDate ={this.changeOffer} text="Date" style={{width: '95%', marginTop: '12px'}}/>
        </Col>
        <Col lg={2}>
          <Calendar getDate ={this.changeOffer} text = "Valid until" style={{width: '90%', marginTop: '12px'}} daysStep={1}/>
        </Col>

        <Col lg={2}>
          <Button 
            onClick={(async()=>{await this.acceptedOffer() })}
            background={offerChooseCustomer.Declined || offerChooseCustomer.Accepted ? "#3c445a" : "#99d5d7" }
            top="39px" 
            paddingTop="12px"
            width = '93%'
            height="40px"
            size="16px"
            text='Offer Create'
          />
        </Col>

        <Col lg={2}>
          <Button 
            onClick={(async()=>{await this.declinedOffer() })}
            background={offerChooseCustomer.Declined ? "#3c445a" : "#ff4b57"}
            top="39px" 
            paddingTop="12px"
            width = '93%'
            height="40px"
            size="16px"
            text='Offer Decilined'
          />
        </Col>
        </div>
        :

        <Col lg={3} lgOffset={9}>
         <Button 
          onClick={(async()=>{await this.createOffer() })}
          background="#99d5d7" 
          top="39px" 
          paddingTop="12px"
          width = '93%'
          height="40px"
          size="16px"
          text='Offer Create'
        />
      </Col>
}

      <Col lg={12}>

          <Modal
            isOpen={this.state.isOpenOrderListModal}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            width={"481px"}
            height={"300px"}
            component={<OrderListModal 
              allCheckOrders={AllCheckOrders.allCheckOrders ? AllCheckOrders.allCheckOrders : []} 
              date = {this.props.date}
              closeModal={this.closeOrderListModal}
              validationOrderListModal={this.validationOrderListModal} 
              />}
            />

             <Modal
            isOpen={this.state.isOpenLoadingModal}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            width={"200px"}
            height={"50px"}
            component={<LoadingModal 
              allCheckOrders={AllCheckOrders.allCheckOrders ? AllCheckOrders.allCheckOrders : []} 
              date = {this.props.date}
              closeModal={this.closeOrderListModal}
              validationOrderListModal={this.validationOrderListModal} 
              />}
            />

          <Modal
            isOpen={this.state.isOpenWarningModal}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            width={"350px"}
            height={"220px"}
            component={<WarningModal 
            closeModal={this.closeWarningModal}
            />}
          />

          <Modal
            isOpen={this.state.isOpenShippingCostModal}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            width={"350px"}
            height={"220px"}
            component={<ShippingCostModal 
            closeModal={this.closeShippingCostModal}
            />}
          />

          <Modal
            isOpen={this.state.isOrderCreatingModal}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            width={"350px"}
            height={"220px"}
            component={<OrderCreatingModal 
            closeModal={this.closeOrderCreatingModal}
            />}
          />

        </Col>


         

        
        
        <Col lg={12} style={{marginTop: '30px'}}>


           <Query
                      query={AllorderTableOnChangeInput}
                      variables={{search: this.state.searchArtikel}}
                      fetchPolicy='network-only'
                    > 
                    {({ loading, error, data, refetch, networkStatus }) => {
                      if (networkStatus === 4) return "Refetching!";
                      if (error) return `Error!: ${error}`;
                      return (
                        <Table 
                    tableSearch={this.state.tableSearch}
                    changeTableSearch={this.changeTableSearch}
                    orderType = {this.state.orderType}
                    changeTableByInput= {this.changeTableByInput}
                    changeNumbersOnNegative= {this.changeNumbersOnNegative}
                    allOrderCreateGrid={this.state.allOrderCreateGrid}
                    onClick={this.indexOnClickTable} 
                    delete={this.deleteTable}
                    testFunctionToInput= {this.testFunctionToInput}
                    changeInputWithDropdownValue={this.changeInputWithDropdownValue}
                    inputValue = {this.state.inputValue}
                    list={data.allorderTableOnChangeInput ? data.allorderTableOnChangeInput : null} 
                    addNewRecord={this.addNewRecord}
                    onClickInputWithDropdown={this.onClickInputWithDropdown}
                    onClickTable={this.onClickTable}
                    loading={this.props.AllOfferCreateGrid.loading}
                    allOrderCreateGrid={this.state.allOrderCreateGrid}

                    
                    //FFFFF
                    names= {names}
                    
                    widths={widths}
                  />                     );
                    }}
                    </Query>

             
        </Col>
      </Row>
    );
  }
}
}

const graph = compose(
  
  graphql(AllOfferCreateGrid, {
    options: (props) => ({
      fetchPolicy: 'network-only',
      variables: {
        TempLS: props.offerChooseCustomer.TempOfferID ? props.offerChooseCustomer.TempOfferID: 0,
        OfferID: props.offerChooseCustomer.OfferID ?  props.offerChooseCustomer.OfferID: 0,
        id: props.id,
        date: "2018-10-10",
        userTable: String,
        LinkOffer: props.id,
      }
    }),

    name: "AllOfferCreateGrid",
    withRef: true
  }
  ),
  graphql(AllCheckOrders, {
    options: (props) => ({
      fetchPolicy: 'cache-and-network',
      variables: {
        id: props.id,
        date: props.date,
      }
    }),
    name: "AllCheckOrders",
    withRef: true

  }
  ),
  graphql(CreateNewOrder, {name:"CreateNewOrder"}),
  graphql(CreateTemporaryOrder, {name:"CreateTemporaryOrder"}),
  graphql(NoOrderOnOrderCreate, {name:"NoOrderOnOrderCreate"}),
  graphql(CreateOffer, {name:"CreateOffer"}),
  graphql(AcceptedOffer, {name:"AcceptedOffer"}),
  graphql(DeclinedOffer, {name:"DeclinedOffer"}),
  graphql(DublicateOffer, {name:"DublicateOffer"}),
  graphql(TemporaryOffer, {name:"TemporaryOffer"}),
)(Order);

export default withApollo(graph);


