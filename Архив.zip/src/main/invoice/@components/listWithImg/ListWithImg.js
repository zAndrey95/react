import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import {  Col } from 'react-bootstrap';
import styled from 'styled-components';

export const ListLine = styled.div`
  height: 28px;
  padding-top: 5px;
  border-bottom: 1px solid #ffffff;
`;

export const BlueText = styled.div`
  width: 175px;
  height: 17px;
  font-family: HelveticaNeue;
  font-size: 14px;
  font-weight: 400;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  color: #4a4a4a;
`;

const defaultImgStyle = {marginTop:'-5px',height: "19px", width:"12px", marginRight: "8px"};



class ListWithImg extends Component {

  render() {
      return (
          <Col lg={12}>
            <ListLine>
              <img 
                style={this.props.imgStyle} 
                src={this.props.src}
              />
              <span> {this.props.text}</span>
            </ListLine>
          </Col>
      )
  }
}

export default ListWithImg;



