import React, { Component } from 'react';
import {  Col, Row } from 'react-bootstrap';
import { withApollo, Query, Mutation } from 'react-apollo'

import './Table.css';

import edit from '../../img/edit.svg';
import testM from '../../functions/query/order/testM.js'
import InputWithDropdown from '../inputWithDropdown/InputWithDropdown.js'

import Input from '../input/Input.js'

import search from '../../img/search1.svg'

const table = ['LinkArtikel','Menge','Bezeichnung','','PreisLieferung','Total','RabattP','MWStCode']

class TableWithChangeItem extends Component {

  constructor() {
    super();
    this.state = {
      selectItem: new Date(),
      index:'i',
      isArtikelNr: false,
      articalIndex: false,
      quantityIndex: false,
      desIndex: false,
      priceIndex: false,
      discountIndex: false,
    }
    this.textInput = React.createRef();

  }



  onClick=(index)=>{
    this.setState({index})
    
  }

  changeTableRowIndex = (state, tableRowIndex) =>{
    console.log(state);
    console.log(tableRowIndex)
    this.setState({[state]: tableRowIndex})
  }

  changeInputWithoutDroponBlur = (state) => {
    this.setState({[state]: false})

  }





  render() {
    const {allOrderCreateGrid, orderType} = this.props
    const inputWithDrop = 
      <InputWithDropdown
        testFunctionToInput= {this.props.testFunctionToInput}
        changeSearchArtikel={this.props.changeSearchArtikel}
        inputValue = {''}
        text="Group" 
        style={{zIndex: 11}} 
        list={this.props.list} 
        gruppeId={1} 
        onBlur={this.testBlur} 
        deleteDropDown={null} 
        addDropDown={null} 
        updeteDrop={null}
        ref = {this.textInput}
          />
    
    const newArr=[];
    allOrderCreateGrid.map((item, index)=>{
      console.log(this.state.index)
                newArr.push([
                  //Artiker NR
                  this.state.articalIndex === index 

                  ?
                    <InputWithDropdown
                      testFunctionToInput= {this.props.testFunctionToInput}
                      changeSearchArtikel={this.props.changeSearchArtikel}
                      inputValue = {''}
                      text="Group" 
                      style={{zIndex: 11}} 
                      list={this.props.list} 
                      gruppeId={1} 
                      onBlur={this.changeInputWithoutDroponBlur.bind(this, 'articalIndex')} 
                      deleteDropDown={null} 
                      addDropDown={null} 
                      updeteDrop={null}
                      ref = {this.textInput}
                    /> 
                  :
                    <div onClick={this.changeTableRowIndex.bind(null,'articalIndex',index)}>{item.ArtikelNr}</div>  
                    
                  ,
                  // Menge
                    <Input  
                      type="number" 
                      value={item.Menge ? item.Menge : 0} 
                      name="search" 
                      onBlur={this.changeInputWithoutDroponBlur.bind(this, 'quantityIndex')} 
                      onChange={this.props.changeTableByInput.bind(this, index)}
                      width = '50%'
                      autoFocus={true}
                    /> 
            
                  ,
                  //Descripton
                  this.state.desIndex === index 
                  ?
                    <InputWithDropdown
                      testFunctionToInput= {this.props.testFunctionToInput}
                      changeSearchArtikel={this.props.changeSearchArtikel}
                      inputValue = {''}
                      text="Group" 
                      style={{zIndex: 11}} 
                      list={this.props.list} 
                      gruppeId={1} 
                      onBlur={this.changeInputWithoutDroponBlur.bind(this, 'desIndex')} 
                      deleteDropDown={null} 
                      addDropDown={null} 
                      updeteDrop={null}
                      ref = {this.textInput}
                    /> 
                  :
                     <div onClick={this.changeTableRowIndex.bind(null,'desIndex',index)}>{item.Bezeichnung ? item.Bezeichnung.substring(0, 25) : ''}</div> 
                    
                  ,
                  <img style={{width:'26px', height: "25px"}} src={edit} onClick={this.props.deleteTable}/>,
                  <div> {item.PreisLieferung}</div>, 
                  <div style ={{color: item.Menge <0 ? "#d0021b" : null}}> {item.Total}</div> , 
                  <div> {item.RabattP ? item.RabattP + '%' : item.RabattP}</div>,
                  <div> {item.MWStCode} </div> 
                ])
              })
    const arr = newArr.map((item, index) => {
      return (
        


        <Col
          onClick={ this.onClick.bind(this,index)}
          style={{"text-align": this.props.align?this.props.align:"center", borderLeft: index==this.state.index ? "12px solid #3c445a": "12px solid #cdcdcd"}}
          className="tabRow"
          lg={12}
          key={index}>
          <Row>
            <Col lg={this.props.delete?11:12}>
              {newArr[index].map((col, id)=>{
                const width = this.props.widths[id];
                return(

                  col ?
                  <div style={{'min-width':`${width}`, float: "left", padding: "10px 0 0 9px" }} key={id}>{col}</div>:
                  <div style={{'min-width':`${width}`, float: "left", padding: "10px 0 0 9px" }} key={id}>{'-'}</div>
                )
              })}
            </Col>
            {this.props.delete?<Col lg={1}><Col lg={6}  className="editTable"><img onClick={this.props.edit?this.props.edit.bind(this, index):null} src={edit}/></Col><Col lg={6}  className="deleteCustomer"><div onClick={this.props.delete?this.props.delete.bind(this, index):null}>x</div></Col></Col>:null}
          </Row>

        </Col>
      )
    })
    
    const names = this.props.names.map((item, index)=>{
      const width = this.props.widths[index];
        return(
          <div
            className="headerTable"
            key={index}
            style={{"text-align": this.props.align?this.props.align:"center",'min-width':`${width}`, float: "left", padding: "10px 0 0 9px", height: "37px", "border-bottom": "1px solid #e0e0e0", background: "#3c445a" }}>
            {item}
          </div>
        )
    })

    return (
      <div>
        <Col lg={this.props.delete?11:12}>{names}</Col>{this.props.delete?<Col style={{height: "36px",background: "#3c445a"}} lg={1}></Col>:null}

        <Row>
          <Col lg={12} className="input-search">
              <Col lg={11}>
                <input className="search_main" placeholder="Search" onChange={ this.props.getSearchValue} value={this.props.searchValue} name="searchValue"/>
              </Col>
               <Col lg={1} className="element_search">
                <img src={search} alt=""/>
              </Col>
          </Col>
        </Row>
        <Col lg={12} id="q" className="ys">
        {arr}
        </Col>
      </div>

    )
  }
}

export default TableWithChangeItem;