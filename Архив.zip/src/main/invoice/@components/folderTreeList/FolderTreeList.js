import React, { Component } from 'react';
import { graphql } from 'react-apollo';
import { withApollo } from 'react-apollo'
import {  Col } from 'react-bootstrap';
import styled, {withTheme} from 'styled-components';

import FolderTreeElement from '../folderTreeElement/FolderTreeElement.js'


class FolderTreeList extends Component {

  render() {
    const folderTree = this.props.folderNames.map((item, index) => {
      return ( 
        <div key ={index} style={{margin: '12px 0px 0px 10px'}}>
          <FolderTreeElement 
            open={this.props.folderIndex == index ? true: false}
            text= {item}
            subFolder={[]}
            subFolderItems={[]}
            changeFolderName={this.props.changeFolderName}
            getSubFolder = {this.props.getSubFolder}
            elementId = {index}
            onClick={this.props.getFolderIndex.bind(this, index)}
          />
        </div>
      )
  })
    
    return folderTree
  }
}

export default FolderTreeList;


